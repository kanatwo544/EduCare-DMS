'use client';

import { useState } from 'react';
import { useAppData } from '@/lib/context/AppDataContext';
import { AdminPageHeader } from '@/components/admin/AdminPageHeader';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { UserPlus, Upload, Search, Mail, Shield, User, Trash2, CheckCircle2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';

export default function AdminUsersPage() {
  const { students, teachers, classes, subjects, addStudent, addTeacher } = useAppData();
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showBulkModal, setShowBulkModal] = useState(false);
  const [selectedTab, setSelectedTab] = useState('students');

  const [newUser, setNewUser] = useState({
    name: '',
    email: '',
    role: 'student' as 'student' | 'teacher' | 'admin',
    selectedClasses: [] as string[],
    selectedSubjects: [] as string[]
  });

  const admins = [
    {
      id: 'admin1',
      name: 'Sarah Johnson',
      email: 'sarah@school.edu',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah'
    },
    {
      id: 'admin2',
      name: 'Michael Chen',
      email: 'michael@school.edu',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Michael'
    }
  ];

  const handleAddUser = () => {
    if (!newUser.name || !newUser.email) {
      toast.error('Please fill in all required fields');
      return;
    }

    if (newUser.role === 'student') {
      addStudent({
        name: newUser.name,
        email: newUser.email,
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${newUser.name}`,
        subjects: newUser.selectedSubjects,
        overallAverage: 75,
        attendance: 90
      });
      toast.success('Student added successfully!');
    } else if (newUser.role === 'teacher') {
      addTeacher({
        name: newUser.name,
        email: newUser.email,
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${newUser.name}`,
        subjects: newUser.selectedSubjects,
        classes: newUser.selectedClasses
      });
      toast.success('Teacher added successfully!');
    } else {
      toast.success('Admin added successfully! (Demo)');
    }

    setShowAddModal(false);
    setNewUser({
      name: '',
      email: '',
      role: 'student',
      selectedClasses: [],
      selectedSubjects: []
    });
  };

  const handleBulkUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const rows = text.split('\n').filter(row => row.trim());
      const count = rows.length - 1;
      toast.success(`Successfully parsed ${count} users from CSV! (Demo)`);
      setShowBulkModal(false);
    };
    reader.readAsText(file);
  };

  const filteredStudents = students.filter(s =>
    s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredTeachers = teachers.filter(t =>
    t.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredAdmins = admins.filter(a =>
    a.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    a.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-8 space-y-6">
      <AdminPageHeader
        title="User Management"
        description="Manage students, teachers, and administrators"
        rightContent={
          <div className="flex gap-3">
          <Dialog open={showBulkModal} onOpenChange={setShowBulkModal}>
            <DialogTrigger asChild>
              <Button variant="outline" className="gap-2">
                <Upload className="w-4 h-4" />
                Bulk Upload
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Bulk Upload Users</DialogTitle>
                <DialogDescription>Upload a CSV file to add multiple users at once</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label>CSV File</Label>
                  <Input
                    type="file"
                    accept=".csv"
                    onChange={handleBulkUpload}
                  />
                  <p className="text-sm text-gray-500">
                    Format: name,email,role,class (optional),subject (optional)
                  </p>
                </div>
                <div className="bg-blue-50 p-3 rounded-lg text-sm">
                  <p className="font-medium text-blue-900 mb-1">Example CSV format:</p>
                  <code className="text-blue-700">
                    John Doe,john@school.edu,student,10A,physics<br />
                    Jane Smith,jane@school.edu,teacher,,physics,chemistry
                  </code>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog open={showAddModal} onOpenChange={setShowAddModal}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <UserPlus className="w-4 h-4" />
                Add User
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Add New User</DialogTitle>
                <DialogDescription>Create a new user account</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label>Full Name</Label>
                  <Input
                    placeholder="Enter name"
                    value={newUser.name}
                    onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input
                    type="email"
                    placeholder="Enter email"
                    value={newUser.email}
                    onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Role</Label>
                  <Select value={newUser.role} onValueChange={(value: any) => setNewUser({ ...newUser, role: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="student">Student</SelectItem>
                      <SelectItem value="teacher">Teacher</SelectItem>
                      <SelectItem value="admin">Admin</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {newUser.role === 'teacher' && (
                  <div className="space-y-2">
                    <Label>Subjects (Select multiple)</Label>
                    <div className="border rounded-lg p-3 space-y-2 max-h-40 overflow-y-auto">
                      {subjects.map(subject => (
                        <label key={subject.id} className="flex items-center gap-2 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={newUser.selectedSubjects.includes(subject.id)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setNewUser({
                                  ...newUser,
                                  selectedSubjects: [...newUser.selectedSubjects, subject.id]
                                });
                              } else {
                                setNewUser({
                                  ...newUser,
                                  selectedSubjects: newUser.selectedSubjects.filter(id => id !== subject.id)
                                });
                              }
                            }}
                            className="rounded"
                          />
                          <span>{subject.name}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                )}
                {newUser.role === 'student' && (
                  <div className="space-y-2">
                    <Label>Classes (Select multiple)</Label>
                    <div className="border rounded-lg p-3 space-y-2 max-h-40 overflow-y-auto">
                      {classes.map(cls => (
                        <label key={cls.id} className="flex items-center gap-2 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={newUser.selectedClasses.includes(cls.id)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setNewUser({
                                  ...newUser,
                                  selectedClasses: [...newUser.selectedClasses, cls.id]
                                });
                              } else {
                                setNewUser({
                                  ...newUser,
                                  selectedClasses: newUser.selectedClasses.filter(id => id !== cls.id)
                                });
                              }
                            }}
                            className="rounded"
                          />
                          <span>{cls.name}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                )}
                <div className="bg-green-50 p-3 rounded-lg text-sm text-green-800">
                  <p className="font-medium flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4" />
                    Auto-generated credentials
                  </p>
                  <p className="text-green-700 mt-1">
                    Login credentials will be auto-generated and sent via email
                  </p>
                </div>
                <Button onClick={handleAddUser} className="w-full">
                  Create Account
                </Button>
              </div>
            </DialogContent>
          </Dialog>
          </div>
        }
      />

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <Input
          placeholder="Search users by name or email..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>

      <Tabs value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="students">
            Students ({filteredStudents.length})
          </TabsTrigger>
          <TabsTrigger value="teachers">
            Teachers ({filteredTeachers.length})
          </TabsTrigger>
          <TabsTrigger value="admins">
            Admins ({filteredAdmins.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="students" className="space-y-4 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredStudents.map((student, index) => (
              <motion.div
                key={student.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <img src={student.avatar} alt={student.name} className="w-12 h-12 rounded-full" />
                        <div>
                          <h3 className="font-semibold">{student.name}</h3>
                          <p className="text-sm text-gray-600 flex items-center gap-1">
                            <Mail className="w-3 h-3" />
                            {student.email}
                          </p>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700 hover:bg-red-50">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Average:</span>
                        <span className="font-semibold">{student.overallAverage}%</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Attendance:</span>
                        <span className="font-semibold">{student.attendance}%</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Subjects:</span>
                        <span className="font-semibold">{student.subjects.length}</span>
                      </div>
                    </div>
                    <div className="mt-4 flex flex-wrap gap-1">
                      {student.subjects.slice(0, 3).map(subjectId => {
                        const subject = subjects.find(s => s.id === subjectId);
                        return subject ? (
                          <Badge key={subject.id} variant="outline" className="text-xs">
                            {subject.code}
                          </Badge>
                        ) : null;
                      })}
                      {student.subjects.length > 3 && (
                        <Badge variant="outline" className="text-xs">
                          +{student.subjects.length - 3} more
                        </Badge>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="teachers" className="space-y-4 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredTeachers.map((teacher, index) => (
              <motion.div
                key={teacher.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <img src={teacher.avatar} alt={teacher.name} className="w-12 h-12 rounded-full" />
                        <div>
                          <h3 className="font-semibold">{teacher.name}</h3>
                          <p className="text-sm text-gray-600 flex items-center gap-1">
                            <Mail className="w-3 h-3" />
                            {teacher.email}
                          </p>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700 hover:bg-red-50">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Subjects:</span>
                        <span className="font-semibold">{teacher.subjects.length}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Classes:</span>
                        <span className="font-semibold">{teacher.classes.length}</span>
                      </div>
                    </div>
                    <div className="mt-4 space-y-2">
                      <p className="text-xs text-gray-600 font-medium">Teaching:</p>
                      <div className="flex flex-wrap gap-1">
                        {teacher.subjects.map(subjectId => {
                          const subject = subjects.find(s => s.id === subjectId);
                          return subject ? (
                            <Badge key={subject.id} style={{ backgroundColor: subject.color }} className="text-white text-xs">
                              {subject.name}
                            </Badge>
                          ) : null;
                        })}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="admins" className="space-y-4 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredAdmins.map((admin, index) => (
              <motion.div
                key={admin.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card className="hover:shadow-lg transition-shadow border-2 border-purple-200">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="relative">
                          <img src={admin.avatar} alt={admin.name} className="w-12 h-12 rounded-full" />
                          <div className="absolute -bottom-1 -right-1 bg-purple-600 rounded-full p-1">
                            <Shield className="w-3 h-3 text-white" />
                          </div>
                        </div>
                        <div>
                          <h3 className="font-semibold">{admin.name}</h3>
                          <p className="text-sm text-gray-600 flex items-center gap-1">
                            <Mail className="w-3 h-3" />
                            {admin.email}
                          </p>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700 hover:bg-red-50">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                    <div className="mt-4">
                      <Badge className="bg-purple-100 text-purple-800">
                        <Shield className="w-3 h-3 mr-1" />
                        Full Access
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
