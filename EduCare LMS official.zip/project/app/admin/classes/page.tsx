'use client';

import { useState } from 'react';
import { useAppData } from '@/lib/context/AppDataContext';
import { AdminPageHeader } from '@/components/admin/AdminPageHeader';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Plus, Users, TrendingUp, BarChart3, UserCheck, Edit } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function AdminClassesPage() {
  const { classes, students, teachers, subjects, marks, addClass } = useAppData();
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showAnalyticsModal, setShowAnalyticsModal] = useState(false);
  const [selectedClass, setSelectedClass] = useState<any>(null);

  const [newClass, setNewClass] = useState({
    name: '',
    selectedTeacher: '',
    selectedSubjects: [] as string[],
    selectedStudents: [] as string[]
  });

  const handleCreateClass = () => {
    if (!newClass.name || !newClass.selectedTeacher) {
      toast.error('Please fill in all required fields');
      return;
    }

    addClass({
      name: newClass.name,
      grade: '10',
      teachers: [newClass.selectedTeacher],
      subjects: newClass.selectedSubjects,
      students: newClass.selectedStudents
    });

    toast.success('Class created successfully!');
    setShowCreateModal(false);
    setNewClass({
      name: '',
      selectedTeacher: '',
      selectedSubjects: [],
      selectedStudents: []
    });
  };

  const getClassAnalytics = (classItem: any) => {
    const classStudents = students.filter(s => classItem.students.includes(s.id));
    const avg = classStudents.reduce((acc, s) => acc + s.overallAverage, 0) / (classStudents.length || 1);
    const attendance = classStudents.reduce((acc, s) => acc + s.attendance, 0) / (classStudents.length || 1);

    const subjectData = classItem.subjects.map((subjectId: string) => {
      const subject = subjects.find(s => s.id === subjectId);
      const subjectMarks = marks.filter(m =>
        m.subjectId === subjectId &&
        classStudents.some(s => s.id === m.studentId)
      );
      const subjectAvg = subjectMarks.length > 0
        ? subjectMarks.reduce((acc, m) => acc + (m.score / m.maxScore) * 100, 0) / subjectMarks.length
        : 0;

      return {
        name: subject?.name || 'Unknown',
        average: Math.round(subjectAvg)
      };
    });

    return {
      average: Math.round(avg),
      attendance: Math.round(attendance),
      studentCount: classStudents.length,
      subjectData
    };
  };

  const viewAnalytics = (classItem: any) => {
    setSelectedClass(classItem);
    setShowAnalyticsModal(true);
  };

  return (
    <div className="p-8 space-y-6">
      <AdminPageHeader
        title="Class Management"
        description="Create and manage classes and sections"
        rightContent={
        <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              Create Class
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create New Class</DialogTitle>
              <DialogDescription>Set up a new class with teacher and students</DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Class Name</Label>
                <Input
                  placeholder="e.g., Grade 10A"
                  value={newClass.name}
                  onChange={(e) => setNewClass({ ...newClass, name: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label>Assign Teacher</Label>
                <Select value={newClass.selectedTeacher} onValueChange={(value) => setNewClass({ ...newClass, selectedTeacher: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a teacher" />
                  </SelectTrigger>
                  <SelectContent>
                    {teachers.map(teacher => (
                      <SelectItem key={teacher.id} value={teacher.id}>
                        {teacher.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Subjects</Label>
                <div className="border rounded-lg p-3 space-y-2 max-h-40 overflow-y-auto">
                  {subjects.map(subject => (
                    <label key={subject.id} className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={newClass.selectedSubjects.includes(subject.id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setNewClass({
                              ...newClass,
                              selectedSubjects: [...newClass.selectedSubjects, subject.id]
                            });
                          } else {
                            setNewClass({
                              ...newClass,
                              selectedSubjects: newClass.selectedSubjects.filter(id => id !== subject.id)
                            });
                          }
                        }}
                        className="rounded"
                      />
                      <span>{subject.name}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label>Assign Students</Label>
                <div className="border rounded-lg p-3 space-y-2 max-h-60 overflow-y-auto">
                  {students.map(student => (
                    <label key={student.id} className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={newClass.selectedStudents.includes(student.id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setNewClass({
                              ...newClass,
                              selectedStudents: [...newClass.selectedStudents, student.id]
                            });
                          } else {
                            setNewClass({
                              ...newClass,
                              selectedStudents: newClass.selectedStudents.filter(id => id !== student.id)
                            });
                          }
                        }}
                        className="rounded"
                      />
                      <div className="flex items-center gap-2">
                        <img src={student.avatar} alt={student.name} className="w-6 h-6 rounded-full" />
                        <span>{student.name}</span>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              <Button onClick={handleCreateClass} className="w-full">
                Create Class
              </Button>
            </div>
          </DialogContent>
        </Dialog>
        }
      />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Classes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">{classes.length}</div>
            <p className="text-sm text-gray-600 mt-1">Active classes</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Students</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">{students.length}</div>
            <p className="text-sm text-gray-600 mt-1">Enrolled students</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Teachers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-purple-600">{teachers.length}</div>
            <p className="text-sm text-gray-600 mt-1">Active teachers</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {classes.map((classItem, index) => {
          const analytics = getClassAnalytics(classItem);
          const teacher = teachers.find(t => classItem.teachers?.includes(t.id));

          return (
            <motion.div
              key={classItem.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <Card className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-xl">{classItem.name}</CardTitle>
                      <p className="text-sm text-gray-600 mt-1 flex items-center gap-1">
                        <Users className="w-4 h-4" />
                        {teacher?.name || 'No teacher assigned'}
                      </p>
                    </div>
                    <Button variant="ghost" size="sm">
                      <Edit className="w-4 h-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-600">{analytics.studentCount}</div>
                      <div className="text-xs text-gray-600">Students</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600">{analytics.average}%</div>
                      <div className="text-xs text-gray-600">Average</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-purple-600">{analytics.attendance}%</div>
                      <div className="text-xs text-gray-600">Attendance</div>
                    </div>
                  </div>

                  <div>
                    <p className="text-xs text-gray-600 font-medium mb-2">Subjects:</p>
                    <div className="flex flex-wrap gap-1">
                      {classItem.subjects.map((subjectId: string) => {
                        const subject = subjects.find(s => s.id === subjectId);
                        return subject ? (
                          <Badge key={subject.id} variant="outline" className="text-xs">
                            {subject.code}
                          </Badge>
                        ) : null;
                      })}
                    </div>
                  </div>

                  <Button
                    onClick={() => viewAnalytics(classItem)}
                    variant="outline"
                    className="w-full gap-2"
                  >
                    <BarChart3 className="w-4 h-4" />
                    View Analytics
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {selectedClass && (
        <Dialog open={showAnalyticsModal} onOpenChange={setShowAnalyticsModal}>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle>{selectedClass.name} - Analytics</DialogTitle>
              <DialogDescription>Detailed performance metrics and insights</DialogDescription>
            </DialogHeader>
            <div className="space-y-6 py-4">
              {(() => {
                const analytics = getClassAnalytics(selectedClass);
                const classStudents = students.filter(s => selectedClass.students.includes(s.id));
                const teacher = teachers.find(t => selectedClass.teachers?.includes(t.id));

                return (
                  <>
                    <div className="grid grid-cols-3 gap-4">
                      <Card>
                        <CardContent className="pt-6 text-center">
                          <Users className="w-8 h-8 mx-auto text-blue-600 mb-2" />
                          <div className="text-2xl font-bold">{analytics.studentCount}</div>
                          <div className="text-sm text-gray-600">Students</div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="pt-6 text-center">
                          <TrendingUp className="w-8 h-8 mx-auto text-green-600 mb-2" />
                          <div className="text-2xl font-bold">{analytics.average}%</div>
                          <div className="text-sm text-gray-600">Class Average</div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="pt-6 text-center">
                          <UserCheck className="w-8 h-8 mx-auto text-purple-600 mb-2" />
                          <div className="text-2xl font-bold">{analytics.attendance}%</div>
                          <div className="text-sm text-gray-600">Attendance</div>
                        </CardContent>
                      </Card>
                    </div>

                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">Subject Performance</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ResponsiveContainer width="100%" height={250}>
                          <BarChart data={analytics.subjectData}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="name" />
                            <YAxis domain={[0, 100]} />
                            <Tooltip />
                            <Bar dataKey="average" fill="#8b5cf6" />
                          </BarChart>
                        </ResponsiveContainer>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">Student Roster</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2 max-h-60 overflow-y-auto">
                          {classStudents.map((student, idx) => (
                            <div key={student.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                              <div className="flex items-center gap-3">
                                <span className="text-gray-500 font-medium">#{idx + 1}</span>
                                <img src={student.avatar} alt={student.name} className="w-8 h-8 rounded-full" />
                                <div>
                                  <div className="font-medium">{student.name}</div>
                                  <div className="text-sm text-gray-600">{student.email}</div>
                                </div>
                              </div>
                              <div className="text-right">
                                <div className="font-bold">{student.overallAverage}%</div>
                                <div className="text-sm text-gray-600">{student.attendance}% attend</div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>

                    <div className="bg-blue-50 p-4 rounded-lg">
                      <p className="font-medium text-blue-900">Class Teacher:</p>
                      <p className="text-blue-700">{teacher?.name || 'Not assigned'}</p>
                    </div>
                  </>
                );
              })()}
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
