'use client';

import { useState } from 'react';
import { useAppData } from '@/lib/context/AppDataContext';
import { AdminPageHeader } from '@/components/admin/AdminPageHeader';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Plus, BookOpen, Users, Edit, Trash2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';

const SUBJECT_COLORS = [
  '#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6',
  '#06b6d4', '#ec4899', '#14b8a6', '#f97316', '#6366f1'
];

export default function AdminSubjectsPage() {
  const { subjects, teachers, classes, students, marks, addSubject } = useAppData();
  const [showCreateModal, setShowCreateModal] = useState(false);

  const [newSubject, setNewSubject] = useState({
    name: '',
    code: '',
    teacherId: '',
    color: SUBJECT_COLORS[0]
  });

  const handleCreateSubject = () => {
    if (!newSubject.name || !newSubject.code || !newSubject.teacherId) {
      toast.error('Please fill in all required fields');
      return;
    }

    const teacher = teachers.find(t => t.id === newSubject.teacherId);

    addSubject({
      name: newSubject.name,
      code: newSubject.code,
      teacherId: newSubject.teacherId,
      teacherName: teacher?.name || 'Unknown',
      color: newSubject.color
    });

    toast.success('Subject created successfully!');
    setShowCreateModal(false);
    setNewSubject({
      name: '',
      code: '',
      teacherId: '',
      color: SUBJECT_COLORS[Math.floor(Math.random() * SUBJECT_COLORS.length)]
    });
  };

  const getSubjectStats = (subjectId: string) => {
    const linkedClasses = classes.filter(c => c.subjects.includes(subjectId));
    const enrolledStudents = students.filter(s => s.subjects.includes(subjectId));
    const subjectMarks = marks.filter(m => m.subjectId === subjectId);
    const avgScore = subjectMarks.length > 0
      ? subjectMarks.reduce((acc, m) => acc + (m.score / m.maxScore) * 100, 0) / subjectMarks.length
      : 0;

    return {
      classCount: linkedClasses.length,
      studentCount: enrolledStudents.length,
      averageScore: Math.round(avgScore)
    };
  };

  return (
    <div className="p-8 space-y-6">
      <AdminPageHeader
        title="Subject Management"
        description="Create and manage subjects and curriculum"
        rightContent={
          <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              Create Subject
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Subject</DialogTitle>
              <DialogDescription>Add a new subject to the curriculum</DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Subject Name</Label>
                <Input
                  placeholder="e.g., Advanced Physics"
                  value={newSubject.name}
                  onChange={(e) => setNewSubject({ ...newSubject, name: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label>Subject Code</Label>
                <Input
                  placeholder="e.g., PHY101"
                  value={newSubject.code}
                  onChange={(e) => setNewSubject({ ...newSubject, code: e.target.value.toUpperCase() })}
                />
              </div>

              <div className="space-y-2">
                <Label>Assign Teacher</Label>
                <Select value={newSubject.teacherId} onValueChange={(value) => setNewSubject({ ...newSubject, teacherId: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a teacher" />
                  </SelectTrigger>
                  <SelectContent>
                    {teachers.map(teacher => (
                      <SelectItem key={teacher.id} value={teacher.id}>
                        {teacher.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Subject Color</Label>
                <div className="flex gap-2 flex-wrap">
                  {SUBJECT_COLORS.map(color => (
                    <button
                      key={color}
                      onClick={() => setNewSubject({ ...newSubject, color })}
                      className={`w-10 h-10 rounded-lg border-2 transition-all ${
                        newSubject.color === color ? 'border-gray-900 scale-110' : 'border-gray-300'
                      }`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>

              <Button onClick={handleCreateSubject} className="w-full">
                Create Subject
              </Button>
            </div>
          </DialogContent>
          </Dialog>
        }
      />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Subjects</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">{subjects.length}</div>
            <p className="text-sm text-gray-600 mt-1">Active subjects</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Teachers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">{teachers.length}</div>
            <p className="text-sm text-gray-600 mt-1">Assigned teachers</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Avg Enrollment</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-purple-600">
              {Math.round(subjects.reduce((acc, s) => acc + getSubjectStats(s.id).studentCount, 0) / (subjects.length || 1))}
            </div>
            <p className="text-sm text-gray-600 mt-1">Students per subject</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {subjects.map((subject, index) => {
          const stats = getSubjectStats(subject.id);
          const linkedClasses = classes.filter(c => c.subjects.includes(subject.id));

          return (
            <motion.div
              key={subject.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <Card className="hover:shadow-lg transition-shadow border-t-4" style={{ borderTopColor: subject.color }}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-12 h-12 rounded-lg flex items-center justify-center text-white font-bold"
                        style={{ backgroundColor: subject.color }}
                      >
                        <BookOpen className="w-6 h-6" />
                      </div>
                      <div>
                        <CardTitle className="text-lg">{subject.name}</CardTitle>
                        <Badge variant="outline" className="mt-1">{subject.code}</Badge>
                      </div>
                    </div>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="sm">
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700 hover:bg-red-50">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <p className="text-sm text-gray-600 mb-1">Teacher</p>
                    <p className="font-medium">{subject.teacherName}</p>
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-600">{stats.classCount}</div>
                      <div className="text-xs text-gray-600">Classes</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600">{stats.studentCount}</div>
                      <div className="text-xs text-gray-600">Students</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-purple-600">{stats.averageScore}%</div>
                      <div className="text-xs text-gray-600">Avg Score</div>
                    </div>
                  </div>

                  {linkedClasses.length > 0 && (
                    <div>
                      <p className="text-xs text-gray-600 font-medium mb-2">Linked Classes:</p>
                      <div className="flex flex-wrap gap-1">
                        {linkedClasses.map(cls => (
                          <Badge key={cls.id} variant="secondary" className="text-xs">
                            {cls.name}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {linkedClasses.length === 0 && (
                    <div className="bg-yellow-50 p-2 rounded-lg text-xs text-yellow-800">
                      Not linked to any class yet
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
