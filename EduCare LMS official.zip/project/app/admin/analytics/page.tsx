'use client';

import { useAppData } from '@/lib/context/AppDataContext';
import { AdminPageHeader } from '@/components/admin/AdminPageHeader';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Download, TrendingUp, TrendingDown, AlertTriangle, Users, BookOpen, Award } from 'lucide-react';
import { motion } from 'framer-motion';
import { Badge } from '@/components/ui/badge';

export default function AdminAnalyticsPage() {
  const { students, subjects, classes, marks } = useAppData();

  const schoolAverage = students.reduce((acc, s) => acc + s.overallAverage, 0) / (students.length || 1);
  const schoolAttendance = students.reduce((acc, s) => acc + s.attendance, 0) / (students.length || 1);

  const monthlyAttendanceData = [
    { month: 'Sep', attendance: 92 },
    { month: 'Oct', attendance: 89 },
    { month: 'Nov', attendance: 91 },
    { month: 'Dec', attendance: 87 },
    { month: 'Jan', attendance: 90 },
    { month: 'Feb', attendance: schoolAttendance }
  ];

  const monthlyAverageData = [
    { month: 'Sep', average: 72 },
    { month: 'Oct', average: 74 },
    { month: 'Nov', average: 76 },
    { month: 'Dec', average: 75 },
    { month: 'Jan', average: 78 },
    { month: 'Feb', average: schoolAverage }
  ];

  const subjectPerformance = subjects.map(subject => {
    const subjectMarks = marks.filter(m => m.subjectId === subject.id);
    const avg = subjectMarks.length > 0
      ? subjectMarks.reduce((acc, m) => acc + (m.score / m.maxScore) * 100, 0) / subjectMarks.length
      : 0;
    return { name: subject.name, average: Math.round(avg) };
  });

  const teacherPerformance = classes.map(cls => {
    const teacher = subjects.find(s => cls.subjects.includes(s.id));
    const classStudents = students.filter(s => cls.students.includes(s.id));
    const avg = classStudents.reduce((acc, s) => acc + s.overallAverage, 0) / (classStudents.length || 1);
    return {
      teacher: teacher?.teacherName || 'Unknown',
      class: cls.name,
      average: Math.round(avg),
      students: classStudents.length
    };
  }).sort((a, b) => b.average - a.average);

  const classRanking = classes.map(cls => {
    const classStudents = students.filter(s => cls.students.includes(s.id));
    const avg = classStudents.reduce((acc, s) => acc + s.overallAverage, 0) / (classStudents.length || 1);
    const attendance = classStudents.reduce((acc, s) => acc + s.attendance, 0) / (classStudents.length || 1);
    return {
      name: cls.name,
      average: Math.round(avg),
      attendance: Math.round(attendance),
      students: classStudents.length
    };
  }).sort((a, b) => b.average - a.average);

  const underperformingStudents = students
    .filter(s => s.overallAverage < 70 || s.attendance < 85)
    .sort((a, b) => a.overallAverage - b.overallAverage)
    .slice(0, 10);

  const handleExportReport = () => {
    alert('Report exported successfully! (Demo functionality)');
  };

  return (
    <div className="p-8 space-y-6">
      <AdminPageHeader
        title="Analytics Dashboard"
        description="Comprehensive school performance insights"
        rightContent={
          <Button onClick={handleExportReport} className="gap-2">
            <Download className="w-4 h-4" />
            Export Report
          </Button>
        }
      />

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">School Average</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">{Math.round(schoolAverage)}%</div>
            <div className="flex items-center gap-1 mt-2 text-sm text-green-600">
              <TrendingUp className="w-4 h-4" />
              <span>+3% from last month</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Attendance Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">{Math.round(schoolAttendance)}%</div>
            <div className="flex items-center gap-1 mt-2 text-sm text-green-600">
              <TrendingUp className="w-4 h-4" />
              <span>+1% from last month</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Students</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-purple-600">{students.length}</div>
            <div className="flex items-center gap-1 mt-2 text-sm text-gray-600">
              <Users className="w-4 h-4" />
              <span>Across {classes.length} classes</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Subjects</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-orange-600">{subjects.length}</div>
            <div className="flex items-center gap-1 mt-2 text-sm text-gray-600">
              <BookOpen className="w-4 h-4" />
              <span>Active subjects</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>School Average Trend</CardTitle>
            <CardDescription>Monthly performance overview</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={monthlyAverageData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis domain={[0, 100]} />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="average" stroke="#3b82f6" strokeWidth={2} name="Average %" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Attendance Trend</CardTitle>
            <CardDescription>Monthly attendance rates</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={monthlyAttendanceData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis domain={[0, 100]} />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="attendance" stroke="#10b981" strokeWidth={2} name="Attendance %" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Subject Performance Comparison</CardTitle>
          <CardDescription>Average performance by subject</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={subjectPerformance}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis domain={[0, 100]} />
              <Tooltip />
              <Legend />
              <Bar dataKey="average" fill="#8b5cf6" name="Average %" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Class Rankings</CardTitle>
            <CardDescription>Top performing classes</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {classRanking.slice(0, 5).map((cls, index) => (
                <motion.div
                  key={cls.name}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      index === 0 ? 'bg-yellow-500' : index === 1 ? 'bg-gray-400' : index === 2 ? 'bg-orange-600' : 'bg-blue-500'
                    } text-white font-bold`}>
                      {index + 1}
                    </div>
                    <div>
                      <div className="font-semibold">{cls.name}</div>
                      <div className="text-sm text-gray-600">{cls.students} students</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-lg">{cls.average}%</div>
                    <div className="text-sm text-gray-600">{cls.attendance}% attend.</div>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-500" />
              Underperforming Students
            </CardTitle>
            <CardDescription>Students requiring attention</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {underperformingStudents.slice(0, 8).map((student, index) => (
                <motion.div
                  key={student.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="flex items-center justify-between p-2 hover:bg-gray-50 rounded-lg"
                >
                  <div className="flex items-center gap-3">
                    <img src={student.avatar} alt={student.name} className="w-8 h-8 rounded-full" />
                    <div>
                      <div className="font-medium">{student.name}</div>
                      <div className="text-sm text-gray-600">{student.email}</div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    {student.overallAverage < 70 && (
                      <Badge variant="destructive" className="text-xs">
                        {student.overallAverage}% avg
                      </Badge>
                    )}
                    {student.attendance < 85 && (
                      <Badge variant="outline" className="text-xs text-orange-600 border-orange-600">
                        {student.attendance}% attend
                      </Badge>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Teacher Performance Overview</CardTitle>
          <CardDescription>Class performance by teacher</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-4 font-semibold text-gray-700">Rank</th>
                  <th className="text-left py-3 px-4 font-semibold text-gray-700">Teacher</th>
                  <th className="text-left py-3 px-4 font-semibold text-gray-700">Class</th>
                  <th className="text-center py-3 px-4 font-semibold text-gray-700">Students</th>
                  <th className="text-right py-3 px-4 font-semibold text-gray-700">Average</th>
                  <th className="text-right py-3 px-4 font-semibold text-gray-700">Status</th>
                </tr>
              </thead>
              <tbody>
                {teacherPerformance.slice(0, 10).map((teacher, index) => (
                  <motion.tr
                    key={index}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: index * 0.05 }}
                    className="border-b hover:bg-gray-50"
                  >
                    <td className="py-3 px-4">
                      {index < 3 ? (
                        <Award className={`w-5 h-5 ${
                          index === 0 ? 'text-yellow-500' : index === 1 ? 'text-gray-400' : 'text-orange-600'
                        }`} />
                      ) : (
                        <span className="text-gray-600">#{index + 1}</span>
                      )}
                    </td>
                    <td className="py-3 px-4 font-medium">{teacher.teacher}</td>
                    <td className="py-3 px-4 text-gray-600">{teacher.class}</td>
                    <td className="py-3 px-4 text-center text-gray-600">{teacher.students}</td>
                    <td className="py-3 px-4 text-right font-bold">{teacher.average}%</td>
                    <td className="py-3 px-4 text-right">
                      {teacher.average >= 80 ? (
                        <Badge className="bg-green-100 text-green-800">Excellent</Badge>
                      ) : teacher.average >= 70 ? (
                        <Badge className="bg-blue-100 text-blue-800">Good</Badge>
                      ) : (
                        <Badge className="bg-orange-100 text-orange-800">Needs Support</Badge>
                      )}
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
