'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { AdminPageHeader } from '@/components/admin/AdminPageHeader';
import { School, Upload, Save, Bell, Palette, Calendar, Award } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';

export default function AdminSettingsPage() {
  const [settings, setSettings] = useState({
    schoolName: 'Springfield High School',
    schoolLogo: '/white_logo.png',
    academicYear: '2023-2024',
    gradeThresholds: {
      aPlus: 90,
      a: 80,
      b: 70,
      c: 60,
      d: 50
    },
    theme: 'light',
    notifications: {
      emailNotifications: true,
      pushNotifications: true,
      weeklyReports: true,
      eventReminders: true
    }
  });

  const handleSave = () => {
    toast.success('Settings saved successfully!');
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      toast.success('Logo uploaded successfully! (Demo)');
    }
  };

  return (
    <div className="p-8 space-y-6">
      <AdminPageHeader
        title="Settings"
        description="Configure school settings and preferences"
        rightContent={
          <Button onClick={handleSave} className="gap-2">
            <Save className="w-4 h-4" />
            Save Changes
          </Button>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <School className="w-5 h-5" />
              School Information
            </CardTitle>
            <CardDescription>Basic school details and branding</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label>School Name</Label>
              <Input
                value={settings.schoolName}
                onChange={(e) => setSettings({ ...settings, schoolName: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label>School Logo</Label>
              <div className="flex items-center gap-4">
                <div className="w-20 h-20 bg-gray-100 rounded-lg flex items-center justify-center">
                  <img src={settings.schoolLogo} alt="School Logo" className="max-w-full max-h-full" />
                </div>
                <div className="flex-1">
                  <Input
                    type="file"
                    accept="image/*"
                    onChange={handleLogoUpload}
                  />
                  <p className="text-sm text-gray-500 mt-1">Recommended: 200x200px, PNG or JPG</p>
                </div>
              </div>
            </div>

            <Separator />

            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                Academic Year
              </Label>
              <Select
                value={settings.academicYear}
                onValueChange={(value) => setSettings({ ...settings, academicYear: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="2023-2024">2023-2024</SelectItem>
                  <SelectItem value="2024-2025">2024-2025</SelectItem>
                  <SelectItem value="2025-2026">2025-2026</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Palette className="w-5 h-5" />
              Appearance
            </CardTitle>
            <CardDescription>Customize the look and feel</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Theme</Label>
              <Select
                value={settings.theme}
                onValueChange={(value) => setSettings({ ...settings, theme: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="light">Light</SelectItem>
                  <SelectItem value="dark">Dark</SelectItem>
                  <SelectItem value="auto">Auto</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="text-sm text-blue-800">
                Theme changes will apply to all users on their next login
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="w-5 h-5" />
              Grade Thresholds
            </CardTitle>
            <CardDescription>Configure grading scale and thresholds</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>A+ (Excellent)</Label>
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    value={settings.gradeThresholds.aPlus}
                    onChange={(e) => setSettings({
                      ...settings,
                      gradeThresholds: { ...settings.gradeThresholds, aPlus: Number(e.target.value) }
                    })}
                    min={0}
                    max={100}
                  />
                  <span className="text-gray-600">%</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label>A (Very Good)</Label>
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    value={settings.gradeThresholds.a}
                    onChange={(e) => setSettings({
                      ...settings,
                      gradeThresholds: { ...settings.gradeThresholds, a: Number(e.target.value) }
                    })}
                    min={0}
                    max={100}
                  />
                  <span className="text-gray-600">%</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label>B (Good)</Label>
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    value={settings.gradeThresholds.b}
                    onChange={(e) => setSettings({
                      ...settings,
                      gradeThresholds: { ...settings.gradeThresholds, b: Number(e.target.value) }
                    })}
                    min={0}
                    max={100}
                  />
                  <span className="text-gray-600">%</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label>C (Satisfactory)</Label>
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    value={settings.gradeThresholds.c}
                    onChange={(e) => setSettings({
                      ...settings,
                      gradeThresholds: { ...settings.gradeThresholds, c: Number(e.target.value) }
                    })}
                    min={0}
                    max={100}
                  />
                  <span className="text-gray-600">%</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label>D (Pass)</Label>
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    value={settings.gradeThresholds.d}
                    onChange={(e) => setSettings({
                      ...settings,
                      gradeThresholds: { ...settings.gradeThresholds, d: Number(e.target.value) }
                    })}
                    min={0}
                    max={100}
                  />
                  <span className="text-gray-600">%</span>
                </div>
              </div>

              <div className="space-y-2 flex items-center">
                <div className="bg-red-50 p-3 rounded-lg text-sm text-red-800">
                  Below {settings.gradeThresholds.d}% = F (Fail)
                </div>
              </div>
            </div>

            <div className="mt-6 p-4 bg-gray-50 rounded-lg">
              <p className="text-sm font-medium text-gray-900 mb-2">Grade Scale Preview:</p>
              <div className="flex gap-2 flex-wrap">
                <div className="px-3 py-1 bg-green-600 text-white rounded font-medium text-sm">
                  A+ ({settings.gradeThresholds.aPlus}%+)
                </div>
                <div className="px-3 py-1 bg-green-500 text-white rounded font-medium text-sm">
                  A ({settings.gradeThresholds.a}-{settings.gradeThresholds.aPlus - 1}%)
                </div>
                <div className="px-3 py-1 bg-blue-500 text-white rounded font-medium text-sm">
                  B ({settings.gradeThresholds.b}-{settings.gradeThresholds.a - 1}%)
                </div>
                <div className="px-3 py-1 bg-yellow-500 text-white rounded font-medium text-sm">
                  C ({settings.gradeThresholds.c}-{settings.gradeThresholds.b - 1}%)
                </div>
                <div className="px-3 py-1 bg-orange-500 text-white rounded font-medium text-sm">
                  D ({settings.gradeThresholds.d}-{settings.gradeThresholds.c - 1}%)
                </div>
                <div className="px-3 py-1 bg-red-500 text-white rounded font-medium text-sm">
                  F (&lt;{settings.gradeThresholds.d}%)
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="w-5 h-5" />
              Notifications
            </CardTitle>
            <CardDescription>Manage notification preferences</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label>Email Notifications</Label>
                <p className="text-sm text-gray-500">Receive email updates</p>
              </div>
              <Switch
                checked={settings.notifications.emailNotifications}
                onCheckedChange={(checked) => setSettings({
                  ...settings,
                  notifications: { ...settings.notifications, emailNotifications: checked }
                })}
              />
            </div>

            <Separator />

            <div className="flex items-center justify-between">
              <div>
                <Label>Push Notifications</Label>
                <p className="text-sm text-gray-500">Browser notifications</p>
              </div>
              <Switch
                checked={settings.notifications.pushNotifications}
                onCheckedChange={(checked) => setSettings({
                  ...settings,
                  notifications: { ...settings.notifications, pushNotifications: checked }
                })}
              />
            </div>

            <Separator />

            <div className="flex items-center justify-between">
              <div>
                <Label>Weekly Reports</Label>
                <p className="text-sm text-gray-500">Automated summaries</p>
              </div>
              <Switch
                checked={settings.notifications.weeklyReports}
                onCheckedChange={(checked) => setSettings({
                  ...settings,
                  notifications: { ...settings.notifications, weeklyReports: checked }
                })}
              />
            </div>

            <Separator />

            <div className="flex items-center justify-between">
              <div>
                <Label>Event Reminders</Label>
                <p className="text-sm text-gray-500">Upcoming events</p>
              </div>
              <Switch
                checked={settings.notifications.eventReminders}
                onCheckedChange={(checked) => setSettings({
                  ...settings,
                  notifications: { ...settings.notifications, eventReminders: checked }
                })}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-red-600">Danger Zone</CardTitle>
          <CardDescription>Irreversible actions - proceed with caution</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between p-4 border border-red-200 rounded-lg bg-red-50">
            <div>
              <p className="font-medium text-red-900">Reset All Data</p>
              <p className="text-sm text-red-700">This will permanently delete all user data</p>
            </div>
            <Button variant="destructive" disabled>
              Reset (Demo)
            </Button>
          </div>
          <div className="flex items-center justify-between p-4 border border-red-200 rounded-lg bg-red-50">
            <div>
              <p className="font-medium text-red-900">Export Database</p>
              <p className="text-sm text-red-700">Download a complete backup of all data</p>
            </div>
            <Button variant="outline" onClick={() => toast.success('Export started! (Demo)')}>
              Export
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
