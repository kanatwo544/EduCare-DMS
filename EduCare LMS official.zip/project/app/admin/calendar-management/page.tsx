'use client';

import { useState } from 'react';
import { useAppData } from '@/lib/context/AppDataContext';
import { AdminPageHeader } from '@/components/admin/AdminPageHeader';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, Calendar, Check, X, Clock, AlertCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { format } from 'date-fns';

export default function CalendarManagementPage() {
  const { calendarEvents, subjects, addCalendarEvent, updateCalendarEvent } = useAppData();
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedTab, setSelectedTab] = useState('all');

  const [newEvent, setNewEvent] = useState({
    title: '',
    description: '',
    date: '',
    endDate: '',
    type: 'event' as 'exam' | 'assignment' | 'event' | 'holiday',
    subjectId: ''
  });

  const handleCreateEvent = () => {
    if (!newEvent.title || !newEvent.date || !newEvent.type) {
      toast.error('Please fill in all required fields');
      return;
    }

    const eventColor = newEvent.type === 'exam' ? '#ef4444' :
                      newEvent.type === 'assignment' ? '#f59e0b' :
                      newEvent.type === 'holiday' ? '#10b981' : '#3b82f6';

    addCalendarEvent({
      title: newEvent.title,
      description: newEvent.description,
      date: newEvent.date,
      endDate: newEvent.endDate || undefined,
      type: newEvent.type,
      subjectId: newEvent.subjectId || undefined,
      color: eventColor,
      status: 'approved'
    });

    toast.success('Event created successfully!');
    setShowCreateModal(false);
    setNewEvent({
      title: '',
      description: '',
      date: '',
      endDate: '',
      type: 'event',
      subjectId: ''
    });
  };

  const handleApprove = (eventId: string) => {
    updateCalendarEvent(eventId, { status: 'approved' });
    toast.success('Event approved!');
  };

  const handleReject = (eventId: string) => {
    updateCalendarEvent(eventId, { status: 'rejected' });
    toast.error('Event rejected');
  };

  const pendingEvents = calendarEvents.filter(e => e.status === 'pending');
  const approvedEvents = calendarEvents.filter(e => e.status === 'approved' || !e.status);
  const rejectedEvents = calendarEvents.filter(e => e.status === 'rejected');

  const getStatusBadge = (status?: string) => {
    if (status === 'pending') {
      return <Badge className="bg-yellow-100 text-yellow-800"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
    }
    if (status === 'rejected') {
      return <Badge variant="destructive"><X className="w-3 h-3 mr-1" />Rejected</Badge>;
    }
    return <Badge className="bg-green-100 text-green-800"><Check className="w-3 h-3 mr-1" />Approved</Badge>;
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'exam': return 'bg-red-100 text-red-800';
      case 'assignment': return 'bg-orange-100 text-orange-800';
      case 'holiday': return 'bg-green-100 text-green-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  return (
    <div className="p-8 space-y-6">
      <AdminPageHeader
        title="Calendar Management"
        description="Manage school events and approve proposals"
        rightContent={
          <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              Add Event
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create School Event</DialogTitle>
              <DialogDescription>Add a new event to the school calendar</DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Event Title</Label>
                <Input
                  placeholder="e.g., Annual Sports Day"
                  value={newEvent.title}
                  onChange={(e) => setNewEvent({ ...newEvent, title: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label>Description</Label>
                <Textarea
                  placeholder="Event details..."
                  value={newEvent.description}
                  onChange={(e) => setNewEvent({ ...newEvent, description: e.target.value })}
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label>Event Type</Label>
                <Select value={newEvent.type} onValueChange={(value: any) => setNewEvent({ ...newEvent, type: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="event">General Event</SelectItem>
                    <SelectItem value="exam">Exam</SelectItem>
                    <SelectItem value="assignment">Assignment</SelectItem>
                    <SelectItem value="holiday">Holiday</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {(newEvent.type === 'exam' || newEvent.type === 'assignment') && (
                <div className="space-y-2">
                  <Label>Subject (Optional)</Label>
                  <Select value={newEvent.subjectId} onValueChange={(value) => setNewEvent({ ...newEvent, subjectId: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a subject" />
                    </SelectTrigger>
                    <SelectContent>
                      {subjects.map(subject => (
                        <SelectItem key={subject.id} value={subject.id}>
                          {subject.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Start Date</Label>
                  <Input
                    type="date"
                    value={newEvent.date}
                    onChange={(e) => setNewEvent({ ...newEvent, date: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>End Date (Optional)</Label>
                  <Input
                    type="date"
                    value={newEvent.endDate}
                    onChange={(e) => setNewEvent({ ...newEvent, endDate: e.target.value })}
                  />
                </div>
              </div>

              <Button onClick={handleCreateEvent} className="w-full">
                Create Event
              </Button>
            </div>
          </DialogContent>
          </Dialog>
        }
      />

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Events</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">{calendarEvents.length}</div>
            <p className="text-sm text-gray-600 mt-1">All calendar events</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Pending</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-yellow-600">{pendingEvents.length}</div>
            <p className="text-sm text-gray-600 mt-1">Awaiting approval</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Approved</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">{approvedEvents.length}</div>
            <p className="text-sm text-gray-600 mt-1">Active events</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Rejected</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-red-600">{rejectedEvents.length}</div>
            <p className="text-sm text-gray-600 mt-1">Declined proposals</p>
          </CardContent>
        </Card>
      </div>

      <Tabs value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all">All Events ({calendarEvents.length})</TabsTrigger>
          <TabsTrigger value="pending">
            Pending ({pendingEvents.length})
            {pendingEvents.length > 0 && (
              <span className="ml-2 w-2 h-2 bg-yellow-500 rounded-full animate-pulse" />
            )}
          </TabsTrigger>
          <TabsTrigger value="approved">Approved ({approvedEvents.length})</TabsTrigger>
          <TabsTrigger value="rejected">Rejected ({rejectedEvents.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4 mt-6">
          <div className="space-y-3">
            {calendarEvents.map((event, index) => (
              <motion.div
                key={event.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex gap-4 flex-1">
                        <div className="flex flex-col items-center">
                          <div className="w-16 h-16 rounded-lg flex items-center justify-center text-white font-bold" style={{ backgroundColor: event.color }}>
                            <Calendar className="w-8 h-8" />
                          </div>
                          <p className="text-xs text-gray-600 mt-2">{format(new Date(event.date), 'MMM dd')}</p>
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="font-bold text-lg">{event.title}</h3>
                            <Badge className={getTypeColor(event.type)}>
                              {event.type}
                            </Badge>
                            {getStatusBadge(event.status)}
                          </div>
                          {event.description && (
                            <p className="text-gray-600 mb-2">{event.description}</p>
                          )}
                          <div className="flex gap-4 text-sm text-gray-600">
                            <span>📅 {format(new Date(event.date), 'PPP')}</span>
                            {event.endDate && (
                              <span>→ {format(new Date(event.endDate), 'PPP')}</span>
                            )}
                            {event.subjectId && (
                              <span>📚 {subjects.find(s => s.id === event.subjectId)?.name}</span>
                            )}
                          </div>
                        </div>
                      </div>
                      {event.status === 'pending' && (
                        <div className="flex gap-2">
                          <Button onClick={() => handleApprove(event.id)} size="sm" className="bg-green-600 hover:bg-green-700">
                            <Check className="w-4 h-4 mr-1" />
                            Approve
                          </Button>
                          <Button onClick={() => handleReject(event.id)} size="sm" variant="destructive">
                            <X className="w-4 h-4 mr-1" />
                            Reject
                          </Button>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="pending" className="space-y-4 mt-6">
          {pendingEvents.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center text-gray-500">
                <Clock className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>No pending events</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {pendingEvents.map((event, index) => (
                <motion.div
                  key={event.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <Card className="border-2 border-yellow-200">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex gap-4 flex-1">
                          <div className="flex flex-col items-center">
                            <div className="w-16 h-16 rounded-lg flex items-center justify-center text-white font-bold" style={{ backgroundColor: event.color }}>
                              <AlertCircle className="w-8 h-8" />
                            </div>
                            <p className="text-xs text-gray-600 mt-2">{format(new Date(event.date), 'MMM dd')}</p>
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <h3 className="font-bold text-lg">{event.title}</h3>
                              <Badge className={getTypeColor(event.type)}>
                                {event.type}
                              </Badge>
                            </div>
                            {event.description && (
                              <p className="text-gray-600 mb-2">{event.description}</p>
                            )}
                            <div className="flex gap-4 text-sm text-gray-600">
                              <span>📅 {format(new Date(event.date), 'PPP')}</span>
                              {event.endDate && (
                                <span>→ {format(new Date(event.endDate), 'PPP')}</span>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button onClick={() => handleApprove(event.id)} size="sm" className="bg-green-600 hover:bg-green-700">
                            <Check className="w-4 h-4 mr-1" />
                            Approve
                          </Button>
                          <Button onClick={() => handleReject(event.id)} size="sm" variant="destructive">
                            <X className="w-4 h-4 mr-1" />
                            Reject
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="approved" className="space-y-4 mt-6">
          <div className="space-y-3">
            {approvedEvents.map((event, index) => (
              <motion.div
                key={event.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card>
                  <CardContent className="p-6">
                    <div className="flex gap-4">
                      <div className="flex flex-col items-center">
                        <div className="w-16 h-16 rounded-lg flex items-center justify-center text-white font-bold" style={{ backgroundColor: event.color }}>
                          <Calendar className="w-8 h-8" />
                        </div>
                        <p className="text-xs text-gray-600 mt-2">{format(new Date(event.date), 'MMM dd')}</p>
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="font-bold text-lg">{event.title}</h3>
                          <Badge className={getTypeColor(event.type)}>
                            {event.type}
                          </Badge>
                        </div>
                        {event.description && (
                          <p className="text-gray-600 mb-2">{event.description}</p>
                        )}
                        <div className="flex gap-4 text-sm text-gray-600">
                          <span>📅 {format(new Date(event.date), 'PPP')}</span>
                          {event.endDate && (
                            <span>→ {format(new Date(event.endDate), 'PPP')}</span>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="rejected" className="space-y-4 mt-6">
          {rejectedEvents.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center text-gray-500">
                <Check className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>No rejected events</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {rejectedEvents.map((event, index) => (
                <motion.div
                  key={event.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <Card className="opacity-60">
                    <CardContent className="p-6">
                      <div className="flex gap-4">
                        <div className="flex flex-col items-center">
                          <div className="w-16 h-16 rounded-lg flex items-center justify-center bg-gray-400 text-white font-bold">
                            <X className="w-8 h-8" />
                          </div>
                          <p className="text-xs text-gray-600 mt-2">{format(new Date(event.date), 'MMM dd')}</p>
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="font-bold text-lg line-through">{event.title}</h3>
                            <Badge className={getTypeColor(event.type)}>
                              {event.type}
                            </Badge>
                          </div>
                          {event.description && (
                            <p className="text-gray-600 mb-2">{event.description}</p>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
