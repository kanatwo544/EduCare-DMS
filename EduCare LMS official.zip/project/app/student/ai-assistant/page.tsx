'use client';

import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Bot, User, Sparkles, TrendingUp, Calendar, FileText, AlertCircle } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppStore } from '@/lib/store';
import { generateAIResponse, AIMessage, AIContext } from '@/lib/aiEngine';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

export default function AIAssistantPage() {
  const { user } = useAppStore();
  const [messages, setMessages] = useState<AIMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [suggestions, setSuggestions] = useState<string[]>([
    'What\'s my attendance?',
    'Show me my grades',
    'What topics have I covered?',
    'Any upcoming exams?'
  ]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [typingText, setTypingText] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, typingText]);

  useEffect(() => {
    if (messages.length === 0) {
      const welcomeMessage: AIMessage = {
        id: 'welcome',
        role: 'assistant',
        content: `Hello! I'm your EduCare AI Assistant. I can help you with information about your grades, attendance, syllabus progress, and upcoming events. What would you like to know?`,
        timestamp: new Date()
      };
      setMessages([welcomeMessage]);
    }
  }, [messages.length]);

  const typeMessage = async (text: string): Promise<void> => {
    setIsTyping(true);
    setTypingText('');

    for (let i = 0; i <= text.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 20));
      setTypingText(text.slice(0, i));
    }

    setIsTyping(false);
    setTypingText('');
  };

  const handleSendMessage = async (messageText?: string) => {
    const messageContent = messageText || input;
    if (!messageContent.trim() || loading || !user) return;

    const userMessage: AIMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: messageContent,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const context: AIContext = {
        userId: user.id,
        userRole: user.role as 'student' | 'teacher' | 'admin',
        conversationHistory: messages
      };

      const response = await generateAIResponse(messageContent, context);

      await typeMessage(response.content);

      const assistantMessage: AIMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response.content,
        timestamp: new Date(),
        responseType: response.responseType,
        data: response.data
      };

      setMessages(prev => [...prev, assistantMessage]);

      if (response.suggestions) {
        setSuggestions(response.suggestions);
      }
    } catch (error) {
      const errorMessage: AIMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: 'Sorry, I encountered an error. Please try again.',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    handleSendMessage(suggestion);
  };

  const renderMessageContent = (message: AIMessage) => {
    if (message.responseType === 'stats' && message.data) {
      return (
        <div className="space-y-4">
          <p className="text-gray-700">{message.content}</p>
          <div className="grid grid-cols-2 gap-3 bg-blue-50 p-4 rounded-lg">
            <div className="text-center">
              <TrendingUp className="w-6 h-6 mx-auto text-[#04ADEE] mb-1" />
              <p className="text-2xl font-bold text-[#04ADEE]">{message.data.overall}%</p>
              <p className="text-xs text-gray-600">Overall</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-green-600">{message.data.present}</p>
              <p className="text-xs text-gray-600">Present</p>
            </div>
          </div>
        </div>
      );
    }

    if (message.responseType === 'table' && message.data) {
      return (
        <div className="space-y-4">
          <p className="text-gray-700">{message.content}</p>
          {message.data.subjects && (
            <div className="bg-gray-50 rounded-lg overflow-hidden">
              {message.data.subjects.map((subject: any, index: number) => (
                <div key={index} className="p-3 border-b border-gray-200 last:border-b-0">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-semibold text-gray-800">{subject.subject}</span>
                    <Badge className="bg-[#04ADEE] text-white">
                      {subject.average || subject.percentage || subject.progress}%
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
          {message.data.events && (
            <div className="space-y-2">
              {message.data.events.map((event: any, index: number) => (
                <div key={index} className="p-3 bg-blue-50 rounded-lg">
                  <div className="flex items-start space-x-2">
                    <Calendar className="w-4 h-4 text-[#04ADEE] mt-0.5 flex-shrink-0" />
                    <div className="flex-1">
                      <p className="text-sm font-semibold text-gray-800">{event.title}</p>
                      <p className="text-xs text-gray-600">{event.description}</p>
                      <p className="text-xs text-gray-500 mt-1">
                        {new Date(event.date).toLocaleDateString('en-US', {
                          month: 'short',
                          day: 'numeric',
                          year: 'numeric'
                        })}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      );
    }

    if (message.responseType === 'alert' && message.data) {
      return (
        <div className="space-y-4">
          <p className="text-gray-700">{message.content}</p>
          {message.data.announcements && (
            <div className="space-y-2">
              {message.data.announcements.map((announcement: any, index: number) => (
                <div key={index} className="p-3 bg-yellow-50 border-l-4 border-yellow-500 rounded">
                  <div className="flex items-start space-x-2">
                    <AlertCircle className="w-4 h-4 text-yellow-600 mt-0.5 flex-shrink-0" />
                    <div className="flex-1">
                      <p className="text-sm font-semibold text-gray-800">{announcement.title}</p>
                      <p className="text-xs text-gray-600 mt-1">{announcement.content}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      );
    }

    return <p className="text-gray-700">{message.content}</p>;
  };

  if (!user) return null;

  return (
    <DashboardLayout>
      <div className="h-[calc(100vh-120px)] flex flex-col">
        <div className="mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#04ADEE] to-[#0398d4] flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-800">AI Assistant</h1>
              <p className="text-gray-600 mt-1">Your personal academic companion</p>
            </div>
          </div>
        </div>

        <div className="flex-1 bg-white rounded-xl shadow-sm border border-gray-100 flex flex-col overflow-hidden">
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            <AnimatePresence>
              {messages.map((message, index) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`flex space-x-3 max-w-3xl ${message.role === 'user' ? 'flex-row-reverse space-x-reverse' : ''}`}>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      message.role === 'user' ? 'bg-[#04ADEE]' : 'bg-gradient-to-br from-[#04ADEE] to-[#0398d4]'
                    }`}>
                      {message.role === 'user' ? (
                        <User className="w-4 h-4 text-white" />
                      ) : (
                        <Bot className="w-4 h-4 text-white" />
                      )}
                    </div>
                    <div className={`flex-1 p-4 rounded-2xl ${
                      message.role === 'user'
                        ? 'bg-[#04ADEE] text-white'
                        : 'bg-gray-50 border border-gray-100'
                    }`}>
                      {renderMessageContent(message)}
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            {isTyping && typingText && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex justify-start"
              >
                <div className="flex space-x-3 max-w-3xl">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#04ADEE] to-[#0398d4] flex items-center justify-center flex-shrink-0">
                    <Bot className="w-4 h-4 text-white" />
                  </div>
                  <div className="flex-1 p-4 rounded-2xl bg-gray-50 border border-gray-100">
                    <p className="text-gray-700">{typingText}<span className="animate-pulse">|</span></p>
                  </div>
                </div>
              </motion.div>
            )}

            {loading && !isTyping && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex justify-start"
              >
                <div className="flex space-x-3">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#04ADEE] to-[#0398d4] flex items-center justify-center">
                    <Bot className="w-4 h-4 text-white" />
                  </div>
                  <div className="flex-1 p-4 rounded-2xl bg-gray-50 border border-gray-100">
                    <div className="flex space-x-2">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {suggestions.length > 0 && (
            <div className="px-6 py-3 border-t border-gray-100 bg-gray-50">
              <p className="text-xs text-gray-500 mb-2">Suggested questions:</p>
              <div className="flex flex-wrap gap-2">
                {suggestions.map((suggestion, index) => (
                  <motion.button
                    key={index}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.05 }}
                    onClick={() => handleSuggestionClick(suggestion)}
                    className="px-3 py-1.5 bg-white border border-gray-200 rounded-full text-xs text-gray-700 hover:bg-[#04ADEE] hover:text-white hover:border-[#04ADEE] transition-colors"
                  >
                    {suggestion}
                  </motion.button>
                ))}
              </div>
            </div>
          )}

          <div className="p-4 border-t border-gray-100">
            <div className="flex space-x-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder="Ask me anything about your academics..."
                className="flex-1"
                disabled={loading}
              />
              <Button
                onClick={() => handleSendMessage()}
                disabled={loading || !input.trim()}
                className="bg-[#04ADEE] hover:bg-[#0398d4] text-white"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
