'use client';

import { motion } from 'framer-motion';
import { TrendingUp, CheckCircle, XCircle, Clock as ClockIcon } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppStore } from '@/lib/store';
import { STUDENTS, SUBJECTS, getStudentAttendance, calculateAttendancePercentage } from '@/lib/demoData';
import { LineChartComponent } from '@/components/dashboard/LineChartComponent';

export default function AttendancePage() {
  const { user } = useAppStore();

  if (!user) return null;

  const student = STUDENTS.find(s => s.id === user.id);
  if (!student) return null;

  const allAttendance = getStudentAttendance(user.id);
  const overallPercentage = calculateAttendancePercentage(allAttendance);

  const studentSubjects = SUBJECTS.filter(s => student.subjects.includes(s.id));

  const subjectAttendance = studentSubjects.map(subject => {
    const records = getStudentAttendance(user.id, subject.id);
    return {
      subject: subject.name,
      color: subject.color,
      total: records.length,
      present: records.filter(r => r.status === 'present').length,
      absent: records.filter(r => r.status === 'absent').length,
      late: records.filter(r => r.status === 'late').length,
      percentage: calculateAttendancePercentage(records)
    };
  });

  const mockTrendData = [
    { name: 'Week 1', value: 95 },
    { name: 'Week 2', value: 92 },
    { name: 'Week 3', value: 94 },
    { name: 'Week 4', value: 91 },
    { name: 'Week 5', value: 93 }
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Attendance</h1>
          <p className="text-gray-600 mt-1">Track your attendance across all subjects</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
          >
            <TrendingUp className="w-8 h-8 text-[#04ADEE] mb-3" />
            <p className="text-3xl font-bold text-[#04ADEE]">{overallPercentage}%</p>
            <p className="text-sm text-gray-600 mt-1">Overall Attendance</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
          >
            <CheckCircle className="w-8 h-8 text-green-600 mb-3" />
            <p className="text-3xl font-bold text-green-600">
              {allAttendance.filter(a => a.status === 'present').length}
            </p>
            <p className="text-sm text-gray-600 mt-1">Classes Attended</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
          >
            <XCircle className="w-8 h-8 text-red-600 mb-3" />
            <p className="text-3xl font-bold text-red-600">
              {allAttendance.filter(a => a.status === 'absent').length}
            </p>
            <p className="text-sm text-gray-600 mt-1">Classes Missed</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
          >
            <ClockIcon className="w-8 h-8 text-yellow-600 mb-3" />
            <p className="text-3xl font-bold text-yellow-600">
              {allAttendance.filter(a => a.status === 'late').length}
            </p>
            <p className="text-sm text-gray-600 mt-1">Late Arrivals</p>
          </motion.div>
        </div>

        <LineChartComponent
          data={mockTrendData}
          title="Attendance Trend"
          color="#04ADEE"
          yAxisLabel="Attendance %"
          delay={0.4}
        />

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden"
        >
          <div className="p-6 border-b border-gray-100">
            <h3 className="text-lg font-semibold text-gray-800">Subject-wise Attendance</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Subject</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Total Classes</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Present</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Absent</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Late</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Percentage</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {subjectAttendance.map((item, index) => (
                  <motion.tr
                    key={item.subject}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.5 + index * 0.05 }}
                    className="hover:bg-gray-50 transition-colors"
                  >
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-3">
                        <div
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: item.color }}
                        />
                        <span className="text-sm font-medium text-gray-800">{item.subject}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-700">{item.total}</td>
                    <td className="px-6 py-4 text-sm text-green-600 font-semibold">{item.present}</td>
                    <td className="px-6 py-4 text-sm text-red-600 font-semibold">{item.absent}</td>
                    <td className="px-6 py-4 text-sm text-yellow-600 font-semibold">{item.late}</td>
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-3">
                        <div className="flex-1">
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <motion.div
                              initial={{ width: 0 }}
                              animate={{ width: `${item.percentage}%` }}
                              transition={{ delay: 0.5 + index * 0.05 + 0.3, duration: 0.8 }}
                              className="h-2 rounded-full"
                              style={{ backgroundColor: item.color }}
                            />
                          </div>
                        </div>
                        <span className="text-sm font-semibold" style={{ color: item.color }}>
                          {item.percentage}%
                        </span>
                      </div>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>
      </div>
    </DashboardLayout>
  );
}
