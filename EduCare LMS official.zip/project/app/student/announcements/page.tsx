'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bell, AlertCircle, Info, TrendingUp, X, User, Calendar, Users } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppData } from '@/lib/context/AppDataContext';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Announcement } from '@/lib/demoData';

export default function AnnouncementsPage() {
  const { announcements } = useAppData();
  const [selectedAnnouncement, setSelectedAnnouncement] = useState<Announcement | null>(null);
  const [readAnnouncements, setReadAnnouncements] = useState<Set<string>>(new Set());

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return '#EF4444';
      case 'medium': return '#F59E0B';
      case 'low': return '#10B981';
      default: return '#6B7280';
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'high': return AlertCircle;
      case 'medium': return TrendingUp;
      case 'low': return Info;
      default: return Bell;
    }
  };

  const handleAnnouncementClick = (announcement: Announcement) => {
    setSelectedAnnouncement(announcement);
    setReadAnnouncements(prev => new Set(prev).add(announcement.id));
  };

  const sortedAnnouncements = [...announcements].sort((a, b) =>
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  const isUnread = (id: string) => !readAnnouncements.has(id);

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Announcements</h1>
          <p className="text-gray-600 mt-1">Stay updated with the latest news and updates</p>
        </div>

        <div className="space-y-4">
          {sortedAnnouncements.map((announcement, index) => {
            const Icon = getPriorityIcon(announcement.priority);
            const priorityColor = getPriorityColor(announcement.priority);
            const unread = isUnread(announcement.id);

            return (
              <motion.div
                key={announcement.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                onClick={() => handleAnnouncementClick(announcement)}
                className="bg-white rounded-xl p-6 shadow-sm border-l-4 hover:shadow-md transition-all cursor-pointer relative"
                style={{ borderColor: priorityColor }}
              >
                {unread && (
                  <div className="absolute top-4 right-4 w-3 h-3 bg-red-500 rounded-full animate-pulse" />
                )}

                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-start space-x-4 flex-1">
                    <div
                      className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: priorityColor + '15' }}
                    >
                      <Icon className="w-6 h-6" style={{ color: priorityColor }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-xl font-bold text-gray-800 mb-2">{announcement.title}</h3>
                      <p className="text-sm text-gray-600 line-clamp-2">{announcement.content}</p>
                    </div>
                  </div>
                  <Badge
                    className="capitalize ml-4 flex-shrink-0"
                    style={{ backgroundColor: priorityColor + '15', color: priorityColor }}
                  >
                    {announcement.priority}
                  </Badge>
                </div>

                <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100">
                  <div className="flex items-center space-x-4 text-sm text-gray-500">
                    <span className="flex items-center">
                      <User className="w-4 h-4 mr-1" />
                      {announcement.author}
                    </span>
                    <span className="capitalize">
                      {announcement.authorRole}
                    </span>
                  </div>
                  <span className="text-sm text-gray-500">
                    {new Date(announcement.date).toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </span>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      <Dialog open={!!selectedAnnouncement} onOpenChange={(open) => !open && setSelectedAnnouncement(null)}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          {selectedAnnouncement && (
            <>
              <DialogHeader>
                <DialogTitle className="text-2xl font-bold pr-8">
                  {selectedAnnouncement.title}
                </DialogTitle>
              </DialogHeader>

              <div className="space-y-6 mt-4">
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-6">
                    <div className="flex items-center space-x-2 text-sm text-gray-600">
                      <User className="w-4 h-4" />
                      <div>
                        <p className="font-medium text-gray-800">{selectedAnnouncement.author}</p>
                        <p className="text-xs capitalize">{selectedAnnouncement.authorRole}</p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2 text-sm text-gray-600">
                      <Calendar className="w-4 h-4" />
                      <span>
                        {new Date(selectedAnnouncement.date).toLocaleDateString('en-US', {
                          month: 'long',
                          day: 'numeric',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </span>
                    </div>

                    <div className="flex items-center space-x-2 text-sm text-gray-600">
                      <Users className="w-4 h-4" />
                      <span className="capitalize">{selectedAnnouncement.targetAudience}</span>
                    </div>
                  </div>

                  <Badge
                    className="capitalize"
                    style={{
                      backgroundColor: getPriorityColor(selectedAnnouncement.priority) + '15',
                      color: getPriorityColor(selectedAnnouncement.priority)
                    }}
                  >
                    {selectedAnnouncement.priority} Priority
                  </Badge>
                </div>

                <div className="prose max-w-none">
                  <p className="text-gray-700 leading-relaxed whitespace-pre-wrap">
                    {selectedAnnouncement.content}
                  </p>
                </div>

                <div className="flex justify-end pt-4 border-t">
                  <Button onClick={() => setSelectedAnnouncement(null)}>
                    Close
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
