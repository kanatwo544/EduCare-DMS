'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Send, Star, MessageSquare, CheckCircle, Clock, User } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppData } from '@/lib/context/AppDataContext';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function FeedbackPage() {
  const { feedbacks, subjects, teachers, submitFeedback, students } = useAppData();
  const [selectedSubject, setSelectedSubject] = useState('');
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState('');
  const [anonymous, setAnonymous] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const currentStudentId = 's1';
  const currentStudent = students.find(s => s.id === currentStudentId);

  const studentSubjects = subjects.filter(s => currentStudent?.subjects.includes(s.id));

  const myFeedbacks = feedbacks.filter(f => f.studentId === currentStudentId);

  const handleSubmitFeedback = async () => {
    if (!selectedSubject || rating === 0 || !comment.trim()) return;

    const subject = subjects.find(s => s.id === selectedSubject);
    const teacher = teachers.find(t => t.id === subject?.teacherId);

    if (!subject || !teacher) return;

    setSubmitting(true);

    submitFeedback({
      studentId: currentStudentId,
      teacherId: teacher.id,
      subjectId: selectedSubject,
      assignmentName: comment,
      comment: comment
    });

    setTimeout(() => {
      setSubmitting(false);
      setSelectedSubject('');
      setRating(0);
      setComment('');
      setAnonymous(false);
    }, 500);
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Feedback</h1>
          <p className="text-gray-600 mt-1">Share your thoughts and view feedback from teachers</p>
        </div>

        <Tabs defaultValue="give" className="w-full">
          <TabsList className="grid w-full max-w-md grid-cols-2">
            <TabsTrigger value="give">Give Feedback</TabsTrigger>
            <TabsTrigger value="received">Received Feedback</TabsTrigger>
          </TabsList>

          <TabsContent value="give" className="space-y-6 mt-6">
            <div className="bg-white rounded-xl p-8 shadow-sm border border-gray-100">
              <h2 className="text-xl font-bold text-gray-800 mb-6">Submit Course Feedback</h2>

              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Select Subject
                  </label>
                  <Select value={selectedSubject} onValueChange={setSelectedSubject}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a subject" />
                    </SelectTrigger>
                    <SelectContent>
                      {studentSubjects.map(subject => (
                        <SelectItem key={subject.id} value={subject.id}>
                          {subject.name} - {subject.teacherName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Rating
                  </label>
                  <div className="flex items-center space-x-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setRating(star)}
                        onMouseEnter={() => setHoverRating(star)}
                        onMouseLeave={() => setHoverRating(0)}
                        className="focus:outline-none transition-transform hover:scale-110"
                      >
                        <Star
                          className={`w-8 h-8 ${
                            star <= (hoverRating || rating)
                              ? 'fill-yellow-400 text-yellow-400'
                              : 'text-gray-300'
                          }`}
                        />
                      </button>
                    ))}
                    {rating > 0 && (
                      <span className="ml-4 text-sm font-medium text-gray-700">
                        {rating === 5
                          ? 'Excellent'
                          : rating === 4
                          ? 'Good'
                          : rating === 3
                          ? 'Average'
                          : rating === 2
                          ? 'Below Average'
                          : 'Poor'}
                      </span>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Your Comments
                  </label>
                  <Textarea
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    placeholder="Share your thoughts about the course, teaching methodology, materials, etc."
                    className="min-h-[150px]"
                  />
                </div>

                <Button
                  onClick={handleSubmitFeedback}
                  disabled={!selectedSubject || rating === 0 || !comment.trim() || submitting}
                  className="w-full bg-[#04ADEE] hover:bg-[#0398d4]"
                >
                  {submitting ? (
                    <>
                      <Clock className="w-4 h-4 mr-2 animate-spin" />
                      Submitting...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      Submit Feedback
                    </>
                  )}
                </Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="received" className="mt-6">
            <div className="space-y-4">
              {myFeedbacks.length === 0 ? (
                <div className="bg-white rounded-xl p-12 shadow-sm border border-gray-100 text-center">
                  <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <MessageSquare className="w-12 h-12 text-gray-400" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-800 mb-2">No feedback yet</h3>
                  <p className="text-gray-600">
                    Teacher feedback on your assignments will appear here
                  </p>
                </div>
              ) : (
                myFeedbacks.map((feedback, index) => {
                  const subject = subjects.find(s => s.id === feedback.subjectId);
                  const teacher = teachers.find(t => t.id === feedback.teacherId);
                  const hasGrade = feedback.grade !== undefined && feedback.maxGrade !== undefined;

                  return (
                    <motion.div
                      key={feedback.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
                    >
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-start space-x-4 flex-1">
                          <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                            <MessageSquare className="w-6 h-6 text-[#04ADEE]" />
                          </div>
                          <div className="flex-1">
                            <h3 className="text-lg font-bold text-gray-800 mb-1">
                              {feedback.assignmentName}
                            </h3>
                            <p className="text-sm text-gray-600">
                              {subject?.name} • {teacher?.name}
                            </p>
                          </div>
                        </div>
                        {hasGrade ? (
                          <div className="text-right ml-4">
                            <div className="text-2xl font-bold text-[#04ADEE]">
                              {feedback.grade}/{feedback.maxGrade}
                            </div>
                            <div className="text-xs text-gray-500">
                              {Math.round((feedback.grade! / feedback.maxGrade!) * 100)}%
                            </div>
                          </div>
                        ) : (
                          <Badge variant="outline" className="ml-4">
                            <Clock className="w-3 h-3 mr-1" />
                            Pending
                          </Badge>
                        )}
                      </div>

                      <div className="p-4 bg-gray-50 rounded-lg mb-4">
                        <p className="text-gray-700 leading-relaxed">{feedback.comment}</p>
                      </div>

                      <div className="flex items-center justify-between text-sm text-gray-500">
                        <div className="flex items-center space-x-4">
                          <span className="flex items-center">
                            <User className="w-4 h-4 mr-1" />
                            Submitted {new Date(feedback.submittedDate).toLocaleDateString()}
                          </span>
                          {feedback.feedbackDate && (
                            <span className="flex items-center">
                              <CheckCircle className="w-4 h-4 mr-1 text-green-500" />
                              Reviewed {new Date(feedback.feedbackDate).toLocaleDateString()}
                            </span>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  );
                })
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
