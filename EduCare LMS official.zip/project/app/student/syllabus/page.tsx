'use client';

import { motion } from 'framer-motion';
import { BookOpen, CheckCircle, Circle } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppStore } from '@/lib/store';
import { STUDENTS, SUBJECTS, SYLLABUS, getSyllabusProgress, getSubjectSyllabus } from '@/lib/demoData';
import { ProgressRing } from '@/components/dashboard/ProgressRing';

export default function SyllabusPage() {
  const { user } = useAppStore();

  if (!user) return null;

  const student = STUDENTS.find(s => s.id === user.id);
  if (!student) return null;

  const studentSubjects = SUBJECTS.filter(s => student.subjects.includes(s.id));

  const getSubjectProgress = (subjectId: string) => {
    const topics = getSubjectSyllabus(subjectId);
    return getSyllabusProgress(topics);
  };

  const overallProgress = Math.round(
    studentSubjects.reduce((sum, s) => sum + getSubjectProgress(s.id), 0) / studentSubjects.length
  );

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Syllabus</h1>
          <p className="text-gray-600 mt-1">Track your syllabus completion across all subjects</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 flex flex-col items-center justify-center"
          >
            <ProgressRing
              progress={overallProgress}
              size={150}
              strokeWidth={10}
              color="#04ADEE"
              label="Overall Progress"
            />
          </motion.div>

          <div className="lg:col-span-3 grid grid-cols-1 md:grid-cols-3 gap-4">
            {studentSubjects.map((subject, index) => {
              const progress = getSubjectProgress(subject.id);
              const topics = getSubjectSyllabus(subject.id);
              const completedCount = topics.filter(t => t.completed).length;

              return (
                <motion.div
                  key={subject.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white rounded-xl p-5 shadow-sm border border-gray-100"
                >
                  <div className="flex items-center justify-between mb-3">
                    <div
                      className="w-10 h-10 rounded-lg flex items-center justify-center"
                      style={{ backgroundColor: subject.color + '15' }}
                    >
                      <BookOpen className="w-5 h-5" style={{ color: subject.color }} />
                    </div>
                    <span className="text-2xl font-bold" style={{ color: subject.color }}>
                      {progress}%
                    </span>
                  </div>
                  <h3 className="font-semibold text-gray-800 mb-1">{subject.name}</h3>
                  <p className="text-sm text-gray-600">{completedCount}/{topics.length} topics completed</p>
                  <div className="w-full bg-gray-200 rounded-full h-2 mt-3">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${progress}%` }}
                      transition={{ delay: index * 0.1 + 0.3, duration: 1 }}
                      className="h-2 rounded-full"
                      style={{ backgroundColor: subject.color }}
                    />
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        <div className="space-y-6">
          {studentSubjects.map((subject, subjectIndex) => {
            const topics = getSubjectSyllabus(subject.id);

            return (
              <motion.div
                key={subject.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: subjectIndex * 0.1 }}
                className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden"
              >
                <div
                  className="p-6 border-l-4"
                  style={{ borderColor: subject.color }}
                >
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center space-x-3">
                      <div
                        className="w-12 h-12 rounded-lg flex items-center justify-center"
                        style={{ backgroundColor: subject.color + '15' }}
                      >
                        <BookOpen className="w-6 h-6" style={{ color: subject.color }} />
                      </div>
                      <div>
                        <h2 className="text-xl font-bold text-gray-800">{subject.name}</h2>
                        <p className="text-sm text-gray-600">{subject.teacherName}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-3xl font-bold" style={{ color: subject.color }}>
                        {getSyllabusProgress(topics)}%
                      </p>
                      <p className="text-sm text-gray-600">Progress</p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    {topics.map((topic, topicIndex) => (
                      <motion.div
                        key={topic.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: subjectIndex * 0.1 + topicIndex * 0.05 }}
                        className={`flex items-start p-4 rounded-lg border ${
                          topic.completed
                            ? 'bg-green-50 border-green-200'
                            : 'bg-gray-50 border-gray-200'
                        }`}
                      >
                        <div className="flex-shrink-0 mt-0.5">
                          {topic.completed ? (
                            <CheckCircle className="w-5 h-5 text-green-600" />
                          ) : (
                            <Circle className="w-5 h-5 text-gray-400" />
                          )}
                        </div>
                        <div className="ml-3 flex-1">
                          <div className="flex items-start justify-between">
                            <div>
                              <h4
                                className={`font-semibold ${
                                  topic.completed ? 'text-green-900' : 'text-gray-800'
                                }`}
                              >
                                {topic.order}. {topic.topic}
                              </h4>
                              <p
                                className={`text-sm mt-1 ${
                                  topic.completed ? 'text-green-700' : 'text-gray-600'
                                }`}
                              >
                                {topic.subtopics.length + ' subtopics'}
                              </p>
                            </div>
                            {topic.completed && (
                              <span className="text-xs text-green-600 whitespace-nowrap ml-4">
                                Completed
                              </span>
                            )}
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </DashboardLayout>
  );
}
