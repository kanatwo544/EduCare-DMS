'use client';

import { motion } from 'framer-motion';
import { FileText, Clock, CheckCircle, AlertCircle, TrendingUp } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppStore } from '@/lib/store';
import { MARKS, SUBJECTS, getStudentMarks, calculateSubjectAverage } from '@/lib/demoData';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function AssessmentsPage() {
  const { user } = useAppStore();

  if (!user) return null;

  const userMarks = getStudentMarks(user.id);
  const gradedMarks = userMarks.filter(m => m.status === 'graded');
  const pendingMarks = userMarks.filter(m => m.status === 'pending');
  const submittedMarks = userMarks.filter(m => m.status === 'submitted');

  const overallAverage = calculateSubjectAverage(gradedMarks);
  const totalAssessments = userMarks.length;
  const completedAssessments = gradedMarks.length;

  const getSubjectName = (subjectId: string) => {
    return SUBJECTS.find(s => s.id === subjectId)?.name || subjectId;
  };

  const getSubjectColor = (subjectId: string) => {
    return SUBJECTS.find(s => s.id === subjectId)?.color || '#04ADEE';
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'graded':
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Graded</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">Pending</Badge>;
      case 'submitted':
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">Submitted</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getTypeBadge = (type: string) => {
    const colors = {
      quiz: 'bg-purple-100 text-purple-800',
      test: 'bg-blue-100 text-blue-800',
      exam: 'bg-red-100 text-red-800',
      assignment: 'bg-green-100 text-green-800'
    };
    return (
      <Badge className={`${colors[type as keyof typeof colors] || 'bg-gray-100 text-gray-800'} hover:${colors[type as keyof typeof colors]}`}>
        {type}
      </Badge>
    );
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Assessments</h1>
          <p className="text-gray-600 mt-1">Track your academic performance across all subjects</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0 }}
            className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
          >
            <div className="flex items-center justify-between mb-2">
              <TrendingUp className="w-8 h-8 text-[#04ADEE]" />
            </div>
            <p className="text-3xl font-bold text-[#04ADEE]">{overallAverage.toFixed(1)}%</p>
            <p className="text-sm text-gray-600 mt-1">Overall Average</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
          >
            <div className="flex items-center justify-between mb-2">
              <FileText className="w-8 h-8 text-blue-600" />
            </div>
            <p className="text-3xl font-bold text-blue-600">{totalAssessments}</p>
            <p className="text-sm text-gray-600 mt-1">Total Assessments</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
          >
            <div className="flex items-center justify-between mb-2">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            <p className="text-3xl font-bold text-green-600">{completedAssessments}</p>
            <p className="text-sm text-gray-600 mt-1">Completed</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
          >
            <div className="flex items-center justify-between mb-2">
              <Clock className="w-8 h-8 text-yellow-600" />
            </div>
            <p className="text-3xl font-bold text-yellow-600">{pendingMarks.length}</p>
            <p className="text-sm text-gray-600 mt-1">Pending</p>
          </motion.div>
        </div>

        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full max-w-md grid-cols-4">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="graded">Graded</TabsTrigger>
            <TabsTrigger value="pending">Pending</TabsTrigger>
            <TabsTrigger value="submitted">Submitted</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="mt-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden"
            >
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Assessment</th>
                      <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Subject</th>
                      <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Type</th>
                      <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Score</th>
                      <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Date</th>
                      <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {userMarks.map((mark, index) => (
                      <motion.tr
                        key={mark.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.05 }}
                        className="hover:bg-gray-50 transition-colors"
                      >
                        <td className="px-6 py-4">
                          <div className="flex items-center space-x-3">
                            <div
                              className="w-2 h-2 rounded-full"
                              style={{ backgroundColor: getSubjectColor(mark.subjectId) }}
                            />
                            <span className="text-sm font-medium text-gray-800">{mark.assessmentName}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-700">{getSubjectName(mark.subjectId)}</td>
                        <td className="px-6 py-4">{getTypeBadge(mark.assessmentType)}</td>
                        <td className="px-6 py-4">
                          {mark.status === 'graded' ? (
                            <span className="text-sm font-semibold">
                              <span className={
                                (mark.score / mark.maxScore) * 100 >= 80 ? 'text-green-600' :
                                (mark.score / mark.maxScore) * 100 >= 60 ? 'text-yellow-600' : 'text-red-600'
                              }>
                                {mark.score}/{mark.maxScore}
                              </span>
                              <span className="text-gray-500 ml-2">
                                ({((mark.score / mark.maxScore) * 100).toFixed(0)}%)
                              </span>
                            </span>
                          ) : (
                            <span className="text-sm text-gray-400">-/{mark.maxScore}</span>
                          )}
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-600">
                          {new Date(mark.date).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4">{getStatusBadge(mark.status)}</td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          </TabsContent>

          <TabsContent value="graded" className="mt-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden"
            >
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Assessment</th>
                      <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Subject</th>
                      <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Type</th>
                      <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Score</th>
                      <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Date</th>
                      <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Feedback</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {gradedMarks.map((mark, index) => (
                      <motion.tr
                        key={mark.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.05 }}
                        className="hover:bg-gray-50 transition-colors"
                      >
                        <td className="px-6 py-4">
                          <div className="flex items-center space-x-3">
                            <div
                              className="w-2 h-2 rounded-full"
                              style={{ backgroundColor: getSubjectColor(mark.subjectId) }}
                            />
                            <span className="text-sm font-medium text-gray-800">{mark.assessmentName}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-700">{getSubjectName(mark.subjectId)}</td>
                        <td className="px-6 py-4">{getTypeBadge(mark.assessmentType)}</td>
                        <td className="px-6 py-4">
                          <span className="text-sm font-semibold">
                            <span className={
                              (mark.score / mark.maxScore) * 100 >= 80 ? 'text-green-600' :
                              (mark.score / mark.maxScore) * 100 >= 60 ? 'text-yellow-600' : 'text-red-600'
                            }>
                              {mark.score}/{mark.maxScore}
                            </span>
                            <span className="text-gray-500 ml-2">
                              ({((mark.score / mark.maxScore) * 100).toFixed(0)}%)
                            </span>
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-600">
                          {new Date(mark.date).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-600 max-w-xs truncate">
                          {mark.feedback || '-'}
                        </td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          </TabsContent>

          <TabsContent value="pending" className="mt-6">
            {pendingMarks.length > 0 ? (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden"
              >
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Assessment</th>
                        <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Subject</th>
                        <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Type</th>
                        <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Max Score</th>
                        <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Due Date</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {pendingMarks.map((mark, index) => (
                        <motion.tr
                          key={mark.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.05 }}
                          className="hover:bg-gray-50 transition-colors"
                        >
                          <td className="px-6 py-4">
                            <div className="flex items-center space-x-3">
                              <AlertCircle className="w-4 h-4 text-yellow-600" />
                              <span className="text-sm font-medium text-gray-800">{mark.assessmentName}</span>
                            </div>
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-700">{getSubjectName(mark.subjectId)}</td>
                          <td className="px-6 py-4">{getTypeBadge(mark.assessmentType)}</td>
                          <td className="px-6 py-4 text-sm text-gray-700">{mark.maxScore}</td>
                          <td className="px-6 py-4 text-sm text-gray-600">
                            {new Date(mark.date).toLocaleDateString()}
                          </td>
                        </motion.tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </motion.div>
            ) : (
              <div className="bg-white rounded-xl p-12 text-center border border-gray-100">
                <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
                <p className="text-gray-500">No pending assessments</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="submitted" className="mt-6">
            {submittedMarks.length > 0 ? (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden"
              >
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Assessment</th>
                        <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Subject</th>
                        <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Type</th>
                        <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Max Score</th>
                        <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Submitted Date</th>
                        <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {submittedMarks.map((mark, index) => (
                        <motion.tr
                          key={mark.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.05 }}
                          className="hover:bg-gray-50 transition-colors"
                        >
                          <td className="px-6 py-4">
                            <div className="flex items-center space-x-3">
                              <Clock className="w-4 h-4 text-blue-600" />
                              <span className="text-sm font-medium text-gray-800">{mark.assessmentName}</span>
                            </div>
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-700">{getSubjectName(mark.subjectId)}</td>
                          <td className="px-6 py-4">{getTypeBadge(mark.assessmentType)}</td>
                          <td className="px-6 py-4 text-sm text-gray-700">{mark.maxScore}</td>
                          <td className="px-6 py-4 text-sm text-gray-600">
                            {new Date(mark.date).toLocaleDateString()}
                          </td>
                          <td className="px-6 py-4">{getStatusBadge(mark.status)}</td>
                        </motion.tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </motion.div>
            ) : (
              <div className="bg-white rounded-xl p-12 text-center border border-gray-100">
                <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">No submitted assessments awaiting grading</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
