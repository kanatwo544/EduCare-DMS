'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { BookOpen, TrendingUp, Users, Clock } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { subjectsAPI, Subject } from '@/lib/apiContracts/subjects';
import { useAppStore } from '@/lib/store';

export default function SubjectsPage() {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAppStore();

  useEffect(() => {
    if (user) {
      subjectsAPI.getSubjects(user.id, 'student').then(data => {
        setSubjects(data);
        setLoading(false);
      });
    }
  }, [user]);

  if (loading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#04ADEE]"></div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">My Subjects</h1>
          <p className="text-gray-600 mt-1">View and manage your enrolled subjects</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {subjects.map((subject, index) => (
            <motion.div
              key={subject.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1, duration: 0.5 }}
            >
              <Link href={`/student/subject/${subject.id}`}>
                <div
                  className="bg-white rounded-xl p-6 shadow-sm border-2 hover:shadow-lg transition-all cursor-pointer group"
                  style={{ borderColor: subject.color + '30' }}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div
                      className="w-12 h-12 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform"
                      style={{ backgroundColor: subject.color + '15' }}
                    >
                      <BookOpen className="w-6 h-6" style={{ color: subject.color }} />
                    </div>
                    <div
                      className="px-3 py-1 rounded-full text-xs font-semibold"
                      style={{
                        backgroundColor: subject.color + '15',
                        color: subject.color
                      }}
                    >
                      {subject.average}%
                    </div>
                  </div>

                  <h3 className="text-xl font-bold text-gray-800 mb-2 group-hover:text-[#04ADEE] transition-colors">
                    {subject.name}
                  </h3>
                  <p className="text-sm text-gray-600 mb-4">
                    <Users className="w-4 h-4 inline mr-1" />
                    {subject.teacher}
                  </p>

                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-xs text-gray-600">Progress</span>
                        <span className="text-xs font-semibold" style={{ color: subject.color }}>
                          {subject.progress}%
                        </span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${subject.progress}%` }}
                          transition={{ delay: index * 0.1 + 0.3, duration: 1 }}
                          className="h-2 rounded-full"
                          style={{ backgroundColor: subject.color }}
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center text-gray-600">
                        <Clock className="w-4 h-4 mr-1" />
                        <span>{subject.attendedClasses}/{subject.totalClasses} classes</span>
                      </div>
                      <div className="flex items-center" style={{ color: subject.color }}>
                        <TrendingUp className="w-4 h-4 mr-1" />
                        <span className="font-semibold">{subject.average}%</span>
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
