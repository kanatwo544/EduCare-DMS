'use client';

import { motion } from 'framer-motion';
import { Calendar as CalIcon, Award, FileText, PartyPopper, Palmtree } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { CALENDAR_EVENTS } from '@/lib/demoData';
import { Badge } from '@/components/ui/badge';

export default function CalendarPage() {
  const getEventIcon = (type: string) => {
    switch (type) {
      case 'exam': return Award;
      case 'assignment': return FileText;
      case 'event': return PartyPopper;
      case 'holiday': return Palmtree;
      default: return CalIcon;
    }
  };

  const sortedEvents = [...CALENDAR_EVENTS].sort((a, b) =>
    new Date(a.date).getTime() - new Date(b.date).getTime()
  );

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Calendar</h1>
          <p className="text-gray-600 mt-1">View upcoming events, exams, and assignments</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sortedEvents.map((event, index) => {
            const Icon = getEventIcon(event.type);
            return (
              <motion.div
                key={event.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="bg-white rounded-xl p-6 shadow-sm border-l-4 hover:shadow-md transition-shadow"
                style={{ borderColor: event.color }}
              >
                <div className="flex items-start justify-between mb-4">
                  <div
                    className="w-12 h-12 rounded-lg flex items-center justify-center"
                    style={{ backgroundColor: event.color + '15' }}
                  >
                    <Icon className="w-6 h-6" style={{ color: event.color }} />
                  </div>
                  <Badge
                    className="capitalize"
                    style={{ backgroundColor: event.color + '15', color: event.color }}
                  >
                    {event.type}
                  </Badge>
                </div>
                <h3 className="text-lg font-bold text-gray-800 mb-2">{event.title}</h3>
                <p className="text-sm text-gray-600 mb-4">{event.description}</p>
                <div className="flex items-center text-sm text-gray-500">
                  <CalIcon className="w-4 h-4 mr-2" />
                  {new Date(event.date).toLocaleDateString('en-US', {
                    weekday: 'short',
                    month: 'short',
                    day: 'numeric'
                  })}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </DashboardLayout>
  );
}
