'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { motion } from 'framer-motion';
import { BookOpen, FileText, Download, Video, Link as LinkIcon, CheckCircle, Circle } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { subjectsAPI, SubjectDetail } from '@/lib/apiContracts/subjects';
import { ProgressRing } from '@/components/dashboard/ProgressRing';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function SubjectDetailPage() {
  const params = useParams();
  const [subject, setSubject] = useState<SubjectDetail | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (params.id) {
      subjectsAPI.getSubjectDetail(params.id as string).then(data => {
        setSubject(data);
        setLoading(false);
      });
    }
  }, [params.id]);

  if (loading || !subject) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#04ADEE]"></div>
        </div>
      </DashboardLayout>
    );
  }

  const getResourceIcon = (type: string) => {
    switch (type) {
      case 'pdf': return FileText;
      case 'video': return Video;
      case 'link': return LinkIcon;
      default: return FileText;
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div
          className="rounded-xl p-6 text-white"
          style={{ background: `linear-gradient(135deg, ${subject.color} 0%, ${subject.color}dd 100%)` }}
        >
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <h1 className="text-3xl font-bold mb-2">{subject.name}</h1>
              <p className="text-white/90 mb-4">{subject.description}</p>
              <p className="text-white/80">Instructor: {subject.teacher}</p>
            </div>
            <div className="bg-white/20 backdrop-blur-sm rounded-xl p-4">
              <div className="text-center">
                <p className="text-4xl font-bold mb-1">{subject.average}%</p>
                <p className="text-sm text-white/90">Your Average</p>
              </div>
            </div>
          </div>
        </div>

        <Tabs defaultValue="syllabus" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="syllabus">Syllabus</TabsTrigger>
            <TabsTrigger value="assessments">Assessments</TabsTrigger>
            <TabsTrigger value="resources">Resources</TabsTrigger>
          </TabsList>

          <TabsContent value="syllabus" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
                >
                  <h3 className="text-lg font-semibold text-gray-800 mb-4">Topics</h3>
                  <div className="space-y-3">
                    {subject.syllabus.map((topic, index) => (
                      <motion.div
                        key={topic.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.05 }}
                        className={`flex items-center p-4 rounded-lg border ${
                          topic.completed ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200'
                        }`}
                      >
                        {topic.completed ? (
                          <CheckCircle className="w-5 h-5 text-green-600 mr-3" />
                        ) : (
                          <Circle className="w-5 h-5 text-gray-400 mr-3" />
                        )}
                        <div className="flex-1">
                          <p className={`font-medium ${topic.completed ? 'text-green-900' : 'text-gray-800'}`}>
                            {topic.topic}
                          </p>
                          {topic.date && (
                            <p className="text-xs text-gray-500 mt-1">
                              Completed on {new Date(topic.date).toLocaleDateString()}
                            </p>
                          )}
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              </div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 flex items-center justify-center"
              >
                <ProgressRing
                  progress={subject.progress || 0}
                  size={180}
                  strokeWidth={12}
                  color={subject.color}
                  label="Syllabus Progress"
                />
              </motion.div>
            </div>
          </TabsContent>

          <TabsContent value="assessments" className="space-y-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden"
            >
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Title</th>
                      <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Type</th>
                      <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Score</th>
                      <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Date</th>
                      <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {subject.assessments.map((assessment, index) => (
                      <motion.tr
                        key={assessment.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.05 }}
                        className="hover:bg-gray-50 transition-colors"
                      >
                        <td className="px-6 py-4 text-sm font-medium text-gray-800">{assessment.title}</td>
                        <td className="px-6 py-4 text-sm">
                          <Badge variant="outline" className="capitalize">{assessment.type}</Badge>
                        </td>
                        <td className="px-6 py-4 text-sm">
                          {assessment.score !== undefined ? (
                            <span className="font-semibold">
                              {assessment.score}/{assessment.maxScore}
                            </span>
                          ) : (
                            <span className="text-gray-400">-/{assessment.maxScore}</span>
                          )}
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-600">
                          {new Date(assessment.date).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4 text-sm">
                          <Badge
                            variant={
                              assessment.status === 'graded' ? 'default' :
                              assessment.status === 'completed' ? 'secondary' : 'outline'
                            }
                            className="capitalize"
                          >
                            {assessment.status}
                          </Badge>
                        </td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          </TabsContent>

          <TabsContent value="resources" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {subject.resources.map((resource, index) => {
                const Icon = getResourceIcon(resource.type);
                return (
                  <motion.div
                    key={resource.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center">
                        <Icon className="w-5 h-5 text-[#04ADEE]" />
                      </div>
                      <Button size="sm" variant="ghost" className="h-8">
                        <Download className="w-4 h-4" />
                      </Button>
                    </div>
                    <h4 className="font-semibold text-gray-800 mb-2">{resource.title}</h4>
                    <p className="text-xs text-gray-500 mb-3">
                      Uploaded by {resource.uploadedBy} on {new Date(resource.date).toLocaleDateString()}
                    </p>
                    <Badge variant="secondary" className="text-xs capitalize">{resource.type}</Badge>
                  </motion.div>
                );
              })}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
