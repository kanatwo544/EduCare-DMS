'use client';

import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Clock, MapPin } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { calendarAPI, TimetableSlot } from '@/lib/apiContracts/calendar';
import { useAppStore } from '@/lib/store';

const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const timeSlots = ['09:00', '10:15', '11:30', '13:00', '14:15', '15:30'];

export default function TimetablePage() {
  const [timetable, setTimetable] = useState<TimetableSlot[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAppStore();

  useEffect(() => {
    if (user) {
      calendarAPI.getTimetable(user.id, 'student').then(data => {
        setTimetable(data);
        setLoading(false);
      });
    }
  }, [user]);

  const getSlotForDayAndTime = (day: string, time: string) => {
    return timetable.find(slot =>
      slot.day === day && slot.startTime === time
    );
  };

  if (loading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#04ADEE]"></div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Timetable</h1>
          <p className="text-gray-600 mt-1">Your weekly class schedule</p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden"
        >
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-4 text-left text-xs font-semibold text-gray-600 uppercase sticky left-0 bg-gray-50 z-10">
                    Time
                  </th>
                  {days.map(day => (
                    <th key={day} className="px-4 py-4 text-center text-xs font-semibold text-gray-600 uppercase min-w-[150px]">
                      {day}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {timeSlots.map((time, timeIndex) => (
                  <tr key={time}>
                    <td className="px-4 py-3 text-sm font-medium text-gray-700 sticky left-0 bg-white z-10">
                      <div className="flex items-center space-x-1">
                        <Clock className="w-4 h-4 text-gray-400" />
                        <span>{time}</span>
                      </div>
                    </td>
                    {days.map((day, dayIndex) => {
                      const slot = getSlotForDayAndTime(day, time);
                      return (
                        <td key={day} className="px-2 py-2">
                          {slot ? (
                            <motion.div
                              initial={{ opacity: 0, scale: 0.9 }}
                              animate={{ opacity: 1, scale: 1 }}
                              transition={{ delay: (timeIndex * days.length + dayIndex) * 0.02 }}
                              className="rounded-lg p-3 h-full"
                              style={{ backgroundColor: slot.color + '15', borderLeft: `3px solid ${slot.color}` }}
                            >
                              <p className="font-semibold text-sm text-gray-800 mb-1">{slot.subjectName}</p>
                              <p className="text-xs text-gray-600 mb-1">{slot.teacherName}</p>
                              <div className="flex items-center text-xs text-gray-500">
                                <MapPin className="w-3 h-3 mr-1" />
                                <span>{slot.room}</span>
                              </div>
                              <p className="text-xs text-gray-400 mt-1">{slot.startTime} - {slot.endTime}</p>
                            </motion.div>
                          ) : (
                            <div className="h-20 flex items-center justify-center text-gray-300 text-xs">
                              -
                            </div>
                          )}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {Array.from(new Set(timetable.map(s => s.subjectName))).map((subject, index) => {
            const slot = timetable.find(s => s.subjectName === subject)!;
            return (
              <motion.div
                key={subject}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 + index * 0.05 }}
                className="flex items-center space-x-2 p-3 bg-white rounded-lg border border-gray-100"
              >
                <div className="w-4 h-4 rounded" style={{ backgroundColor: slot.color }} />
                <span className="text-sm font-medium text-gray-700">{subject}</span>
              </motion.div>
            );
          })}
        </div>
      </div>
    </DashboardLayout>
  );
}
