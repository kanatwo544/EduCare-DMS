'use client';

import { useEffect, useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppStore } from '@/lib/store';
import { dashboardAPI, StudentDashboardData, TeacherDashboardData, AdminDashboardData } from '@/lib/apiContracts/dashboard';
import { StudentDashboard } from '@/components/dashboard/StudentDashboard';
import { TeacherDashboard } from '@/components/dashboard/TeacherDashboard';
import { AdminDashboard } from '@/components/dashboard/AdminDashboard';

export default function DashboardPage() {
  const { user } = useAppStore();
  const [dashboardData, setDashboardData] = useState<StudentDashboardData | TeacherDashboardData | AdminDashboardData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      dashboardAPI.getDashboardData({ role: user.role, userId: user.id })
        .then(data => {
          setDashboardData(data);
          setLoading(false);
        });
    }
  }, [user]);

  if (loading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#04ADEE]"></div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      {user?.role === 'student' && <StudentDashboard data={dashboardData as StudentDashboardData} />}
      {user?.role === 'teacher' && <TeacherDashboard data={dashboardData as TeacherDashboardData} />}
      {user?.role === 'admin' && <AdminDashboard data={dashboardData as AdminDashboardData} />}
    </DashboardLayout>
  );
}
