'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Upload, FileText, Download, Share, Folder } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppData } from '@/lib/context/AppDataContext';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export default function TeacherDrivePage() {
  const { resources } = useAppData();

  const teacherResources = resources.filter(r => r.uploadedBy.includes('Prof'));

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-gray-800">My Drive</h1>
            <p className="text-gray-600 mt-1">Manage and organize your teaching materials</p>
          </div>
          <Button className="bg-[#04ADEE] hover:bg-[#0398d4]">
            <Upload className="w-4 h-4 mr-2" />
            Upload Material
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {teacherResources.map((resource, index) => (
            <motion.div
              key={resource.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <FileText className="w-6 h-6 text-[#04ADEE]" />
                </div>
                <Badge>{resource.fileType}</Badge>
              </div>

              <h3 className="font-bold text-gray-800 mb-2 line-clamp-2">{resource.title}</h3>
              <p className="text-sm text-gray-600 mb-4 line-clamp-2">{resource.description}</p>

              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="flex-1">
                  <Share className="w-4 h-4 mr-1" />
                  Share
                </Button>
                <Button variant="outline" size="sm" className="flex-1">
                  <Download className="w-4 h-4 mr-1" />
                  Download
                </Button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
