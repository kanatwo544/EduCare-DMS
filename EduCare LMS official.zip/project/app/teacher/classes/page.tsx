'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Users, TrendingUp, Calendar, Award, User, X, BarChart3 } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppData } from '@/lib/context/AppDataContext';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';

interface StudentPerformance {
  id: string;
  name: string;
  email: string;
  average: number;
  attendance: number;
  assessments: {
    name: string;
    score: number;
    maxScore: number;
    date: string;
  }[];
}

export default function ClassesPage() {
  const { classes, students, subjects, feedbacks } = useAppData();
  const [selectedStudent, setSelectedStudent] = useState<StudentPerformance | null>(null);

  const currentTeacherId = 't1';
  const teacherClasses = classes.filter(cls => cls.teachers.includes(currentTeacherId));

  const calculateClassAverage = (classId: string) => {
    const classStudents = students.filter(s =>
      classes.find(c => c.id === classId)?.students.includes(s.id)
    );
    if (classStudents.length === 0) return 0;
    const sum = classStudents.reduce((acc, s) => acc + s.overallAverage, 0);
    return Math.round(sum / classStudents.length);
  };

  const calculateClassAttendance = (classId: string) => {
    const classStudents = students.filter(s =>
      classes.find(c => c.id === classId)?.students.includes(s.id)
    );
    if (classStudents.length === 0) return 0;
    const sum = classStudents.reduce((acc, s) => acc + s.attendance, 0);
    return Math.round(sum / classStudents.length);
  };

  const getStudentPerformance = (studentId: string): StudentPerformance | null => {
    const student = students.find(s => s.id === studentId);
    if (!student) return null;

    const studentFeedbacks = feedbacks.filter(f => f.studentId === studentId && f.grade !== undefined);
    const assessments = studentFeedbacks.map(f => ({
      name: f.assignmentName,
      score: f.grade!,
      maxScore: f.maxGrade!,
      date: f.submittedDate
    }));

    return {
      id: student.id,
      name: student.name,
      email: student.email,
      average: student.overallAverage,
      attendance: student.attendance,
      assessments
    };
  };

  const handleStudentClick = (studentId: string) => {
    const performance = getStudentPerformance(studentId);
    if (performance) {
      setSelectedStudent(performance);
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">My Classes</h1>
          <p className="text-gray-600 mt-1">Manage your classes and monitor student performance</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {teacherClasses.map((classItem, index) => {
            const classStudents = students.filter(s => classItem.students.includes(s.id));
            const classAverage = calculateClassAverage(classItem.id);
            const classAttendance = calculateClassAttendance(classItem.id);
            const classSubject = subjects.find(s => classItem.subjects.includes(s.id));

            return (
              <motion.div
                key={classItem.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
              >
                <div className="flex items-start justify-between mb-6">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Users className="w-6 h-6 text-[#04ADEE]" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-gray-800">{classItem.name}</h3>
                      <p className="text-sm text-gray-600">{classSubject?.name}</p>
                    </div>
                  </div>
                  <Badge className="bg-blue-100 text-blue-700">
                    {classStudents.length} Students
                  </Badge>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="p-4 bg-green-50 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <TrendingUp className="w-4 h-4 text-green-600" />
                      <span className="text-sm text-gray-600">Average</span>
                    </div>
                    <p className="text-2xl font-bold text-green-600">{classAverage}%</p>
                  </div>

                  <div className="p-4 bg-orange-50 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <Calendar className="w-4 h-4 text-orange-600" />
                      <span className="text-sm text-gray-600">Attendance</span>
                    </div>
                    <p className="text-2xl font-bold text-orange-600">{classAttendance}%</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="text-sm font-semibold text-gray-700 mb-3">Students</h4>
                  <div className="max-h-64 overflow-y-auto space-y-2">
                    {classStudents.map((student) => (
                      <motion.button
                        key={student.id}
                        onClick={() => handleStudentClick(student.id)}
                        whileHover={{ scale: 1.02 }}
                        className="w-full p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors flex items-center justify-between"
                      >
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-[#04ADEE] rounded-full flex items-center justify-center text-white text-sm font-medium">
                            {student.name[0]}
                          </div>
                          <span className="text-sm font-medium text-gray-800">{student.name}</span>
                        </div>
                        <div className="flex items-center space-x-3">
                          <span className="text-xs text-gray-500">{student.overallAverage}%</span>
                          <Award className={`w-4 h-4 ${
                            student.overallAverage >= 90 ? 'text-yellow-500' :
                            student.overallAverage >= 75 ? 'text-green-500' :
                            student.overallAverage >= 60 ? 'text-blue-500' :
                            'text-gray-400'
                          }`} />
                        </div>
                      </motion.button>
                    ))}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      <Dialog open={!!selectedStudent} onOpenChange={(open) => !open && setSelectedStudent(null)}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          {selectedStudent && (
            <>
              <DialogHeader>
                <DialogTitle className="text-2xl font-bold">
                  {selectedStudent.name} - Performance Overview
                </DialogTitle>
              </DialogHeader>

              <div className="space-y-6 mt-4">
                <div className="grid grid-cols-3 gap-4">
                  <div className="p-4 bg-blue-50 rounded-lg text-center">
                    <User className="w-6 h-6 text-[#04ADEE] mx-auto mb-2" />
                    <p className="text-xs text-gray-600 mb-1">Student ID</p>
                    <p className="text-sm font-bold text-gray-800">{selectedStudent.id.toUpperCase()}</p>
                  </div>

                  <div className="p-4 bg-green-50 rounded-lg text-center">
                    <TrendingUp className="w-6 h-6 text-green-600 mx-auto mb-2" />
                    <p className="text-xs text-gray-600 mb-1">Overall Average</p>
                    <p className="text-2xl font-bold text-green-600">{selectedStudent.average}%</p>
                  </div>

                  <div className="p-4 bg-orange-50 rounded-lg text-center">
                    <Calendar className="w-6 h-6 text-orange-600 mx-auto mb-2" />
                    <p className="text-xs text-gray-600 mb-1">Attendance</p>
                    <p className="text-2xl font-bold text-orange-600">{selectedStudent.attendance}%</p>
                  </div>
                </div>

                <div>
                  <h4 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                    <BarChart3 className="w-5 h-5 mr-2" />
                    Assessment History
                  </h4>
                  {selectedStudent.assessments.length > 0 ? (
                    <div className="space-y-3">
                      {selectedStudent.assessments.map((assessment, idx) => {
                        const percentage = Math.round((assessment.score / assessment.maxScore) * 100);
                        return (
                          <div key={idx} className="p-4 bg-gray-50 rounded-lg">
                            <div className="flex items-start justify-between mb-2">
                              <div className="flex-1">
                                <h5 className="font-semibold text-gray-800">{assessment.name}</h5>
                                <p className="text-xs text-gray-500">
                                  {new Date(assessment.date).toLocaleDateString()}
                                </p>
                              </div>
                              <div className="text-right">
                                <p className="text-xl font-bold text-[#04ADEE]">
                                  {assessment.score}/{assessment.maxScore}
                                </p>
                                <p className="text-xs text-gray-600">{percentage}%</p>
                              </div>
                            </div>
                            <Progress value={percentage} className="h-2" />
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="text-center py-8 bg-gray-50 rounded-lg">
                      <BarChart3 className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-600">No assessments recorded yet</p>
                    </div>
                  )}
                </div>

                <div className="flex justify-end pt-4 border-t">
                  <Button onClick={() => setSelectedStudent(null)}>
                    Close
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
