'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { UserCheck, UserX, Calendar, Save } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppData } from '@/lib/context/AppDataContext';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';

export default function TeacherAttendancePage() {
  const { classes, students, updateAttendance } = useAppData();
  const [selectedClass, setSelectedClass] = useState('');
  const [attendance, setAttendance] = useState<Record<string, boolean>>({});
  const [saving, setSaving] = useState(false);

  const currentTeacherId = 't1';
  const teacherClasses = classes.filter(cls => cls.teachers.includes(currentTeacherId));

  const handleClassSelect = (classId: string) => {
    setSelectedClass(classId);
    const selectedClassData = classes.find(c => c.id === classId);
    if (selectedClassData) {
      const initialAttendance: Record<string, boolean> = {};
      selectedClassData.students.forEach(studentId => {
        initialAttendance[studentId] = true;
      });
      setAttendance(initialAttendance);
    }
  };

  const toggleAttendance = (studentId: string) => {
    setAttendance(prev => ({
      ...prev,
      [studentId]: !prev[studentId]
    }));
  };

  const handleSave = async () => {
    setSaving(true);

    Object.entries(attendance).forEach(([studentId, isPresent]) => {
      updateAttendance(studentId, isPresent);
    });

    setTimeout(() => {
      setSaving(false);
    }, 1000);
  };

  const selectedClassData = classes.find(c => c.id === selectedClass);
  const classStudents = selectedClassData ? students.filter(s => selectedClassData.students.includes(s.id)) : [];

  const presentCount = Object.values(attendance).filter(a => a).length;
  const absentCount = Object.values(attendance).filter(a => !a).length;
  const attendanceRate = classStudents.length > 0 ? Math.round((presentCount / classStudents.length) * 100) : 0;

  return (
    <DashboardLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Mark Attendance</h1>
          <p className="text-gray-600 mt-1">Record daily attendance for your classes</p>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Select Class
              </label>
              <Select value={selectedClass} onValueChange={handleClassSelect}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a class" />
                </SelectTrigger>
                <SelectContent>
                  {teacherClasses.map(cls => (
                    <SelectItem key={cls.id} value={cls.id}>
                      {cls.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Date
              </label>
              <div className="flex items-center space-x-2 p-3 bg-gray-50 rounded-lg">
                <Calendar className="w-5 h-5 text-gray-600" />
                <span className="font-medium text-gray-800">
                  {new Date().toLocaleDateString('en-US', {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
                </span>
              </div>
            </div>
          </div>
        </div>

        {selectedClass && (
          <>
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 text-center">
                <UserCheck className="w-8 h-8 text-green-500 mx-auto mb-2" />
                <p className="text-3xl font-bold text-green-600">{presentCount}</p>
                <p className="text-sm text-gray-600">Present</p>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 text-center">
                <UserX className="w-8 h-8 text-red-500 mx-auto mb-2" />
                <p className="text-3xl font-bold text-red-600">{absentCount}</p>
                <p className="text-sm text-gray-600">Absent</p>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 text-center">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <span className="text-lg font-bold text-[#04ADEE]">%</span>
                </div>
                <p className="text-3xl font-bold text-[#04ADEE]">{attendanceRate}%</p>
                <p className="text-sm text-gray-600">Attendance Rate</p>
              </div>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
              <h2 className="text-lg font-bold text-gray-800 mb-4">Student List</h2>
              <div className="space-y-2">
                {classStudents.map((student, index) => {
                  const isPresent = attendance[student.id];
                  return (
                    <motion.div
                      key={student.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.03 }}
                      onClick={() => toggleAttendance(student.id)}
                      className={`flex items-center justify-between p-4 rounded-lg cursor-pointer transition-all ${
                        isPresent
                          ? 'bg-green-50 border-2 border-green-200'
                          : 'bg-red-50 border-2 border-red-200'
                      }`}
                    >
                      <div className="flex items-center space-x-4">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-medium ${
                          isPresent ? 'bg-green-500' : 'bg-red-500'
                        }`}>
                          {student.name[0]}
                        </div>
                        <div>
                          <p className="font-semibold text-gray-800">{student.name}</p>
                          <p className="text-xs text-gray-500">{student.email}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Badge className={isPresent ? "bg-green-500" : "bg-red-500"}>
                          {isPresent ? (
                            <>
                              <UserCheck className="w-4 h-4 mr-1" />
                              Present
                            </>
                          ) : (
                            <>
                              <UserX className="w-4 h-4 mr-1" />
                              Absent
                            </>
                          )}
                        </Badge>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>

            <div className="flex justify-end">
              <Button
                onClick={handleSave}
                disabled={saving}
                className="bg-[#04ADEE] hover:bg-[#0398d4] min-w-[150px]"
                size="lg"
              >
                {saving ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="w-5 h-5 mr-2" />
                    Save Attendance
                  </>
                )}
              </Button>
            </div>
          </>
        )}
      </div>
    </DashboardLayout>
  );
}
