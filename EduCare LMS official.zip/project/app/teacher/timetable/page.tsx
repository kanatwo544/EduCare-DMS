'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Calendar, Clock, Plus } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppData } from '@/lib/context/AppDataContext';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export default function TeacherTimetablePage() {
  const { timetable, classes } = useAppData();

  const currentTeacherId = 't1';
  const teacherTimetable = timetable.filter(t => t.teacherId === currentTeacherId);

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
  const timeSlots = ['09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00'];

  const getEventForSlot = (day: string, time: string) => {
    return teacherTimetable.find(t => t.day === day && t.time === time);
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-gray-800">My Timetable</h1>
            <p className="text-gray-600 mt-1">View your weekly teaching schedule</p>
          </div>
          <Button className="bg-[#04ADEE] hover:bg-[#0398d4]">
            <Plus className="w-4 h-4 mr-2" />
            Add Event
          </Button>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-200">
                  <th className="p-4 text-left text-sm font-semibold text-gray-700 w-32">Time</th>
                  {days.map(day => (
                    <th key={day} className="p-4 text-center text-sm font-semibold text-gray-700">
                      {day}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {timeSlots.map((time, timeIndex) => (
                  <tr key={time} className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="p-4 text-sm font-medium text-gray-600 bg-gray-50">
                      {time}
                    </td>
                    {days.map((day, dayIndex) => {
                      const event = getEventForSlot(day, time);
                      return (
                        <td key={`${day}-${time}`} className="p-2">
                          {event ? (
                            <motion.div
                              initial={{ opacity: 0, scale: 0.9 }}
                              animate={{ opacity: 1, scale: 1 }}
                              transition={{ delay: (timeIndex * 5 + dayIndex) * 0.01 }}
                              className="p-3 rounded-lg bg-blue-50 border border-blue-200 hover:shadow-md transition-shadow cursor-pointer"
                            >
                              <p className="text-sm font-semibold text-gray-800 mb-1">
                                {event.subject}
                              </p>
                              <p className="text-xs text-gray-600 mb-1">{event.room}</p>
                              <Badge className="text-xs bg-[#04ADEE]">
                                {event.class}
                              </Badge>
                            </motion.div>
                          ) : (
                            <div className="h-full min-h-[80px] flex items-center justify-center text-gray-300">
                              <Clock className="w-4 h-4" />
                            </div>
                          )}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
