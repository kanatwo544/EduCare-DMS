'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { MessageSquare, Send, Star } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppData } from '@/lib/context/AppDataContext';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

export default function FeedbackViewPage() {
  const { feedbacks, students, subjects } = useAppData();
  const [selectedFeedback, setSelectedFeedback] = useState<typeof feedbacks[0] | null>(null);
  const [response, setResponse] = useState('');

  const currentTeacherId = 't1';
  const teacherFeedbacks = feedbacks.filter(f => f.teacherId === currentTeacherId);

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Student Feedback</h1>
          <p className="text-gray-600 mt-1">View and respond to feedback from your students</p>
        </div>

        <div className="space-y-4">
          {teacherFeedbacks.map((feedback, index) => {
            const student = students.find(s => s.id === feedback.studentId);
            const subject = subjects.find(s => s.id === feedback.subjectId);

            return (
              <motion.div
                key={feedback.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                onClick={() => setSelectedFeedback(feedback)}
                className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow cursor-pointer"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-4 flex-1">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <MessageSquare className="w-6 h-6 text-[#04ADEE]" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-gray-800 mb-1">{feedback.assignmentName}</h3>
                      <p className="text-sm text-gray-600 mb-2">
                        {student?.name} • {subject?.name}
                      </p>
                      <p className="text-sm text-gray-700 line-clamp-2">{feedback.comment}</p>
                    </div>
                  </div>
                  {feedback.grade && (
                    <Badge className="bg-[#04ADEE] text-white">
                      {feedback.grade}/{feedback.maxGrade}
                    </Badge>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      <Dialog open={!!selectedFeedback} onOpenChange={(open) => !open && setSelectedFeedback(null)}>
        <DialogContent className="max-w-2xl">
          {selectedFeedback && (
            <>
              <DialogHeader>
                <DialogTitle>{selectedFeedback.assignmentName}</DialogTitle>
              </DialogHeader>

              <div className="space-y-4 mt-4">
                <div className="p-4 bg-gray-50 rounded-lg">
                  <p className="text-gray-700">{selectedFeedback.comment}</p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Your Response
                  </label>
                  <Textarea
                    value={response}
                    onChange={(e) => setResponse(e.target.value)}
                    placeholder="Write your response..."
                    className="min-h-[100px]"
                  />
                </div>

                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setSelectedFeedback(null)}>
                    Cancel
                  </Button>
                  <Button className="bg-[#04ADEE] hover:bg-[#0398d4]">
                    <Send className="w-4 h-4 mr-2" />
                    Send Response
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
