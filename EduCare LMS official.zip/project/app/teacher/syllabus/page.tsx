'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Plus, Check, Users, TrendingUp } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppData } from '@/lib/context/AppDataContext';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';

export default function TeacherSyllabusPage() {
  const { subjects, syllabusTopics, addSyllabusTopic, markTopicTaught } = useAppData();
  const [selectedSubject, setSelectedSubject] = useState('');
  const [newTopicName, setNewTopicName] = useState('');
  const [newSubtopics, setNewSubtopics] = useState('');

  const currentTeacherId = 't1';
  const teacherSubjects = subjects.filter(s => s.teacherId === currentTeacherId);

  const selectedSubjectTopics = syllabusTopics.filter(t => t.subjectId === selectedSubject);

  const calculateProgress = (subjectId: string) => {
    const topics = syllabusTopics.filter(t => t.subjectId === subjectId);
    if (topics.length === 0) return 0;

    const totalSubtopics = topics.reduce((acc, t) => acc + t.subtopics.length, 0);
    const completedSubtopics = topics.reduce((acc, t) =>
      acc + t.subtopics.filter(st => st.taught && st.understood).length, 0
    );

    return totalSubtopics > 0 ? Math.round((completedSubtopics / totalSubtopics) * 100) : 0;
  };

  const handleAddTopic = () => {
    if (!selectedSubject || !newTopicName || !newSubtopics) return;

    const subtopicsList = newSubtopics.split(',').map(s => s.trim()).filter(s => s);

    addSyllabusTopic({
      subjectId: selectedSubject,
      topic: newTopicName,
      subtopics: subtopicsList
    });

    setNewTopicName('');
    setNewSubtopics('');
  };

  const handleMarkTaught = (topicId: string, subtopicIndex: number) => {
    markTopicTaught(topicId, subtopicIndex);
  };

  return (
    <DashboardLayout>
      <div className="max-w-6xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Syllabus Management</h1>
          <p className="text-gray-600 mt-1">Track syllabus coverage with two-step accountability</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {teacherSubjects.map((subject) => {
            const progress = calculateProgress(subject.id);
            const topics = syllabusTopics.filter(t => t.subjectId === subject.id);

            return (
              <motion.div
                key={subject.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => setSelectedSubject(subject.id)}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <BookOpen className="w-6 h-6 text-[#04ADEE]" />
                  </div>
                  <Badge className="bg-green-100 text-green-700">
                    {progress}%
                  </Badge>
                </div>
                <h3 className="font-bold text-gray-800 mb-2">{subject.name}</h3>
                <p className="text-sm text-gray-600 mb-3">{topics.length} topics</p>
                <Progress value={progress} className="h-2" />
              </motion.div>
            );
          })}
        </div>

        {selectedSubject && (
          <>
            <div className="bg-white rounded-xl p-8 shadow-sm border border-gray-100">
              <h2 className="text-xl font-bold text-gray-800 mb-6">Add New Topic</h2>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="topicName">Topic Name</Label>
                  <Input
                    id="topicName"
                    value={newTopicName}
                    onChange={(e) => setNewTopicName(e.target.value)}
                    placeholder="e.g., Introduction to Variables"
                  />
                </div>

                <div className="md:col-span-2">
                  <Label htmlFor="subtopics">Subtopics (comma-separated)</Label>
                  <Input
                    id="subtopics"
                    value={newSubtopics}
                    onChange={(e) => setNewSubtopics(e.target.value)}
                    placeholder="e.g., Declaration, Initialization, Types"
                  />
                </div>
              </div>

              <Button
                onClick={handleAddTopic}
                disabled={!newTopicName || !newSubtopics}
                className="mt-4 bg-[#04ADEE] hover:bg-[#0398d4]"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Topic
              </Button>
            </div>

            <div className="space-y-4">
              {selectedSubjectTopics.map((topic) => {
                const totalSubtopics = topic.subtopics.length;
                const taughtCount = topic.subtopics.filter(st => st.taught).length;
                const understoodCount = topic.subtopics.filter(st => st.understood).length;
                const completedCount = topic.subtopics.filter(st => st.taught && st.understood).length;
                const progress = totalSubtopics > 0 ? (completedCount / totalSubtopics) * 100 : 0;

                return (
                  <motion.div
                    key={topic.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <h3 className="text-lg font-bold text-gray-800 mb-2">{topic.topic}</h3>
                        <div className="flex items-center space-x-4 text-sm">
                          <span className="text-gray-600">
                            <Check className="w-4 h-4 inline mr-1 text-green-500" />
                            Taught: {taughtCount}/{totalSubtopics}
                          </span>
                          <span className="text-gray-600">
                            <Users className="w-4 h-4 inline mr-1 text-blue-500" />
                            Understood: {understoodCount}/{totalSubtopics}
                          </span>
                          <span className="text-gray-600">
                            <TrendingUp className="w-4 h-4 inline mr-1 text-[#04ADEE]" />
                            Complete: {completedCount}/{totalSubtopics}
                          </span>
                        </div>
                      </div>
                      <Badge className="bg-blue-100 text-blue-700">
                        {Math.round(progress)}%
                      </Badge>
                    </div>

                    <Progress value={progress} className="h-2 mb-4" />

                    <div className="space-y-2">
                      {topic.subtopics.map((subtopic, index) => (
                        <div
                          key={index}
                          className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                        >
                          <span className="text-sm font-medium text-gray-800">{subtopic.name}</span>
                          <div className="flex items-center space-x-3">
                            <Button
                              size="sm"
                              variant={subtopic.taught ? "default" : "outline"}
                              onClick={() => handleMarkTaught(topic.id, index)}
                              className={subtopic.taught ? "bg-green-500 hover:bg-green-600" : ""}
                            >
                              <Check className="w-4 h-4 mr-1" />
                              {subtopic.taught ? "Taught" : "Mark Taught"}
                            </Button>
                            <Badge
                              variant={subtopic.understood ? "default" : "outline"}
                              className={subtopic.understood ? "bg-blue-500" : ""}
                            >
                              {subtopic.understood ? "✓ Understood" : "Pending Student"}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </>
        )}
      </div>
    </DashboardLayout>
  );
}
