'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Trash2, Save } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { quizAPI, QuizQuestion } from '@/lib/apiContracts/quiz';
import { useRouter } from 'next/navigation';

export default function CreateQuizPage() {
  const router = useRouter();
  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');
  const [duration, setDuration] = useState('30');
  const [dueDate, setDueDate] = useState('');
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [saving, setSaving] = useState(false);

  const addQuestion = (type: 'mcq' | 'text') => {
    const newQuestion: QuizQuestion = {
      id: 'q-' + Date.now(),
      type,
      question: '',
      options: type === 'mcq' ? ['', '', '', ''] : undefined,
      correctAnswer: type === 'mcq' ? 0 : undefined,
      points: 10
    };
    setQuestions([...questions, newQuestion]);
  };

  const updateQuestion = (id: string, field: string, value: any) => {
    setQuestions(questions.map(q =>
      q.id === id ? { ...q, [field]: value } : q
    ));
  };

  const updateOption = (questionId: string, optionIndex: number, value: string) => {
    setQuestions(questions.map(q =>
      q.id === questionId && q.options
        ? { ...q, options: q.options.map((opt, i) => i === optionIndex ? value : opt) }
        : q
    ));
  };

  const removeQuestion = (id: string) => {
    setQuestions(questions.filter(q => q.id !== id));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await quizAPI.createQuiz({
        title,
        subject,
        subjectId: '1',
        description,
        duration: parseInt(duration),
        dueDate,
        questions
      });
      router.push('/teacher/classes');
    } finally {
      setSaving(false);
    }
  };

  return (
    <DashboardLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-800">Create Quiz</h1>
            <p className="text-gray-600 mt-1">Design and publish a new quiz for your students</p>
          </div>
          <Button
            onClick={handleSave}
            disabled={saving || !title || !subject || questions.length === 0}
            className="bg-[#04ADEE] hover:bg-[#0398d4]"
          >
            <Save className="w-4 h-4 mr-2" />
            {saving ? 'Saving...' : 'Publish Quiz'}
          </Button>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 space-y-6"
        >
          <h3 className="text-lg font-semibold text-gray-800">Quiz Details</h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="title">Quiz Title *</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g., Algebra Fundamentals Quiz"
                className="mt-2"
              />
            </div>

            <div>
              <Label htmlFor="subject">Subject *</Label>
              <Select value={subject} onValueChange={setSubject}>
                <SelectTrigger className="mt-2">
                  <SelectValue placeholder="Select subject" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Mathematics">Mathematics</SelectItem>
                  <SelectItem value="Physics">Physics</SelectItem>
                  <SelectItem value="Chemistry">Chemistry</SelectItem>
                  <SelectItem value="Biology">Biology</SelectItem>
                  <SelectItem value="English">English</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="duration">Duration (minutes)</Label>
              <Input
                id="duration"
                type="number"
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
                className="mt-2"
              />
            </div>

            <div>
              <Label htmlFor="dueDate">Due Date</Label>
              <Input
                id="dueDate"
                type="datetime-local"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="mt-2"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Brief description of the quiz..."
              className="mt-2"
              rows={3}
            />
          </div>
        </motion.div>

        <div className="flex gap-3">
          <Button onClick={() => addQuestion('mcq')} variant="outline">
            <Plus className="w-4 h-4 mr-2" />
            Add MCQ
          </Button>
          <Button onClick={() => addQuestion('text')} variant="outline">
            <Plus className="w-4 h-4 mr-2" />
            Add Text Question
          </Button>
        </div>

        <div className="space-y-4">
          {questions.map((question, index) => (
            <motion.div
              key={question.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 space-y-4"
            >
              <div className="flex justify-between items-start">
                <h4 className="text-lg font-semibold text-gray-800">
                  Question {index + 1} ({question.type === 'mcq' ? 'Multiple Choice' : 'Text Answer'})
                </h4>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => removeQuestion(question.id)}
                  className="text-red-600 hover:text-red-700 hover:bg-red-50"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>

              <div>
                <Label>Question Text *</Label>
                <Textarea
                  value={question.question}
                  onChange={(e) => updateQuestion(question.id, 'question', e.target.value)}
                  placeholder="Enter your question here..."
                  className="mt-2"
                  rows={2}
                />
              </div>

              {question.type === 'mcq' && question.options && (
                <div className="space-y-3">
                  <Label>Options *</Label>
                  {question.options.map((option, optIndex) => (
                    <div key={optIndex} className="flex items-center gap-3">
                      <input
                        type="radio"
                        name={`correct-${question.id}`}
                        checked={question.correctAnswer === optIndex}
                        onChange={() => updateQuestion(question.id, 'correctAnswer', optIndex)}
                        className="w-4 h-4 text-[#04ADEE]"
                      />
                      <Input
                        value={option}
                        onChange={(e) => updateOption(question.id, optIndex, e.target.value)}
                        placeholder={`Option ${optIndex + 1}`}
                      />
                    </div>
                  ))}
                  <p className="text-xs text-gray-500">Select the correct answer</p>
                </div>
              )}

              <div className="w-32">
                <Label>Points</Label>
                <Input
                  type="number"
                  value={question.points}
                  onChange={(e) => updateQuestion(question.id, 'points', parseInt(e.target.value))}
                  className="mt-2"
                />
              </div>
            </motion.div>
          ))}

          {questions.length === 0 && (
            <div className="bg-gray-50 rounded-xl p-12 text-center">
              <p className="text-gray-500">No questions added yet. Click the buttons above to add questions.</p>
            </div>
          )}
        </div>

        <div className="bg-blue-50 rounded-xl p-6 border border-blue-100">
          <h4 className="font-semibold text-gray-800 mb-2">Quiz Summary</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div>
              <p className="text-gray-600">Total Questions</p>
              <p className="text-2xl font-bold text-[#04ADEE]">{questions.length}</p>
            </div>
            <div>
              <p className="text-gray-600">Total Points</p>
              <p className="text-2xl font-bold text-[#04ADEE]">
                {questions.reduce((sum, q) => sum + q.points, 0)}
              </p>
            </div>
            <div>
              <p className="text-gray-600">MCQ Questions</p>
              <p className="text-2xl font-bold text-[#04ADEE]">
                {questions.filter(q => q.type === 'mcq').length}
              </p>
            </div>
            <div>
              <p className="text-gray-600">Text Questions</p>
              <p className="text-2xl font-bold text-[#04ADEE]">
                {questions.filter(q => q.type === 'text').length}
              </p>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
