'use client';

import { useEffect, useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { Send, Search, MoreVertical, Circle, Paperclip, Users } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppData } from '@/lib/context/AppDataContext';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { ChatMessage } from '@/lib/demoData';

interface ChatRoom {
  id: string;
  name: string;
  type: 'individual' | 'group';
  participants: string[];
  lastMessage?: string;
  unreadCount: number;
}

export default function TeacherChatPage() {
  const { chatMessages, students, classes, sendMessage, teachers } = useAppData();
  const [selectedRoom, setSelectedRoom] = useState<ChatRoom | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const currentTeacherId = 't1';
  const currentTeacher = teachers.find(t => t.id === currentTeacherId);

  const rooms: ChatRoom[] = [
    ...students.map(student => ({
      id: `student-${student.id}`,
      name: student.name,
      type: 'individual' as const,
      participants: [currentTeacherId, student.id],
      lastMessage: chatMessages
        .filter(m =>
          (m.senderId === currentTeacherId && m.receiverId === student.id) ||
          (m.senderId === student.id && m.receiverId === currentTeacherId)
        )
        .slice(-1)[0]?.content,
      unreadCount: chatMessages.filter(m =>
        m.senderId === student.id &&
        m.receiverId === currentTeacherId &&
        !m.read
      ).length
    })),
    ...classes
      .filter(cls => cls.teachers.includes(currentTeacherId))
      .map(cls => ({
        id: `class-${cls.id}`,
        name: cls.name,
        type: 'group' as const,
        participants: [...cls.students, ...cls.teachers],
        lastMessage: 'Group chat',
        unreadCount: 0
      }))
  ];

  const filteredRooms = rooms.filter(room =>
    room.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getConversationMessages = (): ChatMessage[] => {
    if (!selectedRoom) return [];

    if (selectedRoom.type === 'individual') {
      const otherUserId = selectedRoom.participants.find(p => p !== currentTeacherId);
      return chatMessages
        .filter(m =>
          (m.senderId === currentTeacherId && m.receiverId === otherUserId) ||
          (m.senderId === otherUserId && m.receiverId === currentTeacherId)
        )
        .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
    }

    return [];
  };

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !selectedRoom) return;

    if (selectedRoom.type === 'individual') {
      const otherUserId = selectedRoom.participants.find(p => p !== currentTeacherId);
      if (otherUserId) {
        const receiver = students.find(s => s.id === otherUserId);
        sendMessage({
          senderId: currentTeacherId,
          senderName: currentTeacher?.name || 'Teacher',
          receiverId: otherUserId,
          receiverName: receiver?.name || 'User',
          content: newMessage
        });
      }
    }

    setNewMessage('');
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  useEffect(() => {
    if (filteredRooms.length > 0 && !selectedRoom) {
      setSelectedRoom(filteredRooms[0]);
    }
  }, []);

  const conversationMessages = getConversationMessages();

  return (
    <DashboardLayout>
      <div className="h-[calc(100vh-120px)]">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 h-full flex overflow-hidden">
          <div className="w-80 border-r border-gray-200 flex flex-col">
            <div className="p-4 border-b border-gray-200">
              <h2 className="text-xl font-bold text-gray-800 mb-3">Messages</h2>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search conversations..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>

            <div className="flex-1 overflow-y-auto">
              {filteredRooms.map((room, index) => {
                const isSelected = selectedRoom?.id === room.id;
                return (
                  <motion.div
                    key={room.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                    onClick={() => setSelectedRoom(room)}
                    className={`p-4 cursor-pointer hover:bg-gray-50 transition-colors border-l-4 ${
                      isSelected ? 'bg-blue-50 border-[#04ADEE]' : 'border-transparent'
                    }`}
                  >
                    <div className="flex items-start space-x-3">
                      <div className="relative">
                        <Avatar>
                          <AvatarFallback className="bg-[#04ADEE] text-white">
                            {room.type === 'group' ? (
                              <Users className="w-5 h-5" />
                            ) : (
                              room.name[0].toUpperCase()
                            )}
                          </AvatarFallback>
                        </Avatar>
                        {room.type === 'individual' && (
                          <Circle className="absolute bottom-0 right-0 w-3 h-3 fill-green-500 text-green-500" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-semibold text-gray-800 truncate">{room.name}</span>
                          {room.unreadCount > 0 && (
                            <span className="bg-[#04ADEE] text-white text-xs font-semibold px-2 py-0.5 rounded-full">
                              {room.unreadCount}
                            </span>
                          )}
                        </div>
                        {room.lastMessage && (
                          <p className="text-sm text-gray-600 truncate">{room.lastMessage}</p>
                        )}
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>

          <div className="flex-1 flex flex-col">
            {selectedRoom ? (
              <>
                <div className="p-4 border-b border-gray-200 flex items-center justify-between bg-gray-50">
                  <div className="flex items-center space-x-3">
                    <Avatar>
                      <AvatarFallback className="bg-[#04ADEE] text-white">
                        {selectedRoom.type === 'group' ? (
                          <Users className="w-5 h-5" />
                        ) : (
                          selectedRoom.name[0].toUpperCase()
                        )}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-semibold text-gray-800">{selectedRoom.name}</h3>
                      <p className="text-xs text-gray-500">
                        {selectedRoom.type === 'group'
                          ? `${selectedRoom.participants.length} members`
                          : 'Online'}
                      </p>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon">
                    <MoreVertical className="w-5 h-5" />
                  </Button>
                </div>

                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {conversationMessages.map((message, index) => {
                    const isOwn = message.senderId === currentTeacherId;
                    return (
                      <motion.div
                        key={message.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.02 }}
                        className={`flex ${isOwn ? 'justify-end' : 'justify-start'}`}
                      >
                        <div className={`flex items-end space-x-2 max-w-[70%] ${isOwn ? 'flex-row-reverse space-x-reverse' : ''}`}>
                          {!isOwn && (
                            <Avatar className="w-8 h-8">
                              <AvatarFallback className="bg-gray-200 text-xs">
                                {message.senderName[0]}
                              </AvatarFallback>
                            </Avatar>
                          )}
                          <div>
                            {!isOwn && (
                              <p className="text-xs text-gray-600 mb-1 px-3">{message.senderName}</p>
                            )}
                            <div
                              className={`px-4 py-2 rounded-2xl ${
                                isOwn
                                  ? 'bg-[#04ADEE] text-white rounded-br-none'
                                  : 'bg-gray-100 text-gray-800 rounded-bl-none'
                              }`}
                            >
                              <p className="text-sm">{message.content}</p>
                            </div>
                            <p className="text-xs text-gray-500 mt-1 px-3">
                              {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </p>
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}
                  <div ref={messagesEndRef} />
                </div>

                <div className="p-4 border-t border-gray-200 bg-gray-50">
                  <div className="flex items-center space-x-2">
                    <Button variant="ghost" size="icon" className="flex-shrink-0">
                      <Paperclip className="w-5 h-5 text-gray-600" />
                    </Button>
                    <Input
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                      placeholder="Type a message..."
                      className="flex-1"
                    />
                    <Button
                      onClick={handleSendMessage}
                      disabled={!newMessage.trim()}
                      className="bg-[#04ADEE] hover:bg-[#0398d4] flex-shrink-0"
                    >
                      <Send className="w-5 h-5" />
                    </Button>
                  </div>
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center text-gray-500">
                <div className="text-center">
                  <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Users className="w-12 h-12 text-gray-400" />
                  </div>
                  <p className="text-lg font-medium">Select a conversation</p>
                  <p className="text-sm text-gray-400 mt-1">Choose from your existing conversations or start a new one</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
