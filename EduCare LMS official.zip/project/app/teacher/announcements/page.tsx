'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Send, Bell, Users, CheckCircle } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppData } from '@/lib/context/AppDataContext';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export default function TeacherAnnouncementsPage() {
  const { addAnnouncement, teachers } = useAppData();
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [audience, setAudience] = useState('all');
  const [priority, setPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [posting, setPosting] = useState(false);
  const [posted, setPosted] = useState(false);

  const currentTeacherId = 't1';
  const currentTeacher = teachers.find(t => t.id === currentTeacherId);

  const handlePost = async () => {
    if (!title || !content) return;

    setPosting(true);

    addAnnouncement({
      title,
      content,
      author: currentTeacher?.name || 'Teacher',
      authorRole: 'teacher',
      targetAudience: audience as 'all' | 'students' | 'teachers',
      priority,
      date: new Date().toISOString()
    });

    setTimeout(() => {
      setPosting(false);
      setPosted(true);

      setTimeout(() => {
        setPosted(false);
        setTitle('');
        setContent('');
        setAudience('all');
        setPriority('medium');
      }, 2000);
    }, 1000);
  };

  return (
    <DashboardLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Create Announcement</h1>
          <p className="text-gray-600 mt-1">Share important updates with students and staff</p>
        </div>

        {posted ? (
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-green-50 border-2 border-green-500 rounded-xl p-12 text-center"
          >
            <CheckCircle className="w-20 h-20 text-green-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-green-800 mb-2">Announcement Posted!</h2>
            <p className="text-green-700">
              Your announcement has been sent to {audience === 'all' ? 'everyone' : audience}
            </p>
          </motion.div>
        ) : (
          <div className="bg-white rounded-xl p-8 shadow-sm border border-gray-100">
            <div className="space-y-6">
              <div>
                <Label htmlFor="title">Announcement Title</Label>
                <Input
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Enter announcement title"
                  className="mt-2"
                />
              </div>

              <div>
                <Label htmlFor="content">Message</Label>
                <Textarea
                  id="content"
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Write your announcement message here..."
                  className="mt-2 min-h-[200px]"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="audience">Target Audience</Label>
                  <Select value={audience} onValueChange={setAudience}>
                    <SelectTrigger id="audience" className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Everyone</SelectItem>
                      <SelectItem value="students">Students Only</SelectItem>
                      <SelectItem value="teachers">Teachers Only</SelectItem>
                      <SelectItem value="admin">Admin Only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="priority">Priority Level</Label>
                  <Select value={priority} onValueChange={(val) => setPriority(val as 'low' | 'medium' | 'high')}>
                    <SelectTrigger id="priority" className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low Priority</SelectItem>
                      <SelectItem value="medium">Medium Priority</SelectItem>
                      <SelectItem value="high">High Priority</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="pt-4 border-t border-gray-200">
                <Button
                  onClick={handlePost}
                  disabled={!title || !content || posting}
                  className="w-full bg-[#04ADEE] hover:bg-[#0398d4]"
                  size="lg"
                >
                  {posting ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                      Posting...
                    </>
                  ) : (
                    <>
                      <Send className="w-5 h-5 mr-2" />
                      Post Announcement
                    </>
                  )}
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
