'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { FileUp, Award, Users, CheckCircle, TrendingUp, Medal } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppData } from '@/lib/context/AppDataContext';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';

interface StudentMark {
  studentId: string;
  studentName: string;
  mark: number;
}

export default function UploadMarksPage() {
  const { classes, students, subjects, submitFeedback } = useAppData();
  const [selectedClass, setSelectedClass] = useState('');
  const [assessmentName, setAssessmentName] = useState('');
  const [totalScore, setTotalScore] = useState('100');
  const [feedbackComment, setFeedbackComment] = useState('');
  const [studentMarks, setStudentMarks] = useState<StudentMark[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const currentTeacherId = 't1';
  const teacherClasses = classes.filter(cls => cls.teachers.includes(currentTeacherId));

  const handleClassSelect = (classId: string) => {
    setSelectedClass(classId);
    const selectedClassData = classes.find(c => c.id === classId);
    if (selectedClassData) {
      const classStudents = students.filter(s => selectedClassData.students.includes(s.id));
      setStudentMarks(
        classStudents.map(s => ({
          studentId: s.id,
          studentName: s.name,
          mark: 0
        }))
      );
    }
  };

  const updateStudentMark = (studentId: string, mark: string) => {
    const numMark = parseInt(mark) || 0;
    setStudentMarks(prev =>
      prev.map(sm =>
        sm.studentId === studentId ? { ...sm, mark: numMark } : sm
      )
    );
  };

  const handleSubmit = async () => {
    if (!selectedClass || !assessmentName || studentMarks.length === 0) return;

    setSubmitting(true);

    const selectedClassData = classes.find(c => c.id === selectedClass);
    const subject = subjects.find(s => selectedClassData?.subjects.includes(s.id));

    studentMarks.forEach(sm => {
      submitFeedback({
        studentId: sm.studentId,
        teacherId: currentTeacherId,
        subjectId: subject?.id || '',
        assignmentName: assessmentName,
        comment: feedbackComment || `Score: ${sm.mark}/${totalScore}`,
        grade: sm.mark,
        maxGrade: parseInt(totalScore)
      });
    });

    setTimeout(() => {
      setSubmitting(false);
      setSubmitted(true);

      setTimeout(() => {
        setSubmitted(false);
        setSelectedClass('');
        setAssessmentName('');
        setTotalScore('100');
        setFeedbackComment('');
        setStudentMarks([]);
      }, 2000);
    }, 1000);
  };

  const calculateAverage = () => {
    if (studentMarks.length === 0) return 0;
    const sum = studentMarks.reduce((acc, sm) => acc + sm.mark, 0);
    const maxPossible = studentMarks.length * parseInt(totalScore);
    return Math.round((sum / maxPossible) * 100);
  };

  const getRankedStudents = () => {
    return [...studentMarks]
      .sort((a, b) => b.mark - a.mark)
      .map((sm, index) => ({ ...sm, rank: index + 1 }));
  };

  const getPerformanceColor = (mark: number, total: number) => {
    const percentage = (mark / total) * 100;
    if (percentage >= 90) return 'text-yellow-600 bg-yellow-50';
    if (percentage >= 75) return 'text-green-600 bg-green-50';
    if (percentage >= 60) return 'text-blue-600 bg-blue-50';
    return 'text-gray-600 bg-gray-50';
  };

  const getMedalIcon = (rank: number) => {
    if (rank === 1) return <Medal className="w-5 h-5 text-yellow-500" />;
    if (rank === 2) return <Medal className="w-5 h-5 text-gray-400" />;
    if (rank === 3) return <Medal className="w-5 h-5 text-orange-600" />;
    return <span className="w-5 h-5 flex items-center justify-center text-sm font-bold text-gray-500">#{rank}</span>;
  };

  return (
    <DashboardLayout>
      <div className="max-w-6xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Upload Assessment Marks</h1>
          <p className="text-gray-600 mt-1">Create assessments and record student performance</p>
        </div>

        {submitted ? (
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-green-50 border-2 border-green-500 rounded-xl p-12 text-center"
          >
            <CheckCircle className="w-20 h-20 text-green-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-green-800 mb-2">Marks Uploaded Successfully!</h2>
            <p className="text-green-700">
              Student dashboards have been updated with the new assessment results
            </p>
          </motion.div>
        ) : (
          <>
            <div className="bg-white rounded-xl p-8 shadow-sm border border-gray-100">
              <h2 className="text-xl font-bold text-gray-800 mb-6">Assessment Details</h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="class">Select Class</Label>
                  <Select value={selectedClass} onValueChange={handleClassSelect}>
                    <SelectTrigger id="class">
                      <SelectValue placeholder="Choose a class" />
                    </SelectTrigger>
                    <SelectContent>
                      {teacherClasses.map(cls => {
                        const subject = subjects.find(s => cls.subjects.includes(s.id));
                        return (
                          <SelectItem key={cls.id} value={cls.id}>
                            {cls.name} - {subject?.name}
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="assessmentName">Assessment Name</Label>
                  <Input
                    id="assessmentName"
                    value={assessmentName}
                    onChange={(e) => setAssessmentName(e.target.value)}
                    placeholder="e.g., Midterm Exam, Quiz 1"
                  />
                </div>

                <div>
                  <Label htmlFor="totalScore">Total Score</Label>
                  <Input
                    id="totalScore"
                    type="number"
                    value={totalScore}
                    onChange={(e) => setTotalScore(e.target.value)}
                    placeholder="100"
                  />
                </div>

                <div>
                  <Label htmlFor="feedback">Feedback Comment (Optional)</Label>
                  <Input
                    id="feedback"
                    value={feedbackComment}
                    onChange={(e) => setFeedbackComment(e.target.value)}
                    placeholder="General feedback for all students"
                  />
                </div>
              </div>
            </div>

            {studentMarks.length > 0 && (
              <>
                <div className="bg-white rounded-xl p-8 shadow-sm border border-gray-100">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-xl font-bold text-gray-800">Student Marks</h2>
                    <Badge className="bg-blue-100 text-blue-700">
                      <Users className="w-4 h-4 mr-1" />
                      {studentMarks.length} Students
                    </Badge>
                  </div>

                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {studentMarks.map((sm, index) => (
                      <motion.div
                        key={sm.studentId}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.03 }}
                        className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg"
                      >
                        <div className="w-10 h-10 bg-[#04ADEE] rounded-full flex items-center justify-center text-white font-medium flex-shrink-0">
                          {sm.studentName[0]}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-gray-800">{sm.studentName}</p>
                          <p className="text-xs text-gray-500">{sm.studentId.toUpperCase()}</p>
                        </div>
                        <div className="flex items-center space-x-3">
                          <Input
                            type="number"
                            value={sm.mark || ''}
                            onChange={(e) => updateStudentMark(sm.studentId, e.target.value)}
                            className="w-24 text-center"
                            placeholder="0"
                            min="0"
                            max={totalScore}
                          />
                          <span className="text-gray-500 font-medium">/ {totalScore}</span>
                          <Badge className={getPerformanceColor(sm.mark, parseInt(totalScore))}>
                            {Math.round((sm.mark / parseInt(totalScore)) * 100)}%
                          </Badge>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                        <TrendingUp className="w-5 h-5 text-green-600" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Class Average</p>
                        <p className="text-2xl font-bold text-green-600">{calculateAverage()}%</p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <Award className="w-5 h-5 text-[#04ADEE]" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Top Scorer</p>
                        <p className="text-lg font-bold text-[#04ADEE]">
                          {getRankedStudents()[0]?.studentName || 'N/A'}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-xl p-8 shadow-sm border border-gray-100">
                  <h3 className="text-lg font-bold text-gray-800 mb-4">Performance Hierarchy</h3>
                  <div className="space-y-2">
                    {getRankedStudents().map((student, index) => (
                      <motion.div
                        key={student.studentId}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.03 }}
                        className={`flex items-center space-x-4 p-4 rounded-lg ${
                          student.rank <= 3 ? 'bg-gradient-to-r from-yellow-50 to-white border border-yellow-200' : 'bg-gray-50'
                        }`}
                      >
                        <div className="flex items-center space-x-3 flex-1">
                          {getMedalIcon(student.rank)}
                          <p className="font-semibold text-gray-800">{student.studentName}</p>
                        </div>
                        <div className="flex items-center space-x-4">
                          <p className="text-lg font-bold text-[#04ADEE]">
                            {student.mark}/{totalScore}
                          </p>
                          <Badge className={getPerformanceColor(student.mark, parseInt(totalScore))}>
                            {Math.round((student.mark / parseInt(totalScore)) * 100)}%
                          </Badge>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button
                    onClick={handleSubmit}
                    disabled={!assessmentName || submitting}
                    className="bg-[#04ADEE] hover:bg-[#0398d4] min-w-[200px]"
                    size="lg"
                  >
                    {submitting ? (
                      <>
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                        Uploading...
                      </>
                    ) : (
                      <>
                        <FileUp className="w-5 h-5 mr-2" />
                        Upload Marks
                      </>
                    )}
                  </Button>
                </div>
              </>
            )}
          </>
        )}
      </div>
    </DashboardLayout>
  );
}
