export interface Feedback {
  id: string;
  studentId: string;
  studentName: string;
  teacherId: string;
  teacherName: string;
  subjectId: string;
  subjectName: string;
  rating: number;
  comment: string;
  createdAt: string;
  anonymous: boolean;
}

export interface SubmitFeedbackRequest {
  teacherId: string;
  subjectId: string;
  rating: number;
  comment: string;
  anonymous?: boolean;
}

export interface SubmitFeedbackResponse {
  success: boolean;
  feedbackId: string;
  message: string;
}

export const feedbackAPI = {
  async submitFeedback(data: SubmitFeedbackRequest): Promise<SubmitFeedbackResponse> {
    await new Promise(resolve => setTimeout(resolve, 500));

    return {
      success: true,
      feedbackId: 'feedback-' + Date.now(),
      message: 'Feedback submitted successfully'
    };
  },

  async getFeedback(teacherId: string): Promise<Feedback[]> {
    await new Promise(resolve => setTimeout(resolve, 500));

    return [
      {
        id: 'fb1',
        studentId: 's1',
        studentName: 'Alice Johnson',
        teacherId,
        teacherName: 'Dr. Smith',
        subjectId: '1',
        subjectName: 'Mathematics',
        rating: 5,
        comment: 'Excellent teaching style! Very clear explanations and patient with questions.',
        createdAt: '2024-03-01T10:00:00',
        anonymous: false
      },
      {
        id: 'fb2',
        studentId: 's2',
        studentName: 'Anonymous',
        teacherId,
        teacherName: 'Dr. Smith',
        subjectId: '1',
        subjectName: 'Mathematics',
        rating: 4,
        comment: 'Good teacher, but sometimes moves too fast through topics.',
        createdAt: '2024-02-28T15:30:00',
        anonymous: true
      },
      {
        id: 'fb3',
        studentId: 's3',
        studentName: 'Charlie Brown',
        teacherId,
        teacherName: 'Dr. Smith',
        subjectId: '1',
        subjectName: 'Mathematics',
        rating: 5,
        comment: 'Very helpful and always available for doubt clearing sessions.',
        createdAt: '2024-02-25T11:20:00',
        anonymous: false
      },
      {
        id: 'fb4',
        studentId: 's4',
        studentName: 'Diana Prince',
        teacherId,
        teacherName: 'Dr. Smith',
        subjectId: '1',
        subjectName: 'Mathematics',
        rating: 4,
        comment: 'Great examples and practice problems. Would appreciate more video resources.',
        createdAt: '2024-02-20T14:10:00',
        anonymous: false
      }
    ];
  }
};
