import { STUDENTS, TEACHERS, ADMIN } from '../demoData';

export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse {
  success: boolean;
  user: {
    id: string;
    name: string;
    email: string;
    role: 'student' | 'teacher' | 'admin';
    avatar?: string;
  };
  token: string;
}

export interface ForgotPasswordRequest {
  email: string;
}

export interface ForgotPasswordResponse {
  success: boolean;
  message: string;
}

export const authAPI = {
  async login(data: LoginRequest): Promise<LoginResponse> {
    await new Promise(resolve => setTimeout(resolve, 1000));

    const student = STUDENTS.find(s => s.email === data.email);
    if (student) {
      return {
        success: true,
        user: {
          id: student.id,
          name: student.name,
          email: student.email,
          role: 'student',
          avatar: student.avatar
        },
        token: 'mock-jwt-token-' + Date.now()
      };
    }

    const teacher = TEACHERS.find(t => t.email === data.email);
    if (teacher) {
      return {
        success: true,
        user: {
          id: teacher.id,
          name: teacher.name,
          email: teacher.email,
          role: 'teacher',
          avatar: teacher.avatar
        },
        token: 'mock-jwt-token-' + Date.now()
      };
    }

    if (data.email === ADMIN.email) {
      return {
        success: true,
        user: {
          id: ADMIN.id,
          name: ADMIN.name,
          email: ADMIN.email,
          role: 'admin',
          avatar: ADMIN.avatar
        },
        token: 'mock-jwt-token-' + Date.now()
      };
    }

    return {
      success: true,
      user: {
        id: 's1',
        name: 'Demo User',
        email: data.email,
        role: data.email.includes('teacher') ? 'teacher' : data.email.includes('admin') ? 'admin' : 'student',
        avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=' + data.email
      },
      token: 'mock-jwt-token-' + Date.now()
    };
  },

  async forgotPassword(data: ForgotPasswordRequest): Promise<ForgotPasswordResponse> {
    await new Promise(resolve => setTimeout(resolve, 1000));

    return {
      success: true,
      message: 'Password reset link sent to your email'
    };
  }
};
