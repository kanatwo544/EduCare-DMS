export interface QuizQuestion {
  id: string;
  type: 'mcq' | 'text';
  question: string;
  options?: string[];
  correctAnswer?: string | number;
  points: number;
}

export interface Quiz {
  id: string;
  title: string;
  subject: string;
  subjectId: string;
  description: string;
  duration: number;
  totalPoints: number;
  dueDate: string;
  questions: QuizQuestion[];
  status: 'draft' | 'published';
  createdBy: string;
  createdAt: string;
}

export interface CreateQuizRequest {
  title: string;
  subject: string;
  subjectId: string;
  description: string;
  duration: number;
  dueDate: string;
  questions: QuizQuestion[];
}

export interface CreateQuizResponse {
  success: boolean;
  quizId: string;
  message: string;
}

export interface QuizAttempt {
  id: string;
  quizId: string;
  studentId: string;
  answers: Record<string, string | number>;
  startTime: string;
  endTime?: string;
  score?: number;
  status: 'in_progress' | 'submitted' | 'graded';
}

export interface SubmitQuizRequest {
  quizId: string;
  studentId: string;
  answers: Record<string, string | number>;
}

export interface SubmitQuizResponse {
  success: boolean;
  attemptId: string;
  autoGradedScore?: number;
  message: string;
}

export interface GradeQuizRequest {
  attemptId: string;
  grades: Record<string, number>;
  feedback?: string;
}

export interface GradeQuizResponse {
  success: boolean;
  finalScore: number;
  message: string;
}

export const quizAPI = {
  async createQuiz(data: CreateQuizRequest): Promise<CreateQuizResponse> {
    await new Promise(resolve => setTimeout(resolve, 800));

    return {
      success: true,
      quizId: 'quiz-' + Date.now(),
      message: 'Quiz created successfully'
    };
  },

  async getQuiz(quizId: string): Promise<Quiz> {
    await new Promise(resolve => setTimeout(resolve, 500));

    return {
      id: quizId,
      title: 'Algebra Fundamentals Quiz',
      subject: 'Mathematics',
      subjectId: '1',
      description: 'Test your understanding of basic algebra concepts',
      duration: 30,
      totalPoints: 100,
      dueDate: '2024-03-20T23:59:59',
      status: 'published',
      createdBy: 'Dr. Smith',
      createdAt: '2024-03-01T10:00:00',
      questions: [
        {
          id: 'q1',
          type: 'mcq',
          question: 'What is the value of x in the equation 2x + 5 = 15?',
          options: ['3', '5', '7', '10'],
          correctAnswer: 1,
          points: 20
        },
        {
          id: 'q2',
          type: 'mcq',
          question: 'Simplify: 3x + 2x',
          options: ['5x', '6x', '5x²', '6'],
          correctAnswer: 0,
          points: 20
        },
        {
          id: 'q3',
          type: 'text',
          question: 'Explain the distributive property with an example',
          points: 30
        },
        {
          id: 'q4',
          type: 'mcq',
          question: 'What is the slope of the line y = 3x + 2?',
          options: ['2', '3', '5', '1'],
          correctAnswer: 1,
          points: 15
        },
        {
          id: 'q5',
          type: 'text',
          question: 'Solve for x: x² - 5x + 6 = 0',
          points: 15
        }
      ]
    };
  },

  async submitQuiz(data: SubmitQuizRequest): Promise<SubmitQuizResponse> {
    await new Promise(resolve => setTimeout(resolve, 1000));

    return {
      success: true,
      attemptId: 'attempt-' + Date.now(),
      autoGradedScore: 55,
      message: 'Quiz submitted successfully. MCQ questions have been auto-graded.'
    };
  },

  async getQuizAttempts(quizId: string): Promise<QuizAttempt[]> {
    await new Promise(resolve => setTimeout(resolve, 500));

    return [
      {
        id: 'attempt-1',
        quizId,
        studentId: 'student-1',
        answers: { q1: 1, q2: 0, q3: 'The distributive property...', q4: 1, q5: 'x = 2 or x = 3' },
        startTime: '2024-03-15T10:00:00',
        endTime: '2024-03-15T10:25:00',
        score: 85,
        status: 'graded'
      },
      {
        id: 'attempt-2',
        quizId,
        studentId: 'student-2',
        answers: { q1: 1, q2: 0, q3: 'Example...', q4: 0, q5: 'x = 2, 3' },
        startTime: '2024-03-15T11:00:00',
        endTime: '2024-03-15T11:28:00',
        status: 'submitted'
      }
    ];
  },

  async gradeQuiz(data: GradeQuizRequest): Promise<GradeQuizResponse> {
    await new Promise(resolve => setTimeout(resolve, 800));

    return {
      success: true,
      finalScore: 88,
      message: 'Quiz graded successfully'
    };
  }
};
