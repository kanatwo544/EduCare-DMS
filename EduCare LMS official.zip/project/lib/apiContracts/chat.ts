export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderAvatar?: string;
  content: string;
  timestamp: string;
  read: boolean;
}

export interface ChatRoom {
  id: string;
  name: string;
  type: 'direct' | 'group' | 'class';
  participants: Array<{
    id: string;
    name: string;
    avatar?: string;
    role: 'student' | 'teacher' | 'admin';
    online: boolean;
  }>;
  lastMessage?: ChatMessage;
  unreadCount: number;
}

export interface SendMessageRequest {
  roomId: string;
  content: string;
}

export interface SendMessageResponse {
  success: boolean;
  messageId: string;
  timestamp: string;
}

export const chatAPI = {
  async getChatRooms(userId: string): Promise<ChatRoom[]> {
    await new Promise(resolve => setTimeout(resolve, 500));

    return [
      {
        id: 'room1',
        name: 'Mathematics Class',
        type: 'class',
        participants: [
          { id: 't1', name: 'Dr. Smith', role: 'teacher', online: true },
          { id: 's1', name: 'Alice Johnson', role: 'student', online: true },
          { id: 's2', name: 'Bob Smith', role: 'student', online: false }
        ],
        lastMessage: {
          id: 'm1',
          senderId: 't1',
          senderName: 'Dr. Smith',
          content: 'Tomorrow\'s class will focus on derivatives',
          timestamp: '2024-03-05T15:30:00',
          read: false
        },
        unreadCount: 2
      },
      {
        id: 'room2',
        name: 'Dr. Smith',
        type: 'direct',
        participants: [
          { id: 't1', name: 'Dr. Smith', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=smith', role: 'teacher', online: true }
        ],
        lastMessage: {
          id: 'm2',
          senderId: 't1',
          senderName: 'Dr. Smith',
          content: 'Great work on the last assignment!',
          timestamp: '2024-03-04T14:20:00',
          read: true
        },
        unreadCount: 0
      },
      {
        id: 'room3',
        name: 'Study Group',
        type: 'group',
        participants: [
          { id: 's1', name: 'Alice Johnson', role: 'student', online: true },
          { id: 's2', name: 'Bob Smith', role: 'student', online: true },
          { id: 's3', name: 'Charlie Brown', role: 'student', online: false }
        ],
        lastMessage: {
          id: 'm3',
          senderId: 's1',
          senderName: 'Alice Johnson',
          content: 'Anyone up for a study session this weekend?',
          timestamp: '2024-03-03T18:45:00',
          read: true
        },
        unreadCount: 0
      }
    ];
  },

  async getMessages(roomId: string): Promise<ChatMessage[]> {
    await new Promise(resolve => setTimeout(resolve, 500));

    return [
      {
        id: 'm1',
        senderId: 's1',
        senderName: 'You',
        content: 'Hi Dr. Smith, I have a question about today\'s lecture',
        timestamp: '2024-03-05T14:00:00',
        read: true
      },
      {
        id: 'm2',
        senderId: 't1',
        senderName: 'Dr. Smith',
        senderAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=smith',
        content: 'Sure! What would you like to know?',
        timestamp: '2024-03-05T14:02:00',
        read: true
      },
      {
        id: 'm3',
        senderId: 's1',
        senderName: 'You',
        content: 'Could you explain the concept of limits again?',
        timestamp: '2024-03-05T14:03:00',
        read: true
      },
      {
        id: 'm4',
        senderId: 't1',
        senderName: 'Dr. Smith',
        senderAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=smith',
        content: 'Of course! A limit describes the value that a function approaches as the input approaches some value.',
        timestamp: '2024-03-05T14:05:00',
        read: true
      },
      {
        id: 'm5',
        senderId: 't1',
        senderName: 'Dr. Smith',
        senderAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=smith',
        content: 'Let me share a document that explains this in detail...',
        timestamp: '2024-03-05T14:06:00',
        read: true
      }
    ];
  },

  async sendMessage(data: SendMessageRequest): Promise<SendMessageResponse> {
    await new Promise(resolve => setTimeout(resolve, 300));

    return {
      success: true,
      messageId: 'msg-' + Date.now(),
      timestamp: new Date().toISOString()
    };
  },

  simulateTyping(roomId: string, userId: string): void {
    console.log(`User ${userId} is typing in room ${roomId}`);
  }
};
