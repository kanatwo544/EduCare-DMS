export interface Announcement {
  id: string;
  title: string;
  content: string;
  author: string;
  authorRole: 'teacher' | 'admin';
  createdAt: string;
  targetAudience: 'all' | 'students' | 'teachers' | 'class';
  classId?: string;
  subjectId?: string;
  priority: 'low' | 'medium' | 'high';
  attachments?: Array<{
    id: string;
    name: string;
    url: string;
  }>;
}

export interface CreateAnnouncementRequest {
  title: string;
  content: string;
  targetAudience: 'all' | 'students' | 'teachers' | 'class';
  classId?: string;
  subjectId?: string;
  priority: 'low' | 'medium' | 'high';
}

export interface CreateAnnouncementResponse {
  success: boolean;
  announcementId: string;
  message: string;
}

export const announcementsAPI = {
  async getAnnouncements(userId: string, role: 'student' | 'teacher' | 'admin'): Promise<Announcement[]> {
    await new Promise(resolve => setTimeout(resolve, 500));

    return [
      {
        id: 'a1',
        title: 'Mid-term Exam Schedule',
        content: 'Mid-term examinations will be conducted from March 15th to March 20th. Please check the detailed timetable in your student portal.',
        author: 'Admin Office',
        authorRole: 'admin',
        createdAt: '2024-03-01T09:00:00',
        targetAudience: 'all',
        priority: 'high'
      },
      {
        id: 'a2',
        title: 'Annual Science Fair',
        content: 'The annual science fair will be held on March 25th. All students are encouraged to participate. Registration deadline is March 10th.',
        author: 'Dr. Smith',
        authorRole: 'teacher',
        createdAt: '2024-03-02T10:30:00',
        targetAudience: 'students',
        priority: 'medium'
      },
      {
        id: 'a3',
        title: 'Mathematics Workshop',
        content: 'A special workshop on advanced calculus will be conducted this Saturday at 10 AM in Room 205.',
        author: 'Dr. Smith',
        authorRole: 'teacher',
        createdAt: '2024-03-03T14:00:00',
        targetAudience: 'students',
        priority: 'medium',
        subjectId: '1'
      },
      {
        id: 'a4',
        title: 'Parent-Teacher Meeting',
        content: 'Parent-teacher meetings are scheduled for March 22nd. Please coordinate with parents to ensure attendance.',
        author: 'Admin Office',
        authorRole: 'admin',
        createdAt: '2024-02-28T11:00:00',
        targetAudience: 'teachers',
        priority: 'high'
      },
      {
        id: 'a5',
        title: 'Library Hours Extended',
        content: 'The library will now be open until 8 PM on weekdays to accommodate exam preparation.',
        author: 'Librarian',
        authorRole: 'admin',
        createdAt: '2024-02-27T15:30:00',
        targetAudience: 'all',
        priority: 'low'
      }
    ];
  },

  async createAnnouncement(data: CreateAnnouncementRequest): Promise<CreateAnnouncementResponse> {
    await new Promise(resolve => setTimeout(resolve, 500));

    return {
      success: true,
      announcementId: 'announcement-' + Date.now(),
      message: 'Announcement created successfully'
    };
  }
};
