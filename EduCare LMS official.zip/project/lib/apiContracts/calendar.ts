export interface CalendarEvent {
  id: string;
  title: string;
  description?: string;
  startTime: string;
  endTime: string;
  type: 'class' | 'exam' | 'assignment' | 'event' | 'holiday';
  subjectId?: string;
  subjectName?: string;
  location?: string;
  color?: string;
}

export interface TimetableSlot {
  id: string;
  day: 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday';
  startTime: string;
  endTime: string;
  subjectId: string;
  subjectName: string;
  teacherName: string;
  room: string;
  color: string;
}

export const calendarAPI = {
  async getCalendarEvents(userId: string, startDate: string, endDate: string): Promise<CalendarEvent[]> {
    await new Promise(resolve => setTimeout(resolve, 500));

    return [
      {
        id: 'e1',
        title: 'Mathematics Class',
        startTime: '2024-03-15T09:00:00',
        endTime: '2024-03-15T10:00:00',
        type: 'class',
        subjectId: '1',
        subjectName: 'Mathematics',
        location: 'Room 101',
        color: '#04ADEE'
      },
      {
        id: 'e2',
        title: 'Physics Lab',
        startTime: '2024-03-15T11:00:00',
        endTime: '2024-03-15T13:00:00',
        type: 'class',
        subjectId: '2',
        subjectName: 'Physics',
        location: 'Lab 2',
        color: '#10B981'
      },
      {
        id: 'e3',
        title: 'Mid-term Exam - Mathematics',
        startTime: '2024-03-18T10:00:00',
        endTime: '2024-03-18T12:00:00',
        type: 'exam',
        subjectId: '1',
        subjectName: 'Mathematics',
        location: 'Exam Hall',
        color: '#EF4444'
      },
      {
        id: 'e4',
        title: 'Chemistry Assignment Due',
        startTime: '2024-03-20T23:59:00',
        endTime: '2024-03-20T23:59:00',
        type: 'assignment',
        subjectId: '3',
        subjectName: 'Chemistry',
        color: '#F59E0B'
      },
      {
        id: 'e5',
        title: 'Parent-Teacher Meeting',
        description: 'Annual parent-teacher meeting',
        startTime: '2024-03-22T14:00:00',
        endTime: '2024-03-22T17:00:00',
        type: 'event',
        location: 'Auditorium',
        color: '#8B5CF6'
      },
      {
        id: 'e6',
        title: 'Science Fair',
        description: 'Annual science fair exhibition',
        startTime: '2024-03-25T09:00:00',
        endTime: '2024-03-25T16:00:00',
        type: 'event',
        location: 'Main Ground',
        color: '#06B6D4'
      }
    ];
  },

  async getTimetable(userId: string, role: 'student' | 'teacher'): Promise<TimetableSlot[]> {
    await new Promise(resolve => setTimeout(resolve, 500));

    return [
      {
        id: 't1',
        day: 'Monday',
        startTime: '09:00',
        endTime: '10:00',
        subjectId: '1',
        subjectName: 'Mathematics',
        teacherName: 'Dr. Smith',
        room: 'Room 101',
        color: '#04ADEE'
      },
      {
        id: 't2',
        day: 'Monday',
        startTime: '10:15',
        endTime: '11:15',
        subjectId: '2',
        subjectName: 'Physics',
        teacherName: 'Prof. Johnson',
        room: 'Room 102',
        color: '#10B981'
      },
      {
        id: 't3',
        day: 'Monday',
        startTime: '11:30',
        endTime: '12:30',
        subjectId: '3',
        subjectName: 'Chemistry',
        teacherName: 'Dr. Williams',
        room: 'Lab 1',
        color: '#F59E0B'
      },
      {
        id: 't4',
        day: 'Tuesday',
        startTime: '09:00',
        endTime: '10:00',
        subjectId: '4',
        subjectName: 'Biology',
        teacherName: 'Mrs. Davis',
        room: 'Room 103',
        color: '#8B5CF6'
      },
      {
        id: 't5',
        day: 'Tuesday',
        startTime: '10:15',
        endTime: '11:15',
        subjectId: '5',
        subjectName: 'English',
        teacherName: 'Mr. Brown',
        room: 'Room 104',
        color: '#EF4444'
      },
      {
        id: 't6',
        day: 'Tuesday',
        startTime: '11:30',
        endTime: '12:30',
        subjectId: '1',
        subjectName: 'Mathematics',
        teacherName: 'Dr. Smith',
        room: 'Room 101',
        color: '#04ADEE'
      },
      {
        id: 't7',
        day: 'Wednesday',
        startTime: '09:00',
        endTime: '10:00',
        subjectId: '2',
        subjectName: 'Physics',
        teacherName: 'Prof. Johnson',
        room: 'Lab 2',
        color: '#10B981'
      },
      {
        id: 't8',
        day: 'Wednesday',
        startTime: '10:15',
        endTime: '11:15',
        subjectId: '3',
        subjectName: 'Chemistry',
        teacherName: 'Dr. Williams',
        room: 'Room 102',
        color: '#F59E0B'
      },
      {
        id: 't9',
        day: 'Thursday',
        startTime: '09:00',
        endTime: '10:00',
        subjectId: '1',
        subjectName: 'Mathematics',
        teacherName: 'Dr. Smith',
        room: 'Room 101',
        color: '#04ADEE'
      },
      {
        id: 't10',
        day: 'Thursday',
        startTime: '10:15',
        endTime: '11:15',
        subjectId: '4',
        subjectName: 'Biology',
        teacherName: 'Mrs. Davis',
        room: 'Lab 3',
        color: '#8B5CF6'
      },
      {
        id: 't11',
        day: 'Friday',
        startTime: '09:00',
        endTime: '10:00',
        subjectId: '5',
        subjectName: 'English',
        teacherName: 'Mr. Brown',
        room: 'Room 104',
        color: '#EF4444'
      },
      {
        id: 't12',
        day: 'Friday',
        startTime: '10:15',
        endTime: '11:15',
        subjectId: '2',
        subjectName: 'Physics',
        teacherName: 'Prof. Johnson',
        room: 'Room 102',
        color: '#10B981'
      }
    ];
  }
};
