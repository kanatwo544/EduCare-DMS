export interface DriveFile {
  id: string;
  name: string;
  type: 'file' | 'folder';
  mimeType?: string;
  size?: number;
  uploadedBy: string;
  uploadedAt: string;
  parentId?: string;
  url?: string;
  shared?: boolean;
}

export interface UploadFileRequest {
  file: File;
  parentId?: string;
  subjectId?: string;
}

export interface UploadFileResponse {
  success: boolean;
  fileId: string;
  url: string;
  message: string;
}

export interface ShareResourceRequest {
  fileId: string;
  subjectId: string;
  title: string;
  description?: string;
}

export interface ShareResourceResponse {
  success: boolean;
  resourceId: string;
  message: string;
}

export interface Resource {
  id: string;
  title: string;
  description?: string;
  fileType: string;
  fileSize: number;
  url: string;
  subjectId: string;
  subjectName: string;
  sharedBy: string;
  sharedAt: string;
  downloads: number;
}

export const driveAPI = {
  async getDriveFiles(parentId?: string): Promise<DriveFile[]> {
    await new Promise(resolve => setTimeout(resolve, 500));

    if (!parentId) {
      return [
        {
          id: 'f1',
          name: 'Mathematics',
          type: 'folder',
          uploadedBy: 'Dr. Smith',
          uploadedAt: '2024-01-15T10:00:00'
        },
        {
          id: 'f2',
          name: 'Physics',
          type: 'folder',
          uploadedBy: 'Prof. Johnson',
          uploadedAt: '2024-01-16T10:00:00'
        },
        {
          id: 'f3',
          name: 'Syllabus_2024.pdf',
          type: 'file',
          mimeType: 'application/pdf',
          size: 2048576,
          uploadedBy: 'Dr. Smith',
          uploadedAt: '2024-02-01T10:00:00',
          url: '#'
        },
        {
          id: 'f4',
          name: 'Lecture_Notes.pdf',
          type: 'file',
          mimeType: 'application/pdf',
          size: 1024000,
          uploadedBy: 'Dr. Smith',
          uploadedAt: '2024-02-10T10:00:00',
          url: '#'
        }
      ];
    } else {
      return [
        {
          id: 'f5',
          name: 'Chapter1_Algebra.pdf',
          type: 'file',
          mimeType: 'application/pdf',
          size: 512000,
          uploadedBy: 'Dr. Smith',
          uploadedAt: '2024-01-20T10:00:00',
          parentId,
          url: '#'
        },
        {
          id: 'f6',
          name: 'Practice_Problems.pdf',
          type: 'file',
          mimeType: 'application/pdf',
          size: 768000,
          uploadedBy: 'Dr. Smith',
          uploadedAt: '2024-01-25T10:00:00',
          parentId,
          url: '#'
        }
      ];
    }
  },

  async uploadFile(data: UploadFileRequest): Promise<UploadFileResponse> {
    await new Promise(resolve => setTimeout(resolve, 1500));

    return {
      success: true,
      fileId: 'file-' + Date.now(),
      url: '#',
      message: 'File uploaded successfully'
    };
  },

  async shareResource(data: ShareResourceRequest): Promise<ShareResourceResponse> {
    await new Promise(resolve => setTimeout(resolve, 500));

    return {
      success: true,
      resourceId: 'resource-' + Date.now(),
      message: 'Resource shared successfully'
    };
  },

  async getSharedResources(subjectId?: string): Promise<Resource[]> {
    await new Promise(resolve => setTimeout(resolve, 500));

    const allResources = [
      {
        id: 'r1',
        title: 'Algebra Chapter Notes',
        description: 'Comprehensive notes on algebra fundamentals',
        fileType: 'pdf',
        fileSize: 2048576,
        url: '#',
        subjectId: '1',
        subjectName: 'Mathematics',
        sharedBy: 'Dr. Smith',
        sharedAt: '2024-01-15T10:00:00',
        downloads: 45
      },
      {
        id: 'r2',
        title: 'Calculus Video Tutorial',
        description: 'Video explanation of calculus concepts',
        fileType: 'video',
        fileSize: 52428800,
        url: '#',
        subjectId: '1',
        subjectName: 'Mathematics',
        sharedBy: 'Dr. Smith',
        sharedAt: '2024-02-01T10:00:00',
        downloads: 38
      },
      {
        id: 'r3',
        title: 'Physics Lab Manual',
        description: 'Complete lab manual for physics experiments',
        fileType: 'pdf',
        fileSize: 5242880,
        url: '#',
        subjectId: '2',
        subjectName: 'Physics',
        sharedBy: 'Prof. Johnson',
        sharedAt: '2024-01-20T10:00:00',
        downloads: 52
      },
      {
        id: 'r4',
        title: 'Chemistry Reference Book',
        description: 'Additional reading material for chemistry',
        fileType: 'pdf',
        fileSize: 10485760,
        url: '#',
        subjectId: '3',
        subjectName: 'Chemistry',
        sharedBy: 'Dr. Williams',
        sharedAt: '2024-01-25T10:00:00',
        downloads: 41
      }
    ];

    if (subjectId) {
      return allResources.filter(r => r.subjectId === subjectId);
    }

    return allResources;
  }
};
