export interface DashboardDataRequest {
  role: 'student' | 'teacher' | 'admin';
  userId: string;
}

export interface StudentDashboardData {
  overallAverage: number;
  syllabusProgress: number;
  attendancePercentage: number;
  subjectAverages: Array<{
    subject: string;
    average: number;
    color: string;
  }>;
  recentAnnouncements: Array<{
    id: string;
    title: string;
    content: string;
    date: string;
    author: string;
  }>;
  upcomingEvents: Array<{
    id: string;
    title: string;
    date: string;
    type: 'quiz' | 'assignment' | 'event';
  }>;
  recentAssessments: Array<{
    id: string;
    subject: string;
    title: string;
    score: number;
    maxScore: number;
    date: string;
  }>;
}

export interface TeacherDashboardData {
  overallAverage: number;
  classAverages: Array<{
    className: string;
    average: number;
    color: string;
  }>;
  syllabusProgress: Array<{
    subject: string;
    progress: number;
  }>;
  recentFeedback: Array<{
    id: string;
    studentName: string;
    rating: number;
    comment: string;
    date: string;
  }>;
  attendanceAlerts: Array<{
    id: string;
    studentName: string;
    attendancePercentage: number;
    className: string;
  }>;
}

export interface AdminDashboardData {
  performanceSummary: {
    averagePerformance: number;
    totalStudents: number;
    totalTeachers: number;
    totalClasses: number;
  };
  attendanceTrends: Array<{
    date: string;
    percentage: number;
  }>;
  userStats: {
    activeStudents: number;
    activeTeachers: number;
    newEnrollments: number;
  };
}

export const dashboardAPI = {
  async getDashboardData(request: DashboardDataRequest): Promise<StudentDashboardData | TeacherDashboardData | AdminDashboardData> {
    await new Promise(resolve => setTimeout(resolve, 800));

    if (request.role === 'student') {
      return {
        overallAverage: 85.5,
        syllabusProgress: 68,
        attendancePercentage: 92,
        subjectAverages: [
          { subject: 'Mathematics', average: 88, color: '#04ADEE' },
          { subject: 'Physics', average: 82, color: '#10B981' },
          { subject: 'Chemistry', average: 90, color: '#F59E0B' },
          { subject: 'Biology', average: 85, color: '#8B5CF6' },
          { subject: 'English', average: 80, color: '#EF4444' }
        ],
        recentAnnouncements: [
          {
            id: '1',
            title: 'Mid-term Exam Schedule',
            content: 'Mid-term exams will be conducted from March 15-20',
            date: '2024-03-01',
            author: 'Admin'
          },
          {
            id: '2',
            title: 'Science Fair',
            content: 'Annual science fair on March 25th',
            date: '2024-03-02',
            author: 'Mr. Smith'
          }
        ],
        upcomingEvents: [
          { id: '1', title: 'Mathematics Quiz', date: '2024-03-15', type: 'quiz' },
          { id: '2', title: 'Physics Assignment', date: '2024-03-18', type: 'assignment' },
          { id: '3', title: 'Parent-Teacher Meeting', date: '2024-03-22', type: 'event' }
        ],
        recentAssessments: [
          { id: '1', subject: 'Mathematics', title: 'Algebra Test', score: 88, maxScore: 100, date: '2024-02-28' },
          { id: '2', subject: 'Physics', title: 'Motion Quiz', score: 18, maxScore: 20, date: '2024-02-26' },
          { id: '3', subject: 'Chemistry', title: 'Periodic Table', score: 45, maxScore: 50, date: '2024-02-25' }
        ]
      } as StudentDashboardData;
    } else if (request.role === 'teacher') {
      return {
        overallAverage: 78.5,
        classAverages: [
          { className: 'Class 10A', average: 82, color: '#04ADEE' },
          { className: 'Class 10B', average: 76, color: '#10B981' },
          { className: 'Class 9A', average: 80, color: '#F59E0B' },
          { className: 'Class 9B', average: 75, color: '#8B5CF6' }
        ],
        syllabusProgress: [
          { subject: 'Mathematics', progress: 75 },
          { subject: 'Physics', progress: 68 },
          { subject: 'Chemistry', progress: 82 }
        ],
        recentFeedback: [
          {
            id: '1',
            studentName: 'Alice Johnson',
            rating: 5,
            comment: 'Great teaching style!',
            date: '2024-03-01'
          },
          {
            id: '2',
            studentName: 'Bob Smith',
            rating: 4,
            comment: 'Very helpful and clear',
            date: '2024-02-28'
          }
        ],
        attendanceAlerts: [
          { id: '1', studentName: 'Charlie Brown', attendancePercentage: 65, className: 'Class 10A' },
          { id: '2', studentName: 'Diana Prince', attendancePercentage: 70, className: 'Class 10B' }
        ]
      } as TeacherDashboardData;
    } else {
      return {
        performanceSummary: {
          averagePerformance: 80.5,
          totalStudents: 450,
          totalTeachers: 32,
          totalClasses: 24
        },
        attendanceTrends: [
          { date: '2024-02-01', percentage: 88 },
          { date: '2024-02-08', percentage: 90 },
          { date: '2024-02-15', percentage: 87 },
          { date: '2024-02-22', percentage: 92 },
          { date: '2024-03-01', percentage: 89 }
        ],
        userStats: {
          activeStudents: 445,
          activeTeachers: 32,
          newEnrollments: 12
        }
      } as AdminDashboardData;
    }
  }
};
