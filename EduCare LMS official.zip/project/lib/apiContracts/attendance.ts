export interface AttendanceRecord {
  id: string;
  studentId: string;
  studentName: string;
  date: string;
  status: 'present' | 'absent' | 'late';
  subjectId?: string;
  classId?: string;
}

export interface AttendanceSummary {
  totalClasses: number;
  attendedClasses: number;
  percentage: number;
  subjectWise: Array<{
    subjectId: string;
    subjectName: string;
    total: number;
    attended: number;
    percentage: number;
  }>;
  trend: Array<{
    month: string;
    percentage: number;
  }>;
}

export interface MarkAttendanceRequest {
  classId: string;
  subjectId: string;
  date: string;
  records: Array<{
    studentId: string;
    status: 'present' | 'absent' | 'late';
  }>;
}

export interface MarkAttendanceResponse {
  success: boolean;
  message: string;
  recordsUpdated: number;
}

export const attendanceAPI = {
  async getAttendance(userId: string, role: 'student' | 'teacher'): Promise<AttendanceSummary> {
    await new Promise(resolve => setTimeout(resolve, 500));

    if (role === 'student') {
      return {
        totalClasses: 180,
        attendedClasses: 165,
        percentage: 91.67,
        subjectWise: [
          { subjectId: '1', subjectName: 'Mathematics', total: 40, attended: 38, percentage: 95 },
          { subjectId: '2', subjectName: 'Physics', total: 35, attended: 32, percentage: 91.43 },
          { subjectId: '3', subjectName: 'Chemistry', total: 38, attended: 36, percentage: 94.74 },
          { subjectId: '4', subjectName: 'Biology', total: 36, attended: 35, percentage: 97.22 },
          { subjectId: '5', subjectName: 'English', total: 31, attended: 24, percentage: 77.42 }
        ],
        trend: [
          { month: 'Sep', percentage: 88 },
          { month: 'Oct', percentage: 92 },
          { month: 'Nov', percentage: 90 },
          { month: 'Dec', percentage: 94 },
          { month: 'Jan', percentage: 91 },
          { month: 'Feb', percentage: 93 }
        ]
      };
    } else {
      return {
        totalClasses: 120,
        attendedClasses: 108,
        percentage: 90,
        subjectWise: [
          { subjectId: '1', subjectName: 'Class 10A', total: 40, attended: 36, percentage: 90 },
          { subjectId: '2', subjectName: 'Class 10B', total: 40, attended: 38, percentage: 95 },
          { subjectId: '3', subjectName: 'Class 9A', total: 40, attended: 34, percentage: 85 }
        ],
        trend: [
          { month: 'Sep', percentage: 87 },
          { month: 'Oct', percentage: 89 },
          { month: 'Nov', percentage: 92 },
          { month: 'Dec', percentage: 90 },
          { month: 'Jan', percentage: 88 },
          { month: 'Feb', percentage: 91 }
        ]
      };
    }
  },

  async markAttendance(data: MarkAttendanceRequest): Promise<MarkAttendanceResponse> {
    await new Promise(resolve => setTimeout(resolve, 800));

    return {
      success: true,
      message: 'Attendance marked successfully',
      recordsUpdated: data.records.length
    };
  },

  async getAttendanceRecords(classId: string, date: string): Promise<AttendanceRecord[]> {
    await new Promise(resolve => setTimeout(resolve, 500));

    return [
      { id: '1', studentId: 's1', studentName: 'Alice Johnson', date, status: 'present', classId },
      { id: '2', studentId: 's2', studentName: 'Bob Smith', date, status: 'present', classId },
      { id: '3', studentId: 's3', studentName: 'Charlie Brown', date, status: 'absent', classId },
      { id: '4', studentId: 's4', studentName: 'Diana Prince', date, status: 'late', classId },
      { id: '5', studentId: 's5', studentName: 'Eve Wilson', date, status: 'present', classId }
    ];
  }
};
