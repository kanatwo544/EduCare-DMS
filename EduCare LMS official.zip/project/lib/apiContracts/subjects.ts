export interface Subject {
  id: string;
  name: string;
  teacher: string;
  color: string;
  average?: number;
  progress?: number;
  totalClasses?: number;
  attendedClasses?: number;
}

export interface SubjectDetail extends Subject {
  description: string;
  syllabus: Array<{
    id: string;
    topic: string;
    completed: boolean;
    date?: string;
  }>;
  assessments: Array<{
    id: string;
    title: string;
    type: 'quiz' | 'assignment' | 'exam';
    score?: number;
    maxScore: number;
    date: string;
    status: 'upcoming' | 'completed' | 'graded';
  }>;
  resources: Array<{
    id: string;
    title: string;
    type: 'pdf' | 'video' | 'link';
    url: string;
    uploadedBy: string;
    date: string;
  }>;
}

export const subjectsAPI = {
  async getSubjects(userId: string, role: 'student' | 'teacher'): Promise<Subject[]> {
    await new Promise(resolve => setTimeout(resolve, 500));

    if (role === 'student') {
      return [
        { id: '1', name: 'Mathematics', teacher: 'Dr. Smith', color: '#04ADEE', average: 88, progress: 75, totalClasses: 40, attendedClasses: 38 },
        { id: '2', name: 'Physics', teacher: 'Prof. Johnson', color: '#10B981', average: 82, progress: 68, totalClasses: 35, attendedClasses: 32 },
        { id: '3', name: 'Chemistry', teacher: 'Dr. Williams', color: '#F59E0B', average: 90, progress: 82, totalClasses: 38, attendedClasses: 36 },
        { id: '4', name: 'Biology', teacher: 'Mrs. Davis', color: '#8B5CF6', average: 85, progress: 70, totalClasses: 36, attendedClasses: 35 },
        { id: '5', name: 'English', teacher: 'Mr. Brown', color: '#EF4444', average: 80, progress: 65, totalClasses: 32, attendedClasses: 30 }
      ];
    } else {
      return [
        { id: '1', name: 'Mathematics', teacher: 'You', color: '#04ADEE', average: 78, totalClasses: 120 },
        { id: '2', name: 'Physics', teacher: 'You', color: '#10B981', average: 75, totalClasses: 100 },
        { id: '3', name: 'Chemistry', teacher: 'You', color: '#F59E0B', average: 82, totalClasses: 110 }
      ];
    }
  },

  async getSubjectDetail(subjectId: string): Promise<SubjectDetail> {
    await new Promise(resolve => setTimeout(resolve, 500));

    return {
      id: subjectId,
      name: 'Mathematics',
      teacher: 'Dr. Smith',
      color: '#04ADEE',
      average: 88,
      progress: 75,
      totalClasses: 40,
      attendedClasses: 38,
      description: 'Advanced mathematics covering algebra, calculus, and geometry',
      syllabus: [
        { id: '1', topic: 'Algebra Fundamentals', completed: true, date: '2024-01-15' },
        { id: '2', topic: 'Linear Equations', completed: true, date: '2024-01-22' },
        { id: '3', topic: 'Quadratic Equations', completed: true, date: '2024-02-05' },
        { id: '4', topic: 'Calculus Introduction', completed: false },
        { id: '5', topic: 'Derivatives', completed: false },
        { id: '6', topic: 'Integrals', completed: false }
      ],
      assessments: [
        { id: '1', title: 'Algebra Test', type: 'exam', score: 88, maxScore: 100, date: '2024-02-28', status: 'graded' },
        { id: '2', title: 'Linear Equations Quiz', type: 'quiz', score: 18, maxScore: 20, date: '2024-02-15', status: 'graded' },
        { id: '3', title: 'Calculus Assignment', type: 'assignment', maxScore: 50, date: '2024-03-20', status: 'upcoming' }
      ],
      resources: [
        { id: '1', title: 'Algebra Chapter Notes', type: 'pdf', url: '#', uploadedBy: 'Dr. Smith', date: '2024-01-10' },
        { id: '2', title: 'Calculus Video Tutorial', type: 'video', url: '#', uploadedBy: 'Dr. Smith', date: '2024-02-20' },
        { id: '3', title: 'Practice Problems', type: 'pdf', url: '#', uploadedBy: 'Dr. Smith', date: '2024-02-25' }
      ]
    };
  }
};
