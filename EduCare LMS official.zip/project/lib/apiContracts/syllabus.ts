export interface SyllabusTopic {
  id: string;
  topic: string;
  completed: boolean;
  date?: string;
  description?: string;
}

export interface Syllabus {
  id: string;
  subjectId: string;
  subjectName: string;
  topics: SyllabusTopic[];
  overallProgress: number;
}

export interface UpdateSyllabusRequest {
  subjectId: string;
  topicId: string;
  completed: boolean;
}

export interface UpdateSyllabusResponse {
  success: boolean;
  progress: number;
  message: string;
}

export interface AddTopicRequest {
  subjectId: string;
  topic: string;
  description?: string;
}

export interface AddTopicResponse {
  success: boolean;
  topicId: string;
  message: string;
}

export const syllabusAPI = {
  async getSyllabus(subjectId: string): Promise<Syllabus> {
    await new Promise(resolve => setTimeout(resolve, 500));

    const topics = [
      { id: 't1', topic: 'Algebra Fundamentals', completed: true, date: '2024-01-15', description: 'Basic algebraic operations and expressions' },
      { id: 't2', topic: 'Linear Equations', completed: true, date: '2024-01-22', description: 'Solving linear equations in one and two variables' },
      { id: 't3', topic: 'Quadratic Equations', completed: true, date: '2024-02-05', description: 'Solving quadratic equations and applications' },
      { id: 't4', topic: 'Polynomials', completed: true, date: '2024-02-12', description: 'Operations on polynomials' },
      { id: 't5', topic: 'Calculus Introduction', completed: false, description: 'Limits and continuity' },
      { id: 't6', topic: 'Derivatives', completed: false, description: 'Rules of differentiation' },
      { id: 't7', topic: 'Integrals', completed: false, description: 'Integration techniques' },
      { id: 't8', topic: 'Trigonometry', completed: false, description: 'Trigonometric functions and identities' }
    ];

    const completedCount = topics.filter(t => t.completed).length;
    const progress = Math.round((completedCount / topics.length) * 100);

    return {
      id: 'syl-1',
      subjectId,
      subjectName: 'Mathematics',
      topics,
      overallProgress: progress
    };
  },

  async updateSyllabus(data: UpdateSyllabusRequest): Promise<UpdateSyllabusResponse> {
    await new Promise(resolve => setTimeout(resolve, 500));

    return {
      success: true,
      progress: 62,
      message: 'Syllabus updated successfully'
    };
  },

  async addTopic(data: AddTopicRequest): Promise<AddTopicResponse> {
    await new Promise(resolve => setTimeout(resolve, 500));

    return {
      success: true,
      topicId: 't-' + Date.now(),
      message: 'Topic added successfully'
    };
  }
};
