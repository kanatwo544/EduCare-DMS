'use client';

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import {
  STUDENTS as INITIAL_STUDENTS,
  TEACHERS as INITIAL_TEACHERS,
  ADMIN as INITIAL_ADMIN,
  SUBJECTS as INITIAL_SUBJECTS,
  ANNOUNCEMENTS as INITIAL_ANNOUNCEMENTS,
  CALENDAR_EVENTS as INITIAL_CALENDAR_EVENTS,
  CLASSES as INITIAL_CLASSES,
  MARKS as INITIAL_MARKS,
  ATTENDANCE as INITIAL_ATTENDANCE,
  SYLLABUS as INITIAL_SYLLABUS,
  FEEDBACKS as INITIAL_FEEDBACKS,
  RESOURCES as INITIAL_RESOURCES,
  CHAT_MESSAGES as INITIAL_CHAT_MESSAGES,
  Student,
  Teacher,
  Subject,
  Announcement,
  CalendarEvent,
  Class,
  Mark,
  AttendanceRecord,
  SyllabusTopic,
  Feedback,
  ChatMessage,
  Resource
} from '../demoData';

interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  timestamp: Date;
  read: boolean;
  userId: string;
  link?: string;
}

interface TimetableEntry {
  id: string;
  day: string;
  time: string;
  subject: string;
  class: string;
  room: string;
  teacherId: string;
}

interface AppDataContextType {
  students: Student[];
  teachers: Teacher[];
  admin: typeof INITIAL_ADMIN;
  subjects: Subject[];
  classes: Class[];
  announcements: Announcement[];
  calendarEvents: CalendarEvent[];
  marks: Mark[];
  attendance: AttendanceRecord[];
  syllabus: SyllabusTopic[];
  syllabusTopics: SyllabusTopic[];
  feedbacks: Feedback[];
  chatMessages: ChatMessage[];
  resources: Resource[];
  notifications: Notification[];
  timetable: TimetableEntry[];

  addStudent: (student: Omit<Student, 'id'>) => void;
  addTeacher: (teacher: Omit<Teacher, 'id'>) => void;
  addClass: (classData: Omit<Class, 'id'>) => void;
  addSubject: (subject: Omit<Subject, 'id'>) => void;
  addAnnouncement: (announcement: Omit<Announcement, 'id'>) => void;
  sendMessage: (message: Omit<ChatMessage, 'id' | 'timestamp' | 'read'>) => void;
  uploadMarks: (mark: Omit<Mark, 'id'>) => void;
  markAttendance: (record: Omit<AttendanceRecord, 'id'>) => void;
  updateAttendance: (studentId: string, isPresent: boolean) => void;
  addCalendarEvent: (event: Omit<CalendarEvent, 'id'>) => void;
  updateCalendarEvent: (eventId: string, updates: Partial<CalendarEvent>) => void;
  proposeEvent: (event: { title: string; description?: string; date: string; proposedBy: string }) => void;
  submitFeedback: (feedback: Omit<Feedback, 'id' | 'submittedDate'>) => void;
  uploadResource: (resource: Omit<Resource, 'id' | 'uploadedDate'>) => void;
  updateProfile: (userId: string, updates: Partial<Student | Teacher>) => void;
  updateSyllabusProgress: (topicId: string, completed: boolean) => void;
  addSyllabusTopic: (topic: { subjectId: string; topic: string; subtopics: string[] }) => void;
  markTopicTaught: (topicId: string, subtopicIndex: number) => void;
  markNotificationRead: (notificationId: string) => void;
  clearAllNotifications: (userId: string) => void;

  getStudentById: (id: string) => Student | undefined;
  getTeacherById: (id: string) => Teacher | undefined;
  getStudentMarks: (studentId: string, subjectId?: string) => Mark[];
  getStudentAttendance: (studentId: string, subjectId?: string) => AttendanceRecord[];
  getSubjectSyllabus: (subjectId: string) => SyllabusTopic[];
  getStudentFeedbacks: (studentId: string) => Feedback[];
  getUnreadNotifications: (userId: string) => Notification[];
  calculateStudentAverage: (studentId: string, subjectId?: string) => number;
  calculateAttendancePercentage: (studentId: string, subjectId?: string) => number;
  calculateSyllabusProgress: (subjectId: string) => number;
}

const AppDataContext = createContext<AppDataContextType | undefined>(undefined);

export const useAppData = () => {
  const context = useContext(AppDataContext);
  if (!context) {
    throw new Error('useAppData must be used within AppDataProvider');
  }
  return context;
};

interface AppDataProviderProps {
  children: ReactNode;
}

export const AppDataProvider: React.FC<AppDataProviderProps> = ({ children }) => {
  const [students, setStudents] = useState<Student[]>(INITIAL_STUDENTS);
  const [teachers, setTeachers] = useState<Teacher[]>(INITIAL_TEACHERS);
  const [admin] = useState(INITIAL_ADMIN);
  const [subjects, setSubjects] = useState<Subject[]>(INITIAL_SUBJECTS);
  const [classes, setClasses] = useState<Class[]>(INITIAL_CLASSES);
  const [announcements, setAnnouncements] = useState<Announcement[]>(INITIAL_ANNOUNCEMENTS);
  const [calendarEvents, setCalendarEvents] = useState<CalendarEvent[]>(INITIAL_CALENDAR_EVENTS);
  const [marks, setMarks] = useState<Mark[]>(INITIAL_MARKS);
  const [attendance, setAttendance] = useState<AttendanceRecord[]>(INITIAL_ATTENDANCE);
  const [syllabus, setSyllabus] = useState<SyllabusTopic[]>(INITIAL_SYLLABUS);
  const [feedbacks, setFeedbacks] = useState<Feedback[]>(INITIAL_FEEDBACKS);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(INITIAL_CHAT_MESSAGES);
  const [resources, setResources] = useState<Resource[]>(INITIAL_RESOURCES);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [timetable, setTimetable] = useState<TimetableEntry[]>([
    { id: 't1', day: 'Monday', time: '09:00', subject: 'Mathematics', class: 'Class 10A', room: 'Room 101', teacherId: 't1' },
    { id: 't2', day: 'Monday', time: '10:00', subject: 'Physics', class: 'Class 10B', room: 'Room 102', teacherId: 't1' },
    { id: 't3', day: 'Tuesday', time: '09:00', subject: 'Mathematics', class: 'Class 10C', room: 'Room 101', teacherId: 't1' },
    { id: 't4', day: 'Wednesday', time: '11:00', subject: 'Physics', class: 'Class 10A', room: 'Room 102', teacherId: 't1' },
    { id: 't5', day: 'Thursday', time: '09:00', subject: 'Mathematics', class: 'Class 10A', room: 'Room 101', teacherId: 't1' },
    { id: 't6', day: 'Friday', time: '10:00', subject: 'Physics', class: 'Class 10B', room: 'Room 102', teacherId: 't1' }
  ]);

  const createNotification = (
    userId: string,
    title: string,
    message: string,
    type: 'info' | 'success' | 'warning' | 'error' = 'info',
    link?: string
  ) => {
    const notification: Notification = {
      id: `notif-${Date.now()}-${Math.random()}`,
      title,
      message,
      type,
      link,
      timestamp: new Date(),
      read: false,
      userId
    };
    setNotifications(prev => [notification, ...prev]);
  };

  const addAnnouncement = (announcement: Omit<Announcement, 'id'>) => {
    const newAnnouncement: Announcement = {
      ...announcement,
      id: `ann-${Date.now()}`
    };
    setAnnouncements(prev => [newAnnouncement, ...prev]);

    const affectedUsers = announcement.targetAudience === 'all'
      ? [...students.map(s => s.id), ...teachers.map(t => t.id)]
      : announcement.targetAudience === 'students'
      ? students.map(s => s.id)
      : teachers.map(t => t.id);

    affectedUsers.forEach(userId => {
      const userRole = students.find(s => s.id === userId) ? 'student' : teachers.find(t => t.id === userId) ? 'teacher' : 'admin';
      createNotification(userId, 'New Announcement', announcement.title, 'info', `/${userRole}/announcements`);
    });
  };

  const sendMessage = (message: Omit<ChatMessage, 'id' | 'timestamp' | 'read'>) => {
    const newMessage: ChatMessage = {
      ...message,
      id: `msg-${Date.now()}`,
      timestamp: new Date().toISOString(),
      read: false
    };
    setChatMessages(prev => [...prev, newMessage]);

    const receiverRole = students.find(s => s.id === message.receiverId) ? 'student' : teachers.find(t => t.id === message.receiverId) ? 'teacher' : 'admin';
    createNotification(
      message.receiverId,
      'New Message',
      `${message.senderName}: ${message.content.substring(0, 50)}...`,
      'info',
      `/${receiverRole}/chat`
    );
  };

  const addStudent = (student: Omit<Student, 'id'>) => {
    const newStudent: Student = {
      ...student,
      id: `student-${Date.now()}`
    };
    setStudents(prev => [...prev, newStudent]);
  };

  const addTeacher = (teacher: Omit<Teacher, 'id'>) => {
    const newTeacher: Teacher = {
      ...teacher,
      id: `teacher-${Date.now()}`
    };
    setTeachers(prev => [...prev, newTeacher]);
  };

  const addClass = (classData: Omit<Class, 'id'>) => {
    const newClass: Class = {
      ...classData,
      id: `class-${Date.now()}`
    };
    setClasses(prev => [...prev, newClass]);
  };

  const addSubject = (subject: Omit<Subject, 'id'>) => {
    const newSubject: Subject = {
      ...subject,
      id: `subject-${Date.now()}`
    };
    setSubjects(prev => [...prev, newSubject]);
  };

  const uploadMarks = (mark: Omit<Mark, 'id'>) => {
    const newMark: Mark = {
      ...mark,
      id: `mark-${Date.now()}`
    };
    setMarks(prev => [...prev, newMark]);

    createNotification(
      mark.studentId,
      'New Grade Posted',
      `Your grade for ${mark.assessmentName} has been posted.`,
      'success',
      '/student/assessments'
    );

    recalculateStudentMetrics(mark.studentId);
  };

  const markAttendance = (record: Omit<AttendanceRecord, 'id'>) => {
    const newRecord: AttendanceRecord = {
      ...record,
      id: `att-${Date.now()}`
    };
    setAttendance(prev => [...prev, newRecord]);

    if (record.status === 'absent') {
      const subject = subjects.find(s => s.id === record.subjectId);
      createNotification(
        record.studentId,
        'Attendance Alert',
        `You were marked absent for ${subject?.name} on ${new Date(record.date).toLocaleDateString()}.`,
        'warning',
        '/student/attendance'
      );
    }

    recalculateStudentMetrics(record.studentId);
  };

  const addCalendarEvent = (event: Omit<CalendarEvent, 'id'>) => {
    const newEvent: CalendarEvent = {
      ...event,
      id: `event-${Date.now()}`
    };
    setCalendarEvents(prev => [...prev, newEvent]);

    const affectedUsers = [...students.map(s => s.id), ...teachers.map(t => t.id)];
    affectedUsers.forEach(userId => {
      const userRole = students.find(s => s.id === userId) ? 'student' : teachers.find(t => t.id === userId) ? 'teacher' : 'admin';
      createNotification(userId, 'New Event', event.title, 'info', `/${userRole}/calendar`);
    });
  };

  const updateCalendarEvent = (eventId: string, updates: Partial<CalendarEvent>) => {
    setCalendarEvents(prev => prev.map(event =>
      event.id === eventId ? { ...event, ...updates } : event
    ));
  };

  const submitFeedback = (feedback: Omit<Feedback, 'id' | 'submittedDate'>) => {
    const newFeedback: Feedback = {
      ...feedback,
      id: `feedback-${Date.now()}`,
      submittedDate: new Date().toISOString()
    };
    setFeedbacks(prev => [...prev, newFeedback]);

    const teacher = teachers.find(t => t.id === feedback.teacherId);
    if (teacher) {
      const subject = subjects.find(s => s.id === feedback.subjectId);
      createNotification(
        teacher.id,
        'New Feedback',
        `New feedback received for ${subject?.name}`,
        'info',
        '/teacher/feedback-view'
      );
    }
  };

  const uploadResource = (resource: Omit<Resource, 'id' | 'uploadedDate'>) => {
    const newResource: Resource = {
      ...resource,
      id: `resource-${Date.now()}`,
      uploadedDate: new Date().toISOString()
    };
    setResources(prev => [...prev, newResource]);

    const affectedStudents = students.filter(s => s.subjects.includes(resource.subjectId));
    affectedStudents.forEach(student => {
      createNotification(
        student.id,
        'New Resource Available',
        `${resource.title} has been uploaded`,
        'info',
        '/student/resources'
      );
    });
  };

  const updateProfile = (userId: string, updates: Partial<Student | Teacher>) => {
    setStudents(prev =>
      prev.map(student =>
        student.id === userId ? { ...student, ...updates } : student
      )
    );

    setTeachers(prev =>
      prev.map(teacher =>
        teacher.id === userId ? { ...teacher, ...updates } : teacher
      )
    );

    createNotification(userId, 'Profile Updated', 'Your profile has been updated successfully.', 'success');
  };

  const updateSyllabusProgress = (topicId: string, completed: boolean) => {
    setSyllabus(prev =>
      prev.map(topic =>
        topic.id === topicId
          ? { ...topic, completed, completedDate: completed ? new Date().toISOString() : undefined }
          : topic
      )
    );
  };

  const markNotificationRead = (notificationId: string) => {
    setNotifications(prev =>
      prev.map(notif =>
        notif.id === notificationId ? { ...notif, read: true } : notif
      )
    );
  };

  const clearAllNotifications = (userId: string) => {
    setNotifications(prev =>
      prev.map(notif =>
        notif.userId === userId ? { ...notif, read: true } : notif
      )
    );
  };

  const recalculateStudentMetrics = (studentId: string) => {
    const studentMarks = marks.filter(m => m.studentId === studentId && m.status === 'graded');
    const studentAttendance = attendance.filter(a => a.studentId === studentId);

    if (studentMarks.length > 0 || studentAttendance.length > 0) {
      let average = 0;
      if (studentMarks.length > 0) {
        average = studentMarks.reduce((sum, m) => sum + (m.score / m.maxScore) * 100, 0) / studentMarks.length;
      }

      const presentCount = studentAttendance.filter(a => a.status === 'present' || a.status === 'late').length;
      const attendancePercentage = studentAttendance.length > 0
        ? (presentCount / studentAttendance.length) * 100
        : 0;

      setStudents(prev =>
        prev.map(student =>
          student.id === studentId
            ? {
                ...student,
                overallAverage: Math.round(average * 10) / 10,
                attendance: Math.round(attendancePercentage * 10) / 10
              }
            : student
        )
      );
    }
  };

  const getStudentById = (id: string): Student | undefined => {
    return students.find(s => s.id === id);
  };

  const getTeacherById = (id: string): Teacher | undefined => {
    return teachers.find(t => t.id === id);
  };

  const getStudentMarks = (studentId: string, subjectId?: string): Mark[] => {
    return marks.filter(
      m => m.studentId === studentId && (!subjectId || m.subjectId === subjectId)
    );
  };

  const getStudentAttendance = (studentId: string, subjectId?: string): AttendanceRecord[] => {
    return attendance.filter(
      a => a.studentId === studentId && (!subjectId || a.subjectId === subjectId)
    );
  };

  const getSubjectSyllabus = (subjectId: string): SyllabusTopic[] => {
    return syllabus.filter(s => s.subjectId === subjectId).sort((a, b) => a.order - b.order);
  };

  const getStudentFeedbacks = (studentId: string): Feedback[] => {
    return feedbacks.filter(f => f.studentId === studentId);
  };

  const getUnreadNotifications = (userId: string): Notification[] => {
    return notifications.filter(n => n.userId === userId && !n.read);
  };

  const calculateStudentAverage = (studentId: string, subjectId?: string): number => {
    const studentMarks = getStudentMarks(studentId, subjectId).filter(m => m.status === 'graded');
    if (studentMarks.length === 0) return 0;

    const average = studentMarks.reduce((sum, m) => sum + (m.score / m.maxScore) * 100, 0) / studentMarks.length;
    return Math.round(average * 10) / 10;
  };

  const calculateAttendancePercentage = (studentId: string, subjectId?: string): number => {
    const records = getStudentAttendance(studentId, subjectId);
    if (records.length === 0) return 0;

    const presentCount = records.filter(r => r.status === 'present' || r.status === 'late').length;
    const percentage = (presentCount / records.length) * 100;
    return Math.round(percentage * 10) / 10;
  };

  const calculateSyllabusProgress = (subjectId: string): number => {
    const topics = getSubjectSyllabus(subjectId);
    if (topics.length === 0) return 0;

    const completedCount = topics.filter(t => t.completed).length;
    const progress = (completedCount / topics.length) * 100;
    return Math.round(progress);
  };

  const updateAttendance = (studentId: string, isPresent: boolean) => {
    setStudents(prev =>
      prev.map(student =>
        student.id === studentId
          ? { ...student, attendance: isPresent ? Math.min(100, student.attendance + 1) : Math.max(0, student.attendance - 1) }
          : student
      )
    );
  };

  const proposeEvent = (event: { title: string; description?: string; date: string; proposedBy: string }) => {
    addCalendarEvent({
      title: event.title,
      description: event.description,
      date: event.date,
      status: 'pending',
      type: 'event',
      color: '#04ADEE'
    });
  };

  const addSyllabusTopic = (topic: { subjectId: string; topic: string; subtopics: string[] }) => {
    const newTopic: SyllabusTopic = {
      id: `topic-${Date.now()}`,
      subjectId: topic.subjectId,
      topic: topic.topic,
      subtopics: topic.subtopics.map((name, index) => ({
        name,
        taught: false,
        understood: false
      })),
      order: syllabus.filter(t => t.subjectId === topic.subjectId).length + 1,
      completed: false
    };
    setSyllabus(prev => [...prev, newTopic]);
  };

  const markTopicTaught = (topicId: string, subtopicIndex: number) => {
    setSyllabus(prev =>
      prev.map(topic =>
        topic.id === topicId
          ? {
              ...topic,
              subtopics: topic.subtopics.map((st, idx) =>
                idx === subtopicIndex ? { ...st, taught: !st.taught } : st
              )
            }
          : topic
      )
    );
  };

  const value: AppDataContextType = {
    students,
    teachers,
    admin,
    subjects,
    classes,
    announcements,
    calendarEvents,
    marks,
    attendance,
    syllabus,
    syllabusTopics: syllabus,
    feedbacks,
    chatMessages,
    resources,
    notifications,
    timetable,
    addStudent,
    addTeacher,
    addClass,
    addSubject,
    addAnnouncement,
    sendMessage,
    uploadMarks,
    markAttendance,
    updateAttendance,
    addCalendarEvent,
    updateCalendarEvent,
    proposeEvent,
    submitFeedback,
    uploadResource,
    updateProfile,
    updateSyllabusProgress,
    addSyllabusTopic,
    markTopicTaught,
    markNotificationRead,
    clearAllNotifications,
    getStudentById,
    getTeacherById,
    getStudentMarks,
    getStudentAttendance,
    getSubjectSyllabus,
    getStudentFeedbacks,
    getUnreadNotifications,
    calculateStudentAverage,
    calculateAttendancePercentage,
    calculateSyllabusProgress
  };

  return (
    <AppDataContext.Provider value={value}>
      {children}
    </AppDataContext.Provider>
  );
};
