export interface Student {
  id: string;
  name: string;
  email: string;
  avatar: string;
  subjects: string[];
  overallAverage: number;
  attendance: number;
}

export interface Teacher {
  id: string;
  name: string;
  email: string;
  avatar: string;
  subjects: string[];
  classes: string[];
}

export interface Admin {
  id: string;
  name: string;
  email: string;
  avatar: string;
}

export interface Subject {
  id: string;
  name: string;
  code: string;
  color: string;
  teacherId: string;
  teacherName: string;
}

export interface Mark {
  id: string;
  studentId: string;
  subjectId: string;
  assessmentName: string;
  assessmentType: 'quiz' | 'assignment' | 'exam' | 'test';
  score: number;
  maxScore: number;
  date: string;
  status: 'graded' | 'pending' | 'submitted';
  feedback?: string;
}

export interface AttendanceRecord {
  id: string;
  studentId: string;
  subjectId: string;
  date: string;
  status: 'present' | 'absent' | 'late';
}

export interface SyllabusTopic {
  id: string;
  subjectId: string;
  topic: string;
  subtopics: {
    name: string;
    taught: boolean;
    understood: boolean;
  }[];
  order: number;
  completed: boolean;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  author: string;
  authorRole: 'admin' | 'teacher';
  date: string;
  priority: 'low' | 'medium' | 'high';
  targetAudience: 'all' | 'students' | 'teachers';
}

export interface CalendarEvent {
  id: string;
  title: string;
  description?: string;
  date: string;
  endDate?: string;
  status?: 'pending' | 'approved' | 'rejected';
  type: 'exam' | 'assignment' | 'event' | 'holiday';
  subjectId?: string;
  color: string;
}

export interface Resource {
  id: string;
  title: string;
  description: string;
  subjectId: string;
  fileType: 'pdf' | 'video' | 'document' | 'link';
  fileSize?: string;
  uploadedBy: string;
  uploadedDate: string;
  url: string;
}

export interface Feedback {
  id: string;
  studentId: string;
  teacherId: string;
  subjectId: string;
  assignmentName: string;
  grade?: number;
  maxGrade?: number;
  comment: string;
  submittedDate: string;
  feedbackDate?: string;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  receiverId: string;
  receiverName: string;
  content: string;
  timestamp: string;
  read: boolean;
}

export interface Class {
  id: string;
  name: string;
  grade: string;
  students: string[];
  teachers: string[];
  subjects: string[];
}

export const STUDENTS: Student[] = [
  {
    id: 's1',
    name: 'Kananelo Buti',
    email: 'kananelo.buti@educare.com',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Kananelo',
    subjects: ['physics', 'computer-science', 'business'],
    overallAverage: 87.5,
    attendance: 94.2
  },
  {
    id: 's2',
    name: 'Adoniyas Wujira',
    email: 'adoniyas.wujira@educare.com',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Adoniyas',
    subjects: ['computer-science', 'economics', 'mathematics'],
    overallAverage: 91.3,
    attendance: 97.8
  },
  {
    id: 's3',
    name: 'Chinazom Onubogu',
    email: 'chinazom.onubogu@educare.com',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Chinazom',
    subjects: ['chemistry', 'biology', 'physics'],
    overallAverage: 89.7,
    attendance: 92.5
  }
];

export const TEACHERS: Teacher[] = [
  {
    id: 't1',
    name: 'Anuar Idd',
    email: 'anuar.idd@educare.com',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Anuar',
    subjects: ['computer-science'],
    classes: ['Class 10A', 'Class 11B']
  },
  {
    id: 't2',
    name: 'Ibrahim Ramadhan',
    email: 'ibrahim.ramadhan@educare.com',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Ibrahim',
    subjects: ['business'],
    classes: ['Class 10A', 'Class 10B']
  },
  {
    id: 't3',
    name: 'Salma Omary',
    email: 'salma.omary@educare.com',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Salma',
    subjects: ['chemistry'],
    classes: ['Class 11A', 'Class 11B']
  },
  {
    id: 't4',
    name: 'Collins Mkama',
    email: 'collins.mkama@educare.com',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Collins',
    subjects: ['economics'],
    classes: ['Class 10B', 'Class 11A']
  },
  {
    id: 't5',
    name: 'Amani Lekey',
    email: 'amani.lekey@educare.com',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Amani',
    subjects: ['biology', 'physics'],
    classes: ['Class 10A', 'Class 11B']
  }
];

export const ADMIN: Admin = {
  id: 'a1',
  name: 'Rashid Mikidadi',
  email: 'rashid.mikidadi@educare.com',
  avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Rashid'
};

export const SUBJECTS: Subject[] = [
  { id: 'physics', name: 'Physics', code: 'PHY101', color: '#10B981', teacherId: 't5', teacherName: 'Amani Lekey' },
  { id: 'computer-science', name: 'Computer Science', code: 'CS101', color: '#04ADEE', teacherId: 't1', teacherName: 'Anuar Idd' },
  { id: 'business', name: 'Business', code: 'BUS101', color: '#F59E0B', teacherId: 't2', teacherName: 'Ibrahim Ramadhan' },
  { id: 'economics', name: 'Economics', code: 'ECO101', color: '#8B5CF6', teacherId: 't4', teacherName: 'Collins Mkama' },
  { id: 'mathematics', name: 'Mathematics', code: 'MATH101', color: '#EF4444', teacherId: 't4', teacherName: 'Collins Mkama' },
  { id: 'chemistry', name: 'Chemistry', code: 'CHEM101', color: '#06B6D4', teacherId: 't3', teacherName: 'Salma Omary' },
  { id: 'biology', name: 'Biology', code: 'BIO101', color: '#84CC16', teacherId: 't5', teacherName: 'Amani Lekey' }
];

export const MARKS: Mark[] = [
  { id: 'm1', studentId: 's1', subjectId: 'physics', assessmentName: 'Motion and Forces Quiz', assessmentType: 'quiz', score: 18, maxScore: 20, date: '2024-02-15', status: 'graded', feedback: 'Excellent understanding of concepts!' },
  { id: 'm2', studentId: 's1', subjectId: 'physics', assessmentName: 'Mid-term Exam', assessmentType: 'exam', score: 85, maxScore: 100, date: '2024-03-01', status: 'graded' },
  { id: 'm3', studentId: 's1', subjectId: 'computer-science', assessmentName: 'Python Basics Test', assessmentType: 'test', score: 92, maxScore: 100, date: '2024-02-20', status: 'graded', feedback: 'Great coding skills!' },
  { id: 'm4', studentId: 's1', subjectId: 'computer-science', assessmentName: 'Data Structures Assignment', assessmentType: 'assignment', score: 0, maxScore: 50, date: '2024-03-25', status: 'pending' },
  { id: 'm5', studentId: 's1', subjectId: 'business', assessmentName: 'Marketing Quiz', assessmentType: 'quiz', score: 16, maxScore: 20, date: '2024-02-18', status: 'graded' },

  { id: 'm6', studentId: 's2', subjectId: 'computer-science', assessmentName: 'Python Basics Test', assessmentType: 'test', score: 95, maxScore: 100, date: '2024-02-20', status: 'graded', feedback: 'Outstanding performance!' },
  { id: 'm7', studentId: 's2', subjectId: 'economics', assessmentName: 'Supply and Demand Quiz', assessmentType: 'quiz', score: 19, maxScore: 20, date: '2024-02-22', status: 'graded' },
  { id: 'm8', studentId: 's2', subjectId: 'mathematics', assessmentName: 'Calculus Mid-term', assessmentType: 'exam', score: 88, maxScore: 100, date: '2024-03-01', status: 'graded' },
  { id: 'm9', studentId: 's2', subjectId: 'mathematics', assessmentName: 'Integration Problems', assessmentType: 'assignment', score: 0, maxScore: 30, date: '2024-03-20', status: 'pending' },

  { id: 'm10', studentId: 's3', subjectId: 'chemistry', assessmentName: 'Organic Chemistry Test', assessmentType: 'test', score: 87, maxScore: 100, date: '2024-02-25', status: 'graded' },
  { id: 'm11', studentId: 's3', subjectId: 'biology', assessmentName: 'Cell Biology Quiz', assessmentType: 'quiz', score: 17, maxScore: 20, date: '2024-02-28', status: 'graded', feedback: 'Good work!' },
  { id: 'm12', studentId: 's3', subjectId: 'physics', assessmentName: 'Motion and Forces Quiz', assessmentType: 'quiz', score: 19, maxScore: 20, date: '2024-02-15', status: 'graded' },
  { id: 'm13', studentId: 's3', subjectId: 'chemistry', assessmentName: 'Lab Report', assessmentType: 'assignment', score: 0, maxScore: 40, date: '2024-03-22', status: 'submitted', feedback: 'Under review' }
];

export const ATTENDANCE: AttendanceRecord[] = [
  { id: 'a1', studentId: 's1', subjectId: 'physics', date: '2024-03-01', status: 'present' },
  { id: 'a2', studentId: 's1', subjectId: 'physics', date: '2024-03-04', status: 'present' },
  { id: 'a3', studentId: 's1', subjectId: 'physics', date: '2024-03-06', status: 'absent' },
  { id: 'a4', studentId: 's1', subjectId: 'computer-science', date: '2024-03-01', status: 'present' },
  { id: 'a5', studentId: 's1', subjectId: 'computer-science', date: '2024-03-05', status: 'present' },
  { id: 'a6', studentId: 's1', subjectId: 'business', date: '2024-03-02', status: 'present' },

  { id: 'a7', studentId: 's2', subjectId: 'computer-science', date: '2024-03-01', status: 'present' },
  { id: 'a8', studentId: 's2', subjectId: 'computer-science', date: '2024-03-05', status: 'present' },
  { id: 'a9', studentId: 's2', subjectId: 'economics', date: '2024-03-02', status: 'present' },
  { id: 'a10', studentId: 's2', subjectId: 'mathematics', date: '2024-03-01', status: 'present' },
  { id: 'a11', studentId: 's2', subjectId: 'mathematics', date: '2024-03-03', status: 'present' },

  { id: 'a12', studentId: 's3', subjectId: 'chemistry', date: '2024-03-01', status: 'present' },
  { id: 'a13', studentId: 's3', subjectId: 'chemistry', date: '2024-03-04', status: 'late' },
  { id: 'a14', studentId: 's3', subjectId: 'biology', date: '2024-03-02', status: 'present' },
  { id: 'a15', studentId: 's3', subjectId: 'physics', date: '2024-03-01', status: 'present' }
];

export const SYLLABUS: SyllabusTopic[] = [
  {
    id: 'syl1',
    subjectId: 'physics',
    topic: 'Newton\'s Laws of Motion',
    subtopics: [
      { name: 'First Law of Motion', taught: true, understood: true },
      { name: 'Second Law of Motion', taught: true, understood: true },
      { name: 'Third Law of Motion', taught: true, understood: false }
    ],
    completed: true,
    order: 1
  },
  {
    id: 'syl2',
    subjectId: 'physics',
    topic: 'Energy and Work',
    subtopics: [
      { name: 'Kinetic Energy', taught: true, understood: true },
      { name: 'Potential Energy', taught: true, understood: true },
      { name: 'Work-Energy Theorem', taught: true, understood: false }
    ],
    completed: true,
    order: 2
  },
  {
    id: 'syl3',
    subjectId: 'physics',
    topic: 'Waves and Sound',
    subtopics: [
      { name: 'Wave Properties', taught: false, understood: false },
      { name: 'Sound Waves', taught: false, understood: false },
      { name: 'Doppler Effect', taught: false, understood: false }
    ],
    completed: false,
    order: 3
  },
  {
    id: 'syl4',
    subjectId: 'physics',
    topic: 'Electricity and Magnetism',
    subtopics: [
      { name: 'Electric Fields', taught: false, understood: false },
      { name: 'Magnetic Fields', taught: false, understood: false },
      { name: 'Electromagnetic Induction', taught: false, understood: false }
    ],
    completed: false,
    order: 4
  },

  {
    id: 'syl5',
    subjectId: 'computer-science',
    topic: 'Python Fundamentals',
    subtopics: [
      { name: 'Variables and Data Types', taught: true, understood: true },
      { name: 'Control Flow', taught: true, understood: true },
      { name: 'Functions', taught: true, understood: true }
    ],
    completed: true,
    order: 1
  },
  {
    id: 'syl6',
    subjectId: 'computer-science',
    topic: 'Object-Oriented Programming',
    subtopics: [
      { name: 'Classes and Objects', taught: true, understood: true },
      { name: 'Inheritance', taught: true, understood: false },
      { name: 'Polymorphism', taught: true, understood: false }
    ],
    completed: true,
    order: 2
  },
  {
    id: 'syl7',
    subjectId: 'computer-science',
    topic: 'Data Structures',
    subtopics: [
      { name: 'Lists and Arrays', taught: false, understood: false },
      { name: 'Stacks and Queues', taught: false, understood: false },
      { name: 'Trees', taught: false, understood: false }
    ],
    completed: false,
    order: 3
  },
  {
    id: 'syl8',
    subjectId: 'computer-science',
    topic: 'Algorithms',
    subtopics: [
      { name: 'Sorting Algorithms', taught: false, understood: false },
      { name: 'Searching Algorithms', taught: false, understood: false },
      { name: 'Time Complexity', taught: false, understood: false }
    ],
    completed: false,
    order: 4
  },

  {
    id: 'syl9',
    subjectId: 'chemistry',
    topic: 'Atomic Structure',
    subtopics: [
      { name: 'Subatomic Particles', taught: true, understood: true },
      { name: 'Atomic Models', taught: true, understood: true },
      { name: 'Electronic Configuration', taught: true, understood: false }
    ],
    completed: true,
    order: 1
  },
  {
    id: 'syl10',
    subjectId: 'chemistry',
    topic: 'Chemical Bonding',
    subtopics: [
      { name: 'Ionic Bonds', taught: true, understood: true },
      { name: 'Covalent Bonds', taught: true, understood: true },
      { name: 'Metallic Bonds', taught: true, understood: false }
    ],
    completed: true,
    order: 2
  },
  {
    id: 'syl11',
    subjectId: 'chemistry',
    topic: 'Organic Chemistry',
    subtopics: [
      { name: 'Hydrocarbons', taught: false, understood: false },
      { name: 'Functional Groups', taught: false, understood: false },
      { name: 'Reactions', taught: false, understood: false }
    ],
    completed: false,
    order: 3
  },

  {
    id: 'syl12',
    subjectId: 'economics',
    topic: 'Supply and Demand',
    subtopics: [
      { name: 'Law of Demand', taught: true, understood: true },
      { name: 'Law of Supply', taught: true, understood: true },
      { name: 'Market Equilibrium', taught: true, understood: false }
    ],
    completed: true,
    order: 1
  },
  {
    id: 'syl13',
    subjectId: 'economics',
    topic: 'Elasticity',
    subtopics: [
      { name: 'Price Elasticity of Demand', taught: false, understood: false },
      { name: 'Price Elasticity of Supply', taught: false, understood: false },
      { name: 'Income Elasticity', taught: false, understood: false }
    ],
    completed: false,
    order: 2
  },

  {
    id: 'syl14',
    subjectId: 'biology',
    topic: 'Cell Structure',
    subtopics: [
      { name: 'Prokaryotic Cells', taught: true, understood: true },
      { name: 'Eukaryotic Cells', taught: true, understood: true },
      { name: 'Cell Organelles', taught: true, understood: false }
    ],
    completed: true,
    order: 1
  },
  {
    id: 'syl15',
    subjectId: 'biology',
    topic: 'Genetics',
    subtopics: [
      { name: 'DNA Structure', taught: false, understood: false },
      { name: 'RNA and Protein Synthesis', taught: false, understood: false },
      { name: 'Mendelian Inheritance', taught: false, understood: false }
    ],
    completed: false,
    order: 2
  }
];

export const ANNOUNCEMENTS: Announcement[] = [
  {
    id: 'ann0',
    title: 'Physics Exam Tomorrow Morning',
    content: 'Reminder: Physics examination will be held tomorrow morning at 9:00 AM in Hall B. Please bring your calculators and exam permits. Topics covered: Newton\'s Laws, Energy and Work (Chapters 1-2). Good luck!',
    author: 'Amani Lekey',
    authorRole: 'teacher',
    date: '2024-03-14T16:30:00',
    priority: 'high',
    targetAudience: 'students'
  },
  {
    id: 'ann1',
    title: 'Mid-Term Examinations Schedule Released',
    content: 'The mid-term examination schedule has been published. Please check your timetable for specific dates and times. All exams will be held in the main examination hall.',
    author: 'Rashid Mikidadi',
    authorRole: 'admin',
    date: '2024-03-01T09:00:00',
    priority: 'high',
    targetAudience: 'all'
  },
  {
    id: 'ann2',
    title: 'Computer Science Workshop This Saturday',
    content: 'Join us for an exciting workshop on Web Development using React. Open to all students. Register at the CS department office.',
    author: 'Anuar Idd',
    authorRole: 'teacher',
    date: '2024-03-05T10:30:00',
    priority: 'medium',
    targetAudience: 'students'
  },
  {
    id: 'ann3',
    title: 'Library Hours Extended',
    content: 'The library will now be open until 8 PM on weekdays to support your exam preparation. Make the most of this extended time!',
    author: 'Rashid Mikidadi',
    authorRole: 'admin',
    date: '2024-03-03T14:00:00',
    priority: 'low',
    targetAudience: 'all'
  },
  {
    id: 'ann4',
    title: 'Chemistry Lab Safety Reminder',
    content: 'All students must wear proper lab coats and safety goggles during chemistry practicals. No exceptions will be made.',
    author: 'Salma Omary',
    authorRole: 'teacher',
    date: '2024-02-28T11:00:00',
    priority: 'high',
    targetAudience: 'students'
  },
  {
    id: 'ann5',
    title: 'Sports Day - March 15th',
    content: 'Annual sports day will be held on March 15th. All students are encouraged to participate. Sign up with your class representative.',
    author: 'Rashid Mikidadi',
    authorRole: 'admin',
    date: '2024-02-25T08:00:00',
    priority: 'medium',
    targetAudience: 'all'
  }
];

export const CALENDAR_EVENTS: CalendarEvent[] = [
  { id: 'cal1', title: 'Physics Mid-Term Exam', description: 'Chapters 1-5', date: '2024-03-15', type: 'exam', subjectId: 'physics', color: '#10B981' },
  { id: 'cal2', title: 'Computer Science Assignment Due', description: 'Data Structures project submission', date: '2024-03-25', type: 'assignment', subjectId: 'computer-science', color: '#04ADEE' },
  { id: 'cal3', title: 'Chemistry Lab Practical', description: 'Organic chemistry reactions', date: '2024-03-18', type: 'exam', subjectId: 'chemistry', color: '#06B6D4' },
  { id: 'cal4', title: 'Sports Day', description: 'Annual inter-class sports competition', date: '2024-03-15', type: 'event', color: '#F59E0B' },
  { id: 'cal5', title: 'Mathematics Quiz', description: 'Calculus and integration', date: '2024-03-20', type: 'exam', subjectId: 'mathematics', color: '#EF4444' },
  { id: 'cal6', title: 'Parent-Teacher Meeting', description: 'Discuss student progress', date: '2024-03-22', type: 'event', color: '#8B5CF6' },
  { id: 'cal7', title: 'Spring Break', description: 'School holiday', date: '2024-03-28', endDate: '2024-04-05', type: 'holiday', color: '#84CC16' },
  { id: 'cal8', title: 'Biology Field Trip', description: 'Visit to nature reserve', date: '2024-03-12', type: 'event', subjectId: 'biology', color: '#84CC16' }
];

export const RESOURCES: Resource[] = [
  { id: 'res1', title: 'Physics - Motion Notes', description: 'Comprehensive notes on Newton\'s laws', subjectId: 'physics', fileType: 'pdf', fileSize: '2.4 MB', uploadedBy: 'Amani Lekey', uploadedDate: '2024-02-10', url: '#' },
  { id: 'res2', title: 'Python Tutorial Video', description: 'Introduction to Python programming', subjectId: 'computer-science', fileType: 'video', fileSize: '156 MB', uploadedBy: 'Anuar Idd', uploadedDate: '2024-02-15', url: '#' },
  { id: 'res3', title: 'Chemistry Lab Manual', description: 'Safety procedures and experiments', subjectId: 'chemistry', fileType: 'pdf', fileSize: '5.1 MB', uploadedBy: 'Salma Omary', uploadedDate: '2024-02-08', url: '#' },
  { id: 'res4', title: 'Economics Study Guide', description: 'Supply and demand analysis', subjectId: 'economics', fileType: 'document', fileSize: '1.8 MB', uploadedBy: 'Collins Mkama', uploadedDate: '2024-02-20', url: '#' },
  { id: 'res5', title: 'Biology Diagrams', description: 'Cell structure illustrations', subjectId: 'biology', fileType: 'pdf', fileSize: '3.2 MB', uploadedBy: 'Amani Lekey', uploadedDate: '2024-02-18', url: '#' },
  { id: 'res6', title: 'Business Case Studies', description: 'Real-world marketing examples', subjectId: 'business', fileType: 'document', fileSize: '2.7 MB', uploadedBy: 'Ibrahim Ramadhan', uploadedDate: '2024-02-12', url: '#' },
  { id: 'res7', title: 'Mathematics Practice Problems', description: 'Calculus exercises with solutions', subjectId: 'mathematics', fileType: 'pdf', fileSize: '1.5 MB', uploadedBy: 'Collins Mkama', uploadedDate: '2024-02-22', url: '#' }
];

export const FEEDBACKS: Feedback[] = [
  { id: 'fb1', studentId: 's1', teacherId: 't5', subjectId: 'physics', assignmentName: 'Motion Lab Report', grade: 42, maxGrade: 50, comment: 'Good analysis but need more detailed calculations. Well presented.', submittedDate: '2024-02-20', feedbackDate: '2024-02-25' },
  { id: 'fb2', studentId: 's1', teacherId: 't1', subjectId: 'computer-science', assignmentName: 'Python Project', comment: 'Waiting for grading...', submittedDate: '2024-03-10' },
  { id: 'fb3', studentId: 's2', teacherId: 't1', subjectId: 'computer-science', assignmentName: 'Algorithm Analysis', grade: 48, maxGrade: 50, comment: 'Excellent work! Very thorough analysis and clean code.', submittedDate: '2024-02-18', feedbackDate: '2024-02-22' },
  { id: 'fb4', studentId: 's3', teacherId: 't3', subjectId: 'chemistry', assignmentName: 'Organic Reactions Report', comment: 'Under review', submittedDate: '2024-03-08' }
];

export function getStudentById(id: string): Student | undefined {
  return STUDENTS.find(s => s.id === id);
}

export function getTeacherById(id: string): Teacher | undefined {
  return TEACHERS.find(t => t.id === id);
}

export function getSubjectById(id: string): Subject | undefined {
  return SUBJECTS.find(s => s.id === id);
}

export function getStudentMarks(studentId: string, subjectId?: string): Mark[] {
  return MARKS.filter(m =>
    m.studentId === studentId && (!subjectId || m.subjectId === subjectId)
  );
}

export function getStudentAttendance(studentId: string, subjectId?: string): AttendanceRecord[] {
  return ATTENDANCE.filter(a =>
    a.studentId === studentId && (!subjectId || a.subjectId === subjectId)
  );
}

export function getSubjectSyllabus(subjectId: string): SyllabusTopic[] {
  return SYLLABUS.filter(s => s.subjectId === subjectId).sort((a, b) => a.order - b.order);
}

export function getSubjectResources(subjectId: string): Resource[] {
  return RESOURCES.filter(r => r.subjectId === subjectId);
}

export function getStudentFeedbacks(studentId: string): Feedback[] {
  return FEEDBACKS.filter(f => f.studentId === studentId);
}

export function calculateAttendancePercentage(records: AttendanceRecord[]): number {
  if (records.length === 0) return 0;
  const presentCount = records.filter(r => r.status === 'present' || r.status === 'late').length;
  return Math.round((presentCount / records.length) * 100);
}

export function calculateSubjectAverage(marks: Mark[]): number {
  const gradedMarks = marks.filter(m => m.status === 'graded');
  if (gradedMarks.length === 0) return 0;
  const total = gradedMarks.reduce((sum, m) => sum + (m.score / m.maxScore) * 100, 0);
  return Math.round(total / gradedMarks.length * 10) / 10;
}

export function getSyllabusProgress(topics: SyllabusTopic[]): number {
  if (topics.length === 0) return 0;
  const completedCount = topics.filter(t => t.completed).length;
  return Math.round((completedCount / topics.length) * 100);
}

export const CLASSES: Class[] = [
  {
    id: 'class1',
    name: 'Class 10A',
    grade: '10',
    students: ['s1', 's2'],
    teachers: ['t1', 't2', 't5'],
    subjects: ['physics', 'computer-science', 'business']
  },
  {
    id: 'class2',
    name: 'Class 10B',
    grade: '10',
    students: ['s3'],
    teachers: ['t2', 't4'],
    subjects: ['business', 'economics']
  },
  {
    id: 'class3',
    name: 'Class 11A',
    grade: '11',
    students: ['s1', 's3'],
    teachers: ['t3', 't4'],
    subjects: ['chemistry', 'economics']
  },
  {
    id: 'class4',
    name: 'Class 11B',
    grade: '11',
    students: ['s2', 's3'],
    teachers: ['t1', 't3', 't5'],
    subjects: ['computer-science', 'chemistry', 'biology']
  }
];

export const CHAT_MESSAGES: ChatMessage[] = [
  {
    id: 'chat1',
    senderId: 's1',
    senderName: 'Kananelo Buti',
    receiverId: 't1',
    receiverName: 'Anuar Idd',
    content: 'Hello Professor, I have a question about the data structures assignment.',
    timestamp: '2024-03-10T14:30:00',
    read: true
  },
  {
    id: 'chat2',
    senderId: 't1',
    senderName: 'Anuar Idd',
    receiverId: 's1',
    receiverName: 'Kananelo Buti',
    content: 'Hi Kananelo! Sure, what would you like to know?',
    timestamp: '2024-03-10T14:35:00',
    read: true
  },
  {
    id: 'chat3',
    senderId: 's2',
    senderName: 'Adoniyas Wujira',
    receiverId: 't4',
    receiverName: 'Collins Mkama',
    content: 'Could you please clarify the elasticity concept we covered today?',
    timestamp: '2024-03-11T16:20:00',
    read: false
  }
];
