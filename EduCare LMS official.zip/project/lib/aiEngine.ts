import {
  STUDENTS,
  TEACHERS,
  SUBJECTS,
  ANNOUNCEMENTS,
  CALENDAR_EVENTS,
  MARKS,
  CLASSES,
  ATTENDANCE,
  FEEDBACKS,
  getStudentById,
  getTeacherById,
  getStudentMarks,
  getStudentAttendance,
  getSubjectSyllabus,
  calculateAttendancePercentage,
  calculateSubjectAverage,
  getSyllabusProgress,
  getStudentFeedbacks
} from './demoData';

export interface AIMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  responseType?: 'text' | 'stats' | 'table' | 'alert' | 'advice' | 'analysis';
  data?: any;
}

export interface AIContext {
  userId: string;
  userRole: 'student' | 'teacher' | 'admin';
  conversationHistory: AIMessage[];
}

export interface AIResponse {
  content: string;
  responseType: 'text' | 'stats' | 'table' | 'alert' | 'advice' | 'analysis';
  data?: any;
  suggestions?: string[];
}

const greetingKeywords = ['hi', 'hello', 'hey', 'good morning', 'good afternoon', 'good evening', 'greetings', 'sup'];
const attendanceKeywords = ['attendance', 'present', 'absent', 'classes attended', 'how many classes', 'skip'];
const gradeKeywords = ['grade', 'marks', 'score', 'result', 'performance', 'average', 'exam', 'test', 'quiz', 'assessment'];
const syllabusKeywords = ['syllabus', 'topic', 'chapter', 'covered', 'progress', 'curriculum', 'learn'];
const adviceKeywords = ['advice', 'suggest', 'recommend', 'help', 'improve', 'better', 'tip', 'guidance', 'what should i', 'how can i'];
const motivationKeywords = ['motivate', 'encourage', 'inspire', 'struggling', 'difficult', 'hard', 'stress'];
const comparisonKeywords = ['compare', 'rank', 'position', 'standing', 'versus', 'better than', 'classmate'];
const scheduleKeywords = ['schedule', 'timetable', 'class', 'when', 'time', 'next'];
const announcementKeywords = ['announcement', 'news', 'update', 'notice'];
const upcomingKeywords = ['upcoming', 'next', 'future', 'soon', 'tomorrow'];
const teacherKeywords = ['teacher', 'instructor', 'professor', 'faculty'];
const studyKeywords = ['study', 'revise', 'prepare', 'focus', 'concentrate'];
const weaknessKeywords = ['weakness', 'weak', 'struggling', 'low', 'failing', 'bad at'];
const strengthKeywords = ['strength', 'strong', 'good at', 'excel', 'best'];
const statisticsKeywords = ['statistics', 'stats', 'data', 'analytics', 'report', 'overview', 'summary'];
const decisionKeywords = ['decision', 'decide', 'choose', 'should', 'recommend'];
const insightsKeywords = ['insight', 'analysis', 'trend', 'pattern', 'observation'];

function normalizeText(text: string): string {
  return text.toLowerCase().trim();
}

function containsKeywords(text: string, keywords: string[]): boolean {
  const normalized = normalizeText(text);
  return keywords.some(keyword => normalized.includes(keyword));
}

function getGreetingResponse(context: AIContext): AIResponse {
  const user = context.userRole === 'student'
    ? getStudentById(context.userId)
    : context.userRole === 'teacher'
    ? getTeacherById(context.userId)
    : { name: 'Admin' };

  const time = new Date().getHours();
  let timeGreeting = 'Hello';
  if (time < 12) timeGreeting = 'Good morning';
  else if (time < 18) timeGreeting = 'Good afternoon';
  else timeGreeting = 'Good evening';

  const greetings = context.userRole === 'student'
    ? [
        `${timeGreeting}, ${user?.name}! Ready to tackle your academic goals today?`,
        `Hey ${user?.name}! Let's make today productive. What can I help you with?`,
        `${timeGreeting} ${user?.name}! I'm here to help you excel. What would you like to know?`,
      ]
    : context.userRole === 'teacher'
    ? [
        `${timeGreeting}, ${user?.name}! How can I assist you with your teaching today?`,
        `Hello ${user?.name}! Ready to support your students?`,
      ]
    : [
        `${timeGreeting}! How can I assist you with school management today?`,
        `Hello Admin! Let's manage the school efficiently. What do you need?`,
      ];

  const greeting = greetings[Math.floor(Math.random() * greetings.length)];

  return {
    content: greeting,
    responseType: 'text',
    suggestions: getSuggestedQuestions(context)
  };
}

function getPersonalizedAdvice(context: AIContext, query: string): AIResponse {
  if (context.userRole !== 'student') {
    return getDefaultResponse(context, query);
  }

  const student = getStudentById(context.userId);
  if (!student) return getDefaultResponse(context, query);

  const allMarks = getStudentMarks(context.userId);
  const gradedMarks = allMarks.filter(m => m.status === 'graded');
  const overallAverage = calculateSubjectAverage(gradedMarks);
  const allAttendance = getStudentAttendance(context.userId);
  const attendancePercentage = calculateAttendancePercentage(allAttendance);

  const studentSubjects = SUBJECTS.filter(s => student.subjects.includes(s.id));
  const subjectPerformance = studentSubjects.map(subject => {
    const marks = getStudentMarks(context.userId, subject.id).filter(m => m.status === 'graded');
    const average = calculateSubjectAverage(marks);
    const attendance = calculateAttendancePercentage(getStudentAttendance(context.userId, subject.id));
    return { subject: subject.name, average, attendance, subjectId: subject.id };
  });

  const weakSubjects = subjectPerformance.filter(s => s.average < 70).sort((a, b) => a.average - b.average);
  const strongSubjects = subjectPerformance.filter(s => s.average >= 85).sort((a, b) => b.average - a.average);

  let advice = '';
  let recommendations: string[] = [];

  if (containsKeywords(query, weaknessKeywords) || containsKeywords(query, adviceKeywords)) {
    if (weakSubjects.length > 0) {
      advice = `Based on your performance, here's my analysis:\n\n`;
      advice += `Your areas for improvement are: ${weakSubjects.map(s => s.subject).join(', ')}. `;

      weakSubjects.forEach((weak, idx) => {
        if (idx < 2) {
          advice += `\n\nFor ${weak.subject} (${weak.average.toFixed(1)}%):\n`;
          if (weak.attendance < 80) {
            advice += `• Your attendance is ${weak.attendance.toFixed(1)}% - aim for at least 90% to not miss important concepts.\n`;
            recommendations.push(`Improve ${weak.subject} attendance`);
          }
          advice += `• Dedicate 30-45 minutes daily for ${weak.subject} revision.\n`;
          advice += `• Focus on understanding fundamentals before moving to complex topics.\n`;
          advice += `• Consider forming a study group or seeking help from your teacher.\n`;

          const feedbacks = getStudentFeedbacks(context.userId).filter(f => f.subjectId === weak.subjectId);
          if (feedbacks.length > 0) {
            const latestFeedback = feedbacks[feedbacks.length - 1];
            advice += `• Teacher feedback: "${latestFeedback.comment}"\n`;
          }
        }
      });

      recommendations.push('Create a study schedule', 'Join study groups', 'Meet with teachers');
    } else {
      advice = `Great news! You don't have any weak subjects. Your performance across all subjects is strong. `;
      advice += `To maintain this excellence:\n`;
      advice += `• Keep consistent study habits\n`;
      advice += `• Challenge yourself with advanced topics\n`;
      advice += `• Help classmates who are struggling - teaching reinforces learning\n`;
      advice += `• Stay ahead of the syllabus`;
      recommendations.push('Explore advanced topics', 'Join competitions');
    }
  } else if (containsKeywords(query, strengthKeywords)) {
    if (strongSubjects.length > 0) {
      advice = `Your strongest subjects are: ${strongSubjects.map(s => s.subject).join(', ')}. `;
      advice += `\n\nYou're excelling in these areas! Here's how to leverage your strengths:\n`;
      advice += `• Consider participating in competitions or olympiads\n`;
      advice += `• Tutor classmates in these subjects to deepen your understanding\n`;
      advice += `• Explore advanced topics beyond the syllabus\n`;
      advice += `• Connect these strengths to potential career paths`;
      recommendations.push('Join subject competitions', 'Explore career options');
    } else {
      advice = `While you don't have standout subjects yet, you're building a solid foundation. `;
      advice += `Focus on consistent effort across all subjects, and your strengths will emerge naturally.`;
    }
  } else {
    const studentRank = STUDENTS.filter(s => s.overallAverage > overallAverage).length + 1;

    advice = `Let me provide comprehensive advice based on your overall performance:\n\n`;
    advice += `📊 Current Status:\n`;
    advice += `• Overall Average: ${overallAverage.toFixed(1)}%\n`;
    advice += `• Attendance: ${attendancePercentage.toFixed(1)}%\n`;
    advice += `• Class Rank: ${studentRank} of ${STUDENTS.length}\n\n`;

    if (overallAverage >= 85) {
      advice += `🌟 Excellent Performance! You're in the top tier.\n\n`;
      advice += `To maintain excellence:\n`;
      advice += `• Set higher goals - aim for 95%+\n`;
      advice += `• Take on leadership roles in study groups\n`;
      advice += `• Prepare for competitive exams early`;
    } else if (overallAverage >= 70) {
      advice += `✅ Good Performance! You're on the right track.\n\n`;
      advice += `To reach excellence:\n`;
      advice += `• Focus extra time on ${weakSubjects[0]?.subject || 'weaker subjects'}\n`;
      advice += `• Increase study time by 30 minutes daily\n`;
      advice += `• Practice more past papers and questions`;
    } else {
      advice += `⚠️ Needs Improvement. But don't worry - with focused effort, you can improve significantly!\n\n`;
      advice += `Immediate action plan:\n`;
      advice += `• Meet with teachers for personalized guidance\n`;
      advice += `• Create a strict study schedule (2-3 hours daily)\n`;
      advice += `• Focus on understanding, not memorizing\n`;
      advice += `• Improve attendance to at least 90%`;
    }

    if (attendancePercentage < 75) {
      advice += `\n\n🚨 Critical: Your attendance is ${attendancePercentage.toFixed(1)}%. This is severely affecting your learning. Aim for 90%+ immediately.`;
      recommendations.push('Improve attendance urgently');
    }

    recommendations.push('Review study plan', 'Track progress weekly');
  }

  const studentRank = STUDENTS.filter(s => s.overallAverage > overallAverage).length + 1;

  return {
    content: advice,
    responseType: 'advice',
    data: {
      overallAverage,
      attendancePercentage,
      rank: studentRank,
      weakSubjects,
      strongSubjects,
      recommendations
    },
    suggestions: recommendations.length > 0
      ? recommendations.slice(0, 3)
      : ['Show me my grades', 'What\'s my attendance?', 'Upcoming exams?']
  };
}

function getMotivationalResponse(context: AIContext): AIResponse {
  const motivationalQuotes = [
    "Success is not final, failure is not fatal: it is the courage to continue that counts. Keep pushing forward!",
    "Every expert was once a beginner. Don't be afraid to ask questions and seek help.",
    "The difference between try and triumph is a little 'umph'! You've got this!",
    "Believe in yourself. You are braver than you think, more talented than you know, and capable of more than you imagine.",
    "Difficult roads often lead to beautiful destinations. Keep going!",
    "Your only limit is you. Be brave, be fearless, be unstoppable!",
    "Remember why you started. Your goals are worth the effort!"
  ];

  const tip = motivationalQuotes[Math.floor(Math.random() * motivationalQuotes.length)];

  let advice = '';
  if (context.userRole === 'student') {
    const student = getStudentById(context.userId);
    if (student) {
      advice = `Hey ${student.name.split(' ')[0]}, I can see you're working hard. ${tip}\n\n`;
      advice += `Here's a quick boost:\n`;
      advice += `✨ Take short breaks every 45 minutes\n`;
      advice += `✨ Celebrate small wins - every completed task counts\n`;
      advice += `✨ Remember: progress, not perfection\n`;
      advice += `✨ You're doing better than you think!`;
    }
  } else {
    advice = tip;
  }

  return {
    content: advice,
    responseType: 'advice',
    suggestions: ['What are my strengths?', 'Show me my progress', 'Study tips']
  };
}

function getAdminStatistics(context: AIContext, query: string): AIResponse {
  if (context.userRole !== 'admin') {
    return { content: 'Administrative features are only available to admins.', responseType: 'text' };
  }

  const totalStudents = STUDENTS.length;
  const totalTeachers = TEACHERS.length;
  const totalClasses = CLASSES.length;
  const totalSubjects = SUBJECTS.length;

  const schoolAverage = STUDENTS.reduce((sum, s) => sum + s.overallAverage, 0) / totalStudents;
  const schoolAttendance = STUDENTS.reduce((sum, s) => sum + s.attendance, 0) / totalStudents;

  const topPerformers = [...STUDENTS].sort((a, b) => b.overallAverage - a.overallAverage).slice(0, 5);
  const atRiskStudents = [...STUDENTS].filter(s => s.overallAverage < 50 || s.attendance < 75);

  const subjectPerformance = SUBJECTS.map(subject => {
    const relevantMarks = MARKS.filter(m => m.subjectId === subject.id && m.status === 'graded');
    const avg = relevantMarks.length > 0
      ? relevantMarks.reduce((sum, m) => sum + m.score, 0) / relevantMarks.length
      : 0;
    return { subject: subject.name, average: avg, students: new Set(relevantMarks.map(m => m.studentId)).size };
  }).sort((a, b) => b.average - a.average);

  let response = `📊 School Performance Overview:\n\n`;
  response += `👥 Total Students: ${totalStudents}\n`;
  response += `👨‍🏫 Total Teachers: ${totalTeachers}\n`;
  response += `📚 Total Subjects: ${totalSubjects}\n`;
  response += `🏫 Total Classes: ${totalClasses}\n\n`;

  response += `📈 Performance Metrics:\n`;
  response += `• School Average: ${schoolAverage.toFixed(1)}%\n`;
  response += `• Average Attendance: ${schoolAttendance.toFixed(1)}%\n`;
  response += `• Top Performers: ${topPerformers.length}\n`;
  response += `• At-Risk Students: ${atRiskStudents.length}\n\n`;

  response += `🏆 Top Performing Students:\n`;
  topPerformers.forEach((s, idx) => {
    response += `${idx + 1}. ${s.name} - ${s.overallAverage}%\n`;
  });

  if (atRiskStudents.length > 0) {
    response += `\n⚠️ Students Needing Attention (${atRiskStudents.length}):\n`;
    atRiskStudents.slice(0, 5).forEach((s, idx) => {
      response += `${idx + 1}. ${s.name} - Average: ${s.overallAverage}%, Attendance: ${s.attendance}%\n`;
    });
  }

  response += `\n📚 Subject Performance:\n`;
  subjectPerformance.slice(0, 5).forEach((s, idx) => {
    response += `${idx + 1}. ${s.subject} - ${s.average.toFixed(1)}% (${s.students} students)\n`;
  });

  return {
    content: response,
    responseType: 'analysis',
    data: {
      totalStudents,
      totalTeachers,
      schoolAverage: schoolAverage.toFixed(1),
      schoolAttendance: schoolAttendance.toFixed(1),
      topPerformers: topPerformers.map(s => ({ name: s.name, average: s.overallAverage })),
      atRiskStudents: atRiskStudents.map(s => ({
        name: s.name,
        average: s.overallAverage,
        attendance: s.attendance
      })),
      subjectPerformance
    },
    suggestions: ['Show teacher performance', 'Attendance trends', 'Subject analysis']
  };
}

function getAdminDecisionSupport(context: AIContext, query: string): AIResponse {
  if (context.userRole !== 'admin') {
    return { content: 'Decision support is only available to administrators.', responseType: 'text' };
  }

  const atRiskStudents = STUDENTS.filter(s => s.overallAverage < 50 || s.attendance < 75);
  const excellentStudents = STUDENTS.filter(s => s.overallAverage >= 90 && s.attendance >= 90);

  let response = `🎯 Decision Support & Recommendations:\n\n`;

  if (atRiskStudents.length > 0) {
    response += `⚠️ URGENT ACTIONS NEEDED:\n`;
    response += `${atRiskStudents.length} students are at risk of failing.\n\n`;
    response += `Recommended Actions:\n`;
    response += `1. Schedule parent-teacher meetings for these students\n`;
    response += `2. Assign peer tutors from high-performing students\n`;
    response += `3. Create remedial classes for struggling subjects\n`;
    response += `4. Monitor attendance more strictly\n`;
    response += `5. Provide counseling support\n\n`;
  }

  response += `💡 Strategic Recommendations:\n\n`;

  const lowAttendanceSubjects = SUBJECTS.map(subject => {
    const records = ATTENDANCE.filter(a => a.subjectId === subject.id);
    const avgAttendance = records.length > 0
      ? (records.filter(r => r.status === 'present').length / records.length) * 100
      : 100;
    return { subject: subject.name, attendance: avgAttendance };
  }).filter(s => s.attendance < 80).sort((a, b) => a.attendance - b.attendance);

  if (lowAttendanceSubjects.length > 0) {
    response += `📉 Low Attendance Subjects:\n`;
    lowAttendanceSubjects.forEach(s => {
      response += `• ${s.subject}: ${s.attendance.toFixed(1)}% - Consider reviewing teaching methods or schedule\n`;
    });
    response += `\n`;
  }

  response += `🌟 Opportunities:\n`;
  response += `• ${excellentStudents.length} high-performing students ready for advanced programs\n`;
  response += `• Consider introducing honors classes or enrichment programs\n`;
  response += `• Leverage top students as peer mentors\n\n`;

  const teacherWorkload = TEACHERS.map(t => ({
    name: t.name,
    subjects: t.subjects.length,
    classes: t.classes.length
  })).sort((a, b) => (b.subjects + b.classes) - (a.subjects + a.classes));

  response += `👨‍🏫 Teacher Workload Analysis:\n`;
  teacherWorkload.slice(0, 3).forEach(t => {
    response += `• ${t.name}: ${t.subjects} subjects, ${t.classes} classes\n`;
  });

  return {
    content: response,
    responseType: 'analysis',
    data: {
      atRiskCount: atRiskStudents.length,
      excellentCount: excellentStudents.length,
      lowAttendanceSubjects,
      teacherWorkload
    },
    suggestions: ['View at-risk students', 'Teacher assignments', 'Budget recommendations']
  };
}

function getAttendanceResponse(context: AIContext, query: string): AIResponse {
  if (context.userRole !== 'student') {
    return {
      content: 'Attendance information is only available for students.',
      responseType: 'text'
    };
  }

  const student = getStudentById(context.userId);
  if (!student) {
    return {
      content: 'Student information not found.',
      responseType: 'text'
    };
  }

  const allAttendance = getStudentAttendance(context.userId);
  const overallPercentage = calculateAttendancePercentage(allAttendance);
  const present = allAttendance.filter(a => a.status === 'present').length;
  const absent = allAttendance.filter(a => a.status === 'absent').length;
  const late = allAttendance.filter(a => a.status === 'late').length;

  const studentSubjects = SUBJECTS.filter(s => student.subjects.includes(s.id));
  const subjectAttendance = studentSubjects.map(subject => {
    const records = getStudentAttendance(context.userId, subject.id);
    return {
      subject: subject.name,
      percentage: calculateAttendancePercentage(records),
      total: records.length,
      present: records.filter(r => r.status === 'present').length,
      absent: records.filter(r => r.status === 'absent').length
    };
  });

  let responseText = `Your overall attendance is ${overallPercentage}%. `;
  responseText += `You've attended ${present} classes, missed ${absent}, and were late to ${late}. `;

  if (overallPercentage < 75) {
    responseText += '\n\n🚨 CRITICAL: Your attendance is below the recommended 75%. This will seriously impact your learning and may affect your eligibility for exams. You need to improve immediately!';
  } else if (overallPercentage < 85) {
    responseText += '\n\n⚠️ Your attendance needs improvement. Aim for at least 90% to ensure you don\'t miss important concepts.';
  } else if (overallPercentage >= 95) {
    responseText += '\n\n🌟 Outstanding attendance! Your consistency sets a great example!';
  } else {
    responseText += '\n\n✅ Good attendance! Keep it up!';
  }

  return {
    content: responseText,
    responseType: 'stats',
    data: {
      overall: overallPercentage,
      present,
      absent,
      late,
      subjects: subjectAttendance
    },
    suggestions: [
      'Show me my grades',
      'What subjects am I weak in?',
      'Give me study advice'
    ]
  };
}

function getGradesResponse(context: AIContext, query: string): AIResponse {
  if (context.userRole !== 'student') {
    return {
      content: 'Grade information is only available for students.',
      responseType: 'text'
    };
  }

  const student = getStudentById(context.userId);
  if (!student) {
    return {
      content: 'Student information not found.',
      responseType: 'text'
    };
  }

  const allMarks = getStudentMarks(context.userId);
  const gradedMarks = allMarks.filter(m => m.status === 'graded');
  const pendingMarks = allMarks.filter(m => m.status === 'pending' || m.status === 'submitted');

  if (gradedMarks.length === 0) {
    return {
      content: 'You don\'t have any graded assessments yet.',
      responseType: 'text'
    };
  }

  const overallAverage = calculateSubjectAverage(gradedMarks);

  const studentSubjects = SUBJECTS.filter(s => student.subjects.includes(s.id));
  const subjectGrades = studentSubjects.map(subject => {
    const marks = getStudentMarks(context.userId, subject.id).filter(m => m.status === 'graded');
    const avg = calculateSubjectAverage(marks);
    return {
      subject: subject.name,
      average: avg,
      assessments: marks.length,
      trend: marks.length >= 2 ? (marks[marks.length - 1].score - marks[0].score > 0 ? '📈' : '📉') : '—'
    };
  });

  let responseText = `📊 Your overall average is ${overallAverage.toFixed(1)}%. `;
  responseText += `You have ${gradedMarks.length} graded assessments`;

  if (pendingMarks.length > 0) {
    responseText += ` and ${pendingMarks.length} pending assessments.`;
  } else {
    responseText += '.';
  }

  responseText += `\n\n`;

  if (overallAverage >= 90) {
    responseText += '🏆 Outstanding performance! You\'re in the top tier. Keep pushing for perfection!';
  } else if (overallAverage >= 80) {
    responseText += '🌟 Great work! You\'re doing well. With a bit more focus, you can reach excellence!';
  } else if (overallAverage >= 70) {
    responseText += '👍 Good job, but there\'s significant room for improvement. Let\'s work on boosting your scores!';
  } else if (overallAverage >= 50) {
    responseText += '⚠️ Your performance needs attention. Don\'t worry - with focused effort and the right strategies, you can improve significantly!';
  } else {
    responseText += '🚨 Critical situation. You need immediate intervention. Let\'s create an action plan to turn things around!';
  }

  const studentRank = STUDENTS.filter(s => s.overallAverage > overallAverage).length + 1;

  return {
    content: responseText,
    responseType: 'table',
    data: {
      overall: overallAverage,
      graded: gradedMarks.length,
      pending: pendingMarks.length,
      subjects: subjectGrades,
      rank: studentRank
    },
    suggestions: [
      'What subjects am I weak in?',
      'Give me study advice',
      'How can I improve?'
    ]
  };
}

function getSyllabusResponse(context: AIContext, query: string): AIResponse {
  if (context.userRole !== 'student') {
    return {
      content: 'Syllabus progress is only available for students.',
      responseType: 'text'
    };
  }

  const student = getStudentById(context.userId);
  if (!student) {
    return {
      content: 'Student information not found.',
      responseType: 'text'
    };
  }

  const studentSubjects = SUBJECTS.filter(s => student.subjects.includes(s.id));
  const syllabusData = studentSubjects.map(subject => {
    const topics = getSubjectSyllabus(subject.id);
    const progress = getSyllabusProgress(topics);
    const completed = topics.filter(t => t.completed).length;
    const remaining = topics.filter(t => !t.completed).length;

    return {
      subject: subject.name,
      progress,
      completed,
      remaining,
      total: topics.length,
      topics: topics.map(t => ({
        title: t.topic,
        completed: t.completed
      }))
    };
  });

  const avgProgress = Math.round(
    syllabusData.reduce((sum, s) => sum + s.progress, 0) / syllabusData.length
  );

  let responseText = `📚 Your overall syllabus progress is ${avgProgress}%. `;

  const completedTopics = syllabusData.reduce((sum, s) => sum + s.completed, 0);
  const totalTopics = syllabusData.reduce((sum, s) => sum + s.total, 0);

  responseText += `You've completed ${completedTopics} out of ${totalTopics} topics across all subjects. `;

  if (avgProgress >= 80) {
    responseText += '\n\n🎯 Excellent progress! You\'re well on track and ahead of schedule.';
  } else if (avgProgress >= 60) {
    responseText += '\n\n👍 Good progress! Keep working steadily to stay on track.';
  } else if (avgProgress >= 40) {
    responseText += '\n\n⚠️ You\'re falling behind. Dedicate more time to catching up on pending topics.';
  } else {
    responseText += '\n\n🚨 You\'re significantly behind. Create a catch-up plan immediately and stick to it!';
  }

  return {
    content: responseText,
    responseType: 'table',
    data: {
      overall: avgProgress,
      subjects: syllabusData
    },
    suggestions: [
      'What should I study today?',
      'Which topics are pending?',
      'Study tips for weak subjects'
    ]
  };
}

function getUpcomingEventsResponse(context: AIContext): AIResponse {
  const now = new Date();
  const upcomingEvents = CALENDAR_EVENTS.filter(event =>
    new Date(event.date) >= now
  ).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  if (upcomingEvents.length === 0) {
    return {
      content: 'There are no upcoming events at the moment.',
      responseType: 'text'
    };
  }

  const nextEvent = upcomingEvents[0];
  const daysUntil = Math.ceil((new Date(nextEvent.date).getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

  let responseText = `📅 Your next event is "${nextEvent.title}" `;

  if (daysUntil === 0) {
    responseText += 'today! ';
  } else if (daysUntil === 1) {
    responseText += 'tomorrow. ';
  } else {
    responseText += `in ${daysUntil} days. `;
  }

  responseText += nextEvent.description;

  if (upcomingEvents.length > 1) {
    responseText += `\n\nYou have ${upcomingEvents.length} upcoming events in total. Stay prepared!`;
  }

  return {
    content: responseText,
    responseType: 'table',
    data: {
      events: upcomingEvents.slice(0, 5).map(e => ({
        title: e.title,
        description: e.description,
        date: e.date,
        type: e.type
      }))
    },
    suggestions: [
      'How should I prepare?',
      'Show me my grades',
      'What topics should I revise?'
    ]
  };
}

function getAnnouncementsResponse(context: AIContext): AIResponse {
  const recentAnnouncements = ANNOUNCEMENTS.slice(0, 3);

  if (recentAnnouncements.length === 0) {
    return {
      content: 'There are no announcements at the moment.',
      responseType: 'text'
    };
  }

  const latestAnnouncement = recentAnnouncements[0];

  let responseText = `📢 Latest announcement: "${latestAnnouncement.title}" by ${latestAnnouncement.author}. `;
  responseText += latestAnnouncement.content;

  if (recentAnnouncements.length > 1) {
    responseText += `\n\nThere are ${recentAnnouncements.length} recent announcements in total.`;
  }

  return {
    content: responseText,
    responseType: 'alert',
    data: {
      announcements: recentAnnouncements.map(a => ({
        title: a.title,
        content: a.content,
        author: a.author,
        priority: a.priority,
        date: a.date
      }))
    },
    suggestions: [
      'What\'s my next class?',
      'Show me upcoming events',
      'What are my grades?'
    ]
  };
}

function getDefaultResponse(context: AIContext, query: string): AIResponse {
  const responses = context.userRole === 'student'
    ? [
        'I\'m here to help you succeed! Ask me about your grades, attendance, study advice, or how to improve your performance.',
        'I can provide insights on your academic performance, suggest study strategies, and help you stay on track. What would you like to know?',
        'Not sure what you mean, but I\'m great at helping with grades, attendance, study tips, and personalized advice. Try asking something specific!',
      ]
    : context.userRole === 'teacher'
    ? [
        'I can help you with class management, student performance, and teaching strategies. What do you need?',
        'Ask me about your classes, student analytics, or upcoming events.',
      ]
    : [
        'I can provide school statistics, student analytics, teacher performance data, and decision support. What would you like to know?',
        'Ask me about overall school performance, at-risk students, or strategic recommendations.',
      ];

  return {
    content: responses[Math.floor(Math.random() * responses.length)],
    responseType: 'text',
    suggestions: getSuggestedQuestions(context)
  };
}

function getSuggestedQuestions(context: AIContext): string[] {
  if (context.userRole === 'student') {
    return [
      'What subjects am I weak in?',
      'Give me study advice',
      'Show me my grades',
      'What\'s my attendance?',
      'How can I improve?',
      'Motivate me!',
      'What should I focus on?'
    ];
  } else if (context.userRole === 'teacher') {
    return [
      'Show me my classes',
      'Student performance overview',
      'What\'s the latest announcement?',
      'Show me upcoming events'
    ];
  } else {
    return [
      'Show school statistics',
      'Which students need attention?',
      'Subject performance analysis',
      'Teacher workload overview',
      'Strategic recommendations',
      'Attendance trends'
    ];
  }
}

export async function generateAIResponse(
  query: string,
  context: AIContext
): Promise<AIResponse> {
  await new Promise(resolve => setTimeout(resolve, 500 + Math.random() * 1000));

  const normalizedQuery = normalizeText(query);

  if (containsKeywords(normalizedQuery, greetingKeywords)) {
    return getGreetingResponse(context);
  }

  if (context.userRole === 'admin') {
    if (containsKeywords(normalizedQuery, statisticsKeywords) ||
        containsKeywords(normalizedQuery, ['school', 'overview'])) {
      return getAdminStatistics(context, query);
    }

    if (containsKeywords(normalizedQuery, decisionKeywords) ||
        containsKeywords(normalizedQuery, ['recommend', 'action', 'intervention'])) {
      return getAdminDecisionSupport(context, query);
    }

    if (containsKeywords(normalizedQuery, ['student', 'risk', 'attention', 'struggling'])) {
      return getAdminDecisionSupport(context, query);
    }
  }

  if (containsKeywords(normalizedQuery, adviceKeywords) ||
      containsKeywords(normalizedQuery, weaknessKeywords) ||
      containsKeywords(normalizedQuery, strengthKeywords)) {
    return getPersonalizedAdvice(context, query);
  }

  if (containsKeywords(normalizedQuery, motivationKeywords)) {
    return getMotivationalResponse(context);
  }

  if (containsKeywords(normalizedQuery, attendanceKeywords)) {
    return getAttendanceResponse(context, query);
  }

  if (containsKeywords(normalizedQuery, gradeKeywords)) {
    return getGradesResponse(context, query);
  }

  if (containsKeywords(normalizedQuery, syllabusKeywords)) {
    return getSyllabusResponse(context, query);
  }

  if (containsKeywords(normalizedQuery, announcementKeywords)) {
    return getAnnouncementsResponse(context);
  }

  if (containsKeywords(normalizedQuery, upcomingKeywords) ||
      containsKeywords(normalizedQuery, scheduleKeywords)) {
    return getUpcomingEventsResponse(context);
  }

  return getDefaultResponse(context, query);
}
