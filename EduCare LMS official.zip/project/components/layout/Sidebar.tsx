'use client';

import Link from 'next/link';
import Image from 'next/image';
import { usePathname } from 'next/navigation';
import { motion } from 'framer-motion';
import {
  LayoutDashboard,
  BookOpen,
  ClipboardCheck,
  Calendar,
  MessageSquare,
  Bell,
  FileText,
  BarChart3,
  Users,
  FolderOpen,
  BookMarked,
  Clock,
  Star,
  Upload,
  PenTool,
  GraduationCap,
  Settings,
  Sparkles
} from 'lucide-react';
import { useAppStore } from '@/lib/store';

interface NavItem {
  label: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
}

const studentNav: NavItem[] = [
  { label: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
  { label: 'AI Assistant', href: '/student/ai-assistant', icon: Sparkles },
  { label: 'Subjects', href: '/student/subjects', icon: BookOpen },
  { label: 'Assessments', href: '/student/assessments', icon: ClipboardCheck },
  { label: 'Syllabus', href: '/student/syllabus', icon: BookMarked },
  { label: 'Attendance', href: '/student/attendance', icon: Clock },
  { label: 'Timetable', href: '/student/timetable', icon: Calendar },
  { label: 'Calendar', href: '/student/calendar', icon: Calendar },
  { label: 'Announcements', href: '/student/announcements', icon: Bell },
  { label: 'Chat', href: '/student/chat', icon: MessageSquare },
  { label: 'Resources', href: '/student/resources', icon: FolderOpen },
  { label: 'Feedback', href: '/student/feedback', icon: Star }
];

const teacherNav: NavItem[] = [
  { label: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
  { label: 'AI Assistant', href: '/teacher/ai-assistant', icon: Sparkles },
  { label: 'Classes', href: '/teacher/classes', icon: Users },
  { label: 'Upload Marks', href: '/teacher/upload-marks', icon: Upload },
  { label: 'Create Quiz', href: '/teacher/create-quiz', icon: PenTool },
  { label: 'Syllabus', href: '/teacher/syllabus', icon: BookMarked },
  { label: 'Attendance', href: '/teacher/attendance', icon: Clock },
  { label: 'Timetable', href: '/teacher/timetable', icon: Calendar },
  { label: 'Calendar', href: '/teacher/calendar', icon: Calendar },
  { label: 'Announcements', href: '/teacher/announcements', icon: Bell },
  { label: 'Chat', href: '/teacher/chat', icon: MessageSquare },
  { label: 'Drive', href: '/teacher/drive', icon: FolderOpen },
  { label: 'Resources', href: '/teacher/shared-resources', icon: FileText },
  { label: 'Feedback', href: '/teacher/feedback-view', icon: Star }
];

const adminNav: NavItem[] = [
  { label: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
  { label: 'AI Assistant', href: '/admin/ai-assistant', icon: Sparkles },
  { label: 'Users', href: '/admin/users', icon: Users },
  { label: 'Classes', href: '/admin/classes', icon: GraduationCap },
  { label: 'Subjects', href: '/admin/subjects', icon: BookOpen },
  { label: 'Analytics', href: '/admin/analytics', icon: BarChart3 },
  { label: 'Calendar', href: '/admin/calendar-management', icon: Calendar },
  { label: 'Settings', href: '/admin/settings', icon: Settings }
];

export function Sidebar() {
  const pathname = usePathname();
  const { user, sidebarOpen } = useAppStore();

  if (!user) return null;

  const navItems = user.role === 'student' ? studentNav : user.role === 'teacher' ? teacherNav : adminNav;

  return (
    <motion.aside
      initial={{ x: -280 }}
      animate={{ x: sidebarOpen ? 0 : -280 }}
      transition={{ duration: 0.3 }}
      className="fixed left-0 top-0 h-screen w-64 bg-white border-r border-gray-200 z-40 overflow-y-auto"
    >
      <div className="p-6">
        <Link href="/dashboard" className="flex items-center space-x-3">
          <div className="w-12 h-12 flex items-center justify-center">
            <Image
              src="/white_logo.png"
              alt="EduCare Logo"
              width={48}
              height={48}
              className="w-full h-full object-contain"
            />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-800">EduCare</h1>
            <p className="text-xs text-gray-500 capitalize">{user.role}</p>
          </div>
        </Link>
      </div>

      <nav className="px-3 pb-6">
        {navItems.map((item, index) => {
          const isActive = pathname === item.href || pathname.startsWith(item.href + '/');
          const Icon = item.icon;

          return (
            <Link key={item.href} href={item.href}>
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className={`flex items-center space-x-3 px-4 py-3 rounded-lg mb-1 transition-all ${
                  isActive
                    ? 'bg-[#04ADEE] text-white shadow-sm'
                    : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-sm font-medium">{item.label}</span>
              </motion.div>
            </Link>
          );
        })}
      </nav>
    </motion.aside>
  );
}
