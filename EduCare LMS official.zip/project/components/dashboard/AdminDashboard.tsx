'use client';

import { TrendingUp, Users, GraduationCap, BookOpen, UserPlus } from 'lucide-react';
import { StatCard } from './StatCard';
import { LineChartComponent } from './LineChartComponent';
import { AdminDashboardData } from '@/lib/apiContracts/dashboard';
import { motion } from 'framer-motion';

interface AdminDashboardProps {
  data: AdminDashboardData;
}

export function AdminDashboard({ data }: AdminDashboardProps) {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-800">Admin Dashboard</h1>
        <p className="text-gray-600 mt-1">Monitor and manage your institution's performance</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Average Performance"
          value={data.performanceSummary.averagePerformance}
          suffix="%"
          icon={TrendingUp}
          color="#04ADEE"
          delay={0}
        />
        <StatCard
          title="Total Students"
          value={data.performanceSummary.totalStudents}
          icon={Users}
          color="#10B981"
          delay={0.1}
        />
        <StatCard
          title="Total Teachers"
          value={data.performanceSummary.totalTeachers}
          icon={GraduationCap}
          color="#F59E0B"
          delay={0.2}
        />
        <StatCard
          title="Total Classes"
          value={data.performanceSummary.totalClasses}
          icon={BookOpen}
          color="#8B5CF6"
          delay={0.3}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <LineChartComponent
            data={data.attendanceTrends.map(t => ({
              name: new Date(t.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
              value: t.percentage
            }))}
            title="Attendance Trends"
            color="#04ADEE"
            yAxisLabel="Attendance %"
            delay={0.4}
          />
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.5 }}
          className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
        >
          <h3 className="text-lg font-semibold text-gray-800 mb-6">User Statistics</h3>
          <div className="space-y-6">
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-gray-600">Active Students</span>
                <span className="text-2xl font-bold text-[#04ADEE]">{data.userStats.activeStudents}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${(data.userStats.activeStudents / data.performanceSummary.totalStudents) * 100}%` }}
                  transition={{ delay: 0.6, duration: 1 }}
                  className="bg-[#04ADEE] h-2 rounded-full"
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-gray-600">Active Teachers</span>
                <span className="text-2xl font-bold text-[#10B981]">{data.userStats.activeTeachers}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${(data.userStats.activeTeachers / data.performanceSummary.totalTeachers) * 100}%` }}
                  transition={{ delay: 0.7, duration: 1 }}
                  className="bg-[#10B981] h-2 rounded-full"
                />
              </div>
            </div>

            <div className="pt-4 border-t border-gray-100">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <UserPlus className="w-5 h-5 text-[#F59E0B]" />
                  <span className="text-sm text-gray-600">New Enrollments</span>
                </div>
                <span className="text-2xl font-bold text-[#F59E0B]">{data.userStats.newEnrollments}</span>
              </div>
              <p className="text-xs text-gray-500 mt-2">This month</p>
            </div>
          </div>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.5 }}
          className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-6 text-white shadow-lg"
        >
          <h3 className="text-lg font-semibold mb-2">Performance</h3>
          <p className="text-3xl font-bold mb-2">{data.performanceSummary.averagePerformance}%</p>
          <p className="text-sm opacity-90">Institution average score</p>
          <div className="mt-4 pt-4 border-t border-blue-400">
            <p className="text-xs opacity-75">Compared to last month</p>
            <p className="text-sm font-semibold mt-1">↑ 2.5% increase</p>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7, duration: 0.5 }}
          className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl p-6 text-white shadow-lg"
        >
          <h3 className="text-lg font-semibold mb-2">Attendance</h3>
          <p className="text-3xl font-bold mb-2">
            {Math.round(data.attendanceTrends.reduce((acc, t) => acc + t.percentage, 0) / data.attendanceTrends.length)}%
          </p>
          <p className="text-sm opacity-90">Average attendance rate</p>
          <div className="mt-4 pt-4 border-t border-green-400">
            <p className="text-xs opacity-75">Trend</p>
            <p className="text-sm font-semibold mt-1">Stable</p>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.5 }}
          className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl p-6 text-white shadow-lg"
        >
          <h3 className="text-lg font-semibold mb-2">Capacity</h3>
          <p className="text-3xl font-bold mb-2">
            {Math.round((data.performanceSummary.totalStudents / (data.performanceSummary.totalClasses * 30)) * 100)}%
          </p>
          <p className="text-sm opacity-90">Classroom utilization</p>
          <div className="mt-4 pt-4 border-t border-purple-400">
            <p className="text-xs opacity-75">Available capacity</p>
            <p className="text-sm font-semibold mt-1">
              {(data.performanceSummary.totalClasses * 30) - data.performanceSummary.totalStudents} seats
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
