'use client';

import { TrendingUp, Users, BookOpen, Upload, PenTool, Star, AlertCircle } from 'lucide-react';
import { StatCard } from './StatCard';
import { BarChartComponent } from './BarChartComponent';
import { TeacherDashboardData } from '@/lib/apiContracts/dashboard';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import Link from 'next/link';

interface TeacherDashboardProps {
  data: TeacherDashboardData;
}

export function TeacherDashboard({ data }: TeacherDashboardProps) {
  const avgProgress = Math.round(
    data.syllabusProgress.reduce((acc, s) => acc + s.progress, 0) / data.syllabusProgress.length
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Dashboard</h1>
          <p className="text-gray-600 mt-1">Manage your classes and track student performance</p>
        </div>
        <div className="flex gap-3">
          <Link href="/teacher/upload-marks">
            <Button className="bg-[#04ADEE] hover:bg-[#0398d4]">
              <Upload className="w-4 h-4 mr-2" />
              Upload Marks
            </Button>
          </Link>
          <Link href="/teacher/create-quiz">
            <Button variant="outline">
              <PenTool className="w-4 h-4 mr-2" />
              Create Quiz
            </Button>
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Overall Average"
          value={data.overallAverage}
          suffix="%"
          icon={TrendingUp}
          color="#04ADEE"
          delay={0}
        />
        <StatCard
          title="Total Classes"
          value={data.classAverages.length}
          icon={Users}
          color="#10B981"
          delay={0.1}
        />
        <StatCard
          title="Syllabus Progress"
          value={avgProgress}
          suffix="%"
          icon={BookOpen}
          color="#F59E0B"
          delay={0.2}
        />
        <StatCard
          title="Attendance Alerts"
          value={data.attendanceAlerts.length}
          icon={AlertCircle}
          color="#EF4444"
          delay={0.3}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <BarChartComponent
          data={data.classAverages.map(c => ({
            name: c.className,
            value: c.average,
            color: c.color
          }))}
          title="Class Performance"
          yAxisLabel="Average Score (%)"
          delay={0.4}
        />

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.5 }}
          className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
        >
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Syllabus Progress</h3>
          <div className="space-y-4">
            {data.syllabusProgress.map((subject, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 + index * 0.1, duration: 0.3 }}
              >
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium text-gray-700">{subject.subject}</span>
                  <span className="text-sm font-semibold text-[#04ADEE]">{subject.progress}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${subject.progress}%` }}
                    transition={{ delay: 0.5 + index * 0.1, duration: 1 }}
                    className="bg-[#04ADEE] h-2.5 rounded-full"
                  />
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.5 }}
          className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-800">Recent Feedback</h3>
            <Star className="w-5 h-5 text-yellow-500" />
          </div>
          <div className="space-y-4">
            {data.recentFeedback.map((feedback, index) => (
              <motion.div
                key={feedback.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.6 + index * 0.1, duration: 0.3 }}
                className="p-4 bg-yellow-50 rounded-lg border border-yellow-100"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-gray-800">{feedback.studentName}</span>
                  <div className="flex">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        className={`w-4 h-4 ${
                          i < feedback.rating ? 'fill-yellow-500 text-yellow-500' : 'text-gray-300'
                        }`}
                      />
                    ))}
                  </div>
                </div>
                <p className="text-sm text-gray-600">{feedback.comment}</p>
                <span className="text-xs text-gray-500 mt-2 block">
                  {new Date(feedback.date).toLocaleDateString()}
                </span>
              </motion.div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7, duration: 0.5 }}
          className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-800">Attendance Alerts</h3>
            <AlertCircle className="w-5 h-5 text-red-500" />
          </div>
          <div className="space-y-4">
            {data.attendanceAlerts.map((alert, index) => (
              <motion.div
                key={alert.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.7 + index * 0.1, duration: 0.3 }}
                className="p-4 bg-red-50 rounded-lg border border-red-100"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-gray-800">{alert.studentName}</p>
                    <p className="text-sm text-gray-600">{alert.className}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-red-600">{alert.attendancePercentage}%</p>
                    <p className="text-xs text-gray-500">Attendance</p>
                  </div>
                </div>
              </motion.div>
            ))}
            {data.attendanceAlerts.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <AlertCircle className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                <p>No attendance alerts</p>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
