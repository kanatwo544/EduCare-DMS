'use client';

import { TrendingUp, BookOpen, Clock, Target } from 'lucide-react';
import { StatCard } from './StatCard';
import { ProgressRing } from './ProgressRing';
import { BarChartComponent } from './BarChartComponent';
import { StudentDashboardData } from '@/lib/apiContracts/dashboard';
import { motion } from 'framer-motion';

interface StudentDashboardProps {
  data: StudentDashboardData;
}

export function StudentDashboard({ data }: StudentDashboardProps) {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-800">Dashboard</h1>
        <p className="text-gray-600 mt-1">Track your academic progress and stay updated</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Overall Average"
          value={data.overallAverage}
          suffix="%"
          icon={TrendingUp}
          color="#04ADEE"
          delay={0}
        />
        <StatCard
          title="Syllabus Progress"
          value={data.syllabusProgress}
          suffix="%"
          icon={BookOpen}
          color="#10B981"
          delay={0.1}
        />
        <StatCard
          title="Attendance"
          value={data.attendancePercentage}
          suffix="%"
          icon={Clock}
          color="#F59E0B"
          delay={0.2}
        />
        <StatCard
          title="Assessments"
          value={data.recentAssessments.length}
          icon={Target}
          color="#8B5CF6"
          delay={0.3}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <BarChartComponent
            data={data.subjectAverages.map(s => ({
              name: s.subject,
              value: s.average,
              color: s.color
            }))}
            title="Subject Performance"
            yAxisLabel="Average Score (%)"
            delay={0.4}
          />
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.5 }}
          className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 flex items-center justify-center"
        >
          <ProgressRing
            progress={data.syllabusProgress}
            size={180}
            strokeWidth={12}
            color="#04ADEE"
            label="Syllabus Completion"
            delay={0.6}
          />
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7, duration: 0.5 }}
          className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
        >
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Recent Announcements</h3>
          <div className="space-y-4">
            {data.recentAnnouncements.map((announcement, index) => (
              <motion.div
                key={announcement.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.7 + index * 0.1, duration: 0.3 }}
                className="p-4 bg-blue-50 rounded-lg border border-blue-100 hover:bg-blue-100 transition-colors"
              >
                <h4 className="font-semibold text-gray-800">{announcement.title}</h4>
                <p className="text-sm text-gray-600 mt-1">{announcement.content}</p>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-xs text-gray-500">{announcement.author}</span>
                  <span className="text-xs text-gray-500">
                    {new Date(announcement.date).toLocaleDateString()}
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.5 }}
          className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
        >
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Upcoming Events</h3>
          <div className="space-y-4">
            {data.upcomingEvents.map((event, index) => (
              <motion.div
                key={event.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.8 + index * 0.1, duration: 0.3 }}
                className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <div className="flex items-center space-x-3">
                  <div className={`w-2 h-2 rounded-full ${
                    event.type === 'quiz' ? 'bg-blue-500' :
                    event.type === 'assignment' ? 'bg-orange-500' : 'bg-purple-500'
                  }`} />
                  <div>
                    <p className="font-medium text-gray-800">{event.title}</p>
                    <p className="text-xs text-gray-500 capitalize">{event.type}</p>
                  </div>
                </div>
                <span className="text-sm text-gray-600">
                  {new Date(event.date).toLocaleDateString()}
                </span>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.9, duration: 0.5 }}
        className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
      >
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Recent Assessments</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Subject</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Title</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Score</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {data.recentAssessments.map((assessment, index) => (
                <motion.tr
                  key={assessment.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.9 + index * 0.05, duration: 0.3 }}
                  className="hover:bg-gray-50 transition-colors"
                >
                  <td className="px-4 py-3 text-sm text-gray-700 font-medium">{assessment.subject}</td>
                  <td className="px-4 py-3 text-sm text-gray-700">{assessment.title}</td>
                  <td className="px-4 py-3 text-sm">
                    <span className={`font-semibold ${
                      (assessment.score / assessment.maxScore) * 100 >= 80 ? 'text-green-600' :
                      (assessment.score / assessment.maxScore) * 100 >= 60 ? 'text-yellow-600' : 'text-red-600'
                    }`}>
                      {assessment.score}/{assessment.maxScore}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-600">
                    {new Date(assessment.date).toLocaleDateString()}
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </div>
  );
}
