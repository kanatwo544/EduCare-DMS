'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { User, Mail, Phone, MapPin, Calendar, Edit2, Save, X, Camera } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppStore } from '@/lib/store';
import { useAppData } from '@/lib/context/AppDataContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';

export default function ProfilePage() {
  const { user } = useAppStore();
  const { students, teachers, updateProfile } = useAppData();
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: '',
    address: '',
    bio: ''
  });

  if (!user) return null;

  const userDetails = user.role === 'student'
    ? students.find(s => s.id === user.id)
    : teachers.find(t => t.id === user.id);

  const initials = user.name.split(' ').map(n => n[0]).join('').toUpperCase();

  const handleSave = () => {
    updateProfile(user.id, editForm);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditForm({
      name: user.name,
      email: user.email,
      phone: '',
      address: '',
      bio: ''
    });
    setIsEditing(false);
  };

  return (
    <DashboardLayout>
      <div className="max-w-4xl space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">My Profile</h1>
          <p className="text-gray-600 mt-1">Manage your personal information</p>
        </div>

        <Card className="p-8">
          <div className="flex items-start justify-between mb-8">
            <div className="flex items-center space-x-6">
              <div className="relative group">
                <Avatar className="w-24 h-24">
                  <AvatarImage src={user.avatar} alt={user.name} />
                  <AvatarFallback className="bg-[#04ADEE] text-white text-2xl">
                    {initials}
                  </AvatarFallback>
                </Avatar>
                {isEditing && (
                  <button className="absolute inset-0 bg-black bg-opacity-50 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Camera className="w-6 h-6 text-white" />
                  </button>
                )}
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-800">{user.name}</h2>
                <Badge className="mt-2 bg-[#04ADEE] capitalize">{user.role}</Badge>
              </div>
            </div>
            {!isEditing ? (
              <Button onClick={() => setIsEditing(true)} className="bg-[#04ADEE] hover:bg-[#0398d4]">
                <Edit2 className="w-4 h-4 mr-2" />
                Edit Profile
              </Button>
            ) : (
              <div className="flex gap-2">
                <Button variant="outline" onClick={handleCancel}>
                  <X className="w-4 h-4 mr-2" />
                  Cancel
                </Button>
                <Button onClick={handleSave} className="bg-[#04ADEE] hover:bg-[#0398d4]">
                  <Save className="w-4 h-4 mr-2" />
                  Save Changes
                </Button>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label className="text-gray-700 font-medium flex items-center gap-2 mb-2">
                <User className="w-4 h-4" />
                Full Name
              </Label>
              {isEditing ? (
                <Input
                  value={editForm.name}
                  onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                  placeholder="Enter your full name"
                />
              ) : (
                <p className="text-gray-900 p-2 bg-gray-50 rounded">{user.name}</p>
              )}
            </div>

            <div>
              <Label className="text-gray-700 font-medium flex items-center gap-2 mb-2">
                <Mail className="w-4 h-4" />
                Email Address
              </Label>
              {isEditing ? (
                <Input
                  type="email"
                  value={editForm.email}
                  onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                  placeholder="Enter your email"
                />
              ) : (
                <p className="text-gray-900 p-2 bg-gray-50 rounded">{user.email}</p>
              )}
            </div>

            <div>
              <Label className="text-gray-700 font-medium flex items-center gap-2 mb-2">
                <Phone className="w-4 h-4" />
                Phone Number
              </Label>
              {isEditing ? (
                <Input
                  type="tel"
                  value={editForm.phone}
                  onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })}
                  placeholder="Enter your phone number"
                />
              ) : (
                <p className="text-gray-900 p-2 bg-gray-50 rounded">{editForm.phone || 'Not provided'}</p>
              )}
            </div>

            <div>
              <Label className="text-gray-700 font-medium flex items-center gap-2 mb-2">
                <MapPin className="w-4 h-4" />
                Address
              </Label>
              {isEditing ? (
                <Input
                  value={editForm.address}
                  onChange={(e) => setEditForm({ ...editForm, address: e.target.value })}
                  placeholder="Enter your address"
                />
              ) : (
                <p className="text-gray-900 p-2 bg-gray-50 rounded">{editForm.address || 'Not provided'}</p>
              )}
            </div>

            {user.role === 'student' && userDetails && (
              <>
                <div>
                  <Label className="text-gray-700 font-medium flex items-center gap-2 mb-2">
                    <Calendar className="w-4 h-4" />
                    Class
                  </Label>
                  <p className="text-gray-900 p-2 bg-gray-50 rounded">{(userDetails as any).class}</p>
                </div>

                <div>
                  <Label className="text-gray-700 font-medium mb-2">
                    Student ID
                  </Label>
                  <p className="text-gray-900 p-2 bg-gray-50 rounded">{user.id}</p>
                </div>

                <div className="md:col-span-2">
                  <Label className="text-gray-700 font-medium mb-2">
                    Subjects Enrolled
                  </Label>
                  <div className="flex flex-wrap gap-2">
                    {(userDetails as any).subjects?.slice(0, 3).map((subjectId: string, index: number) => (
                      <Badge key={index} variant="outline">
                        Subject {index + 1}
                      </Badge>
                    ))}
                  </div>
                </div>
              </>
            )}

            {user.role === 'teacher' && (
              <>
                <div>
                  <Label className="text-gray-700 font-medium mb-2">
                    Teacher ID
                  </Label>
                  <p className="text-gray-900 p-2 bg-gray-50 rounded">{user.id}</p>
                </div>

                <div>
                  <Label className="text-gray-700 font-medium mb-2">
                    Department
                  </Label>
                  <p className="text-gray-900 p-2 bg-gray-50 rounded">Science</p>
                </div>
              </>
            )}
          </div>

          <div className="mt-6">
            <Label className="text-gray-700 font-medium mb-2">
              Bio
            </Label>
            {isEditing ? (
              <Textarea
                value={editForm.bio}
                onChange={(e) => setEditForm({ ...editForm, bio: e.target.value })}
                placeholder="Tell us about yourself..."
                rows={4}
              />
            ) : (
              <p className="text-gray-900 p-3 bg-gray-50 rounded min-h-[100px]">
                {editForm.bio || 'No bio provided yet.'}
              </p>
            )}
          </div>
        </Card>

        {user.role === 'student' && userDetails && (
          <Card className="p-6">
            <h3 className="text-xl font-bold text-gray-800 mb-4">Academic Performance</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <p className="text-sm text-gray-600 mb-1">Overall Average</p>
                <p className="text-3xl font-bold text-blue-600">{(userDetails as any).overallAverage}%</p>
              </div>
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <p className="text-sm text-gray-600 mb-1">Attendance</p>
                <p className="text-3xl font-bold text-green-600">{(userDetails as any).attendance}%</p>
              </div>
              <div className="text-center p-4 bg-purple-50 rounded-lg">
                <p className="text-sm text-gray-600 mb-1">Rank</p>
                <p className="text-3xl font-bold text-purple-600">#{(userDetails as any).rank}</p>
              </div>
            </div>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
