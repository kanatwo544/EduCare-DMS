'use client';

import { ReactNode } from 'react';
import { AppDataProvider } from '@/lib/context/AppDataContext';

interface AppProvidersProps {
  children: ReactNode;
}

export function AppProviders({ children }: AppProvidersProps) {
  return (
    <AppDataProvider>
      {children}
    </AppDataProvider>
  );
}
