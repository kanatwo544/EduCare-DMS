'use client';

import { DashboardLayout } from './layout/DashboardLayout';

interface PlaceholderPageProps {
  title: string;
  description: string;
}

export function PlaceholderPage({ title, description }: PlaceholderPageProps) {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">{title}</h1>
          <p className="text-gray-600 mt-1">{description}</p>
        </div>
        <div className="bg-white rounded-xl p-12 text-center border border-gray-100">
          <p className="text-gray-500">This page is under construction...</p>
        </div>
      </div>
    </DashboardLayout>
  );
}
